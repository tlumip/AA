package simpleorm.dataset;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import simpleorm.utils.SException;

/*
 * Copyright (c) 2002 Southern Cross Software Queensland (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/**
 * The main Query inteface that provides structured queries.
 * <p>
 * 
 * For example:-
 * <xmp> 
 * Department d100q = session.findOrCreate(Department.DEPARTMENT, "100"); 
 * SQuery<Employee> query = new SQuery(Employee.EMPLOYEE)
 *  .eq(Employee.DEPARTMENT, d100q) // and
 *  .like(Employee.NAME, "%One%")
 *  .descending(Employee.SALARY);
 * List<Employee> emps = session.query(query); 
 * </xmp>
 * 
 * This API is a little unusual in that there is only one SQuery instance
 * created, and each of the methods update its state and then return
 * <code>this</code>.
 * <p>
 * 
 * The normal expansion of the query into SQL is performed by SQueryExecute in the SSessionJdbc
 * package.  The raw* methods can be used to poke any string into the SQL Where or Order
 * By clauses in the order they appear.
 * <p>
 * 
 */

public class SQuery<T extends SRecordInstance> {
	SRecordMeta<T> record = null;

	Map<SRecordMeta<?>, SSelectMode> joinTables = new HashMap<SRecordMeta<?>, SSelectMode>(5);
	
	Set<SFieldReference> joinFields = new HashSet<SFieldReference>(5); 

	ArrayList<Object> queryParameters = new ArrayList<Object>(2);

	SQueryMode queryMode;
	
	long limit = Integer.MAX_VALUE;
	
	long offset = 0;

	SFieldScalar[] selectList = null;

	ArrayList<Join> joins = new ArrayList<Join>();
	
    Where where;
    
    OrderBy orderBy;

    static public class Join {
        String allRaw;
        public String getAllRaw() {
            return allRaw;
        }               
    }
    
    /** Complete raw SQL. Just poked in.  Note also rawClause().*/
    String rawSql;
    
    static public class Where {
        Where left;
        //SFieldReference subSelectRef; // Unfinished, unused for now.  See QueryTests.queryJoinTest.
        SFieldScalar leftField;
        String operator;
        Where right;
        String rightRaw;
        SFieldScalar rightField;
        String allRaw;
        public Where getLeft() {
            return left;
        }
        public SFieldScalar getLeftField() {
            return leftField;
        }
        public String getOperator() {
            return operator;
        }
        public Where getRight() {
            return right;
        }
        public SFieldScalar getRightField() {
            return rightField;
        }        
        public String getRightRaw() {
            return rightRaw;
        }
        public String getAllRaw() {
            return allRaw;
        }               
    }
    
    static public class OrderBy {
        SFieldMeta field;
        String raw;
        boolean ascending;
        OrderBy next;
        public boolean isAscending() {
            return ascending;
        }
        public SFieldMeta getField() {
            return field;
        }
        public String getRaw() {
            return raw;
        }
        public OrderBy getNext() {
            return next;
        }        
    }
    
	/** A new query object that can be .exeuted to produce an SResultSet. */
	public SQuery(SRecordMeta<T> record, SQueryMode queryMode,	SFieldScalar[] selectList) {
		this.record = record;
		this.queryMode = queryMode;
		this.selectList = selectList;
	}
	public SQuery(SRecordMeta<T> record, SSelectMode selectMode) {
        this(record, SQueryMode.SBASIC, selectMode);        
   }
	public SQuery(SRecordMeta<T> record, SQueryMode queryMode) {
         this(record, queryMode, record.getQueriedScalarFields());        
    }
	public SQuery(SRecordMeta<T> record, SQueryMode queryMode,  SSelectMode selectMode) {
         this(record, queryMode, record.fieldsForMode(selectMode));        
    }
	public SQuery(SRecordMeta<T> record) {
         this(record, SQueryMode.SBASIC);        
    }

	public SRecordMeta<T> getRecordMeta() {
		return record;
	}

	/**
	 * Set limit
	 */
	public SQuery<T> setLimit(long lim) {
		limit = lim;
		return this;
	}
	public long getLimit() {
		return this.limit;
	}
	public long getOffset() {
		return this.offset;
	}
	
	/**
	 * Set offset
	 */
	public SQuery<T> setOffset(long off) {
		offset = off;
		return this;
	}

	/**
	 * Add a join to the join statement. Spaces before and after statement
	 * are added systematically.
	 */
	public SQuery<T> rawJoin(String sqlJoin, Object... parameters) {

		Join newJoin = new Join();
		newJoin.allRaw = sqlJoin;
		addJoin(newJoin);
        for (Object par:parameters) rawParameter(par);
		return this;
	}
	private void addJoin(Join newJoin) {
        if (joins == null) {
            joins = new ArrayList<Join>();
            joins.add(newJoin);
        } else {
        	joins.add(newJoin);
        }
	}

	/**
	 * Add predicate to the where class, eg. "BUDGET > ?". Not normally called
	 * directly.
	 */
	public SQuery<T> rawPredicate(String predicate, Object... parameters) {
        
        Where nw = new Where();
        nw.allRaw = predicate;
        addWhere(nw);
        
        for (Object par:parameters) rawParameter(par);
		return this;
	}
    private void addWhere(Where newWhere) {
        Where ow = where;
        if (ow == null) {
            where = newWhere;
        } else {
            where = new Where();
            where.left = ow;
            where.operator = "AND";
            where.right = newWhere;
        }
    }

	/**
	 * Add a clause to the OrderBy statement, eg. "NAME DESC". Commas are added
	 * automatically.
	 */
	public SQuery<T> rawOrderBy(String raw) {
        appendNewOrderBy().raw = raw;
		return this;
	}

     private OrderBy appendNewOrderBy() {
        //OrderBy ob = orderBy;
        OrderBy ob = new OrderBy();
        if (this.orderBy == null) {
            this.orderBy = ob;
        } else {
            OrderBy current = this.orderBy;
            while (current.next != null) {
                current = current.next;
            }
            current.next = ob;
        }
        return ob;
    }

	public SQuery<T> rawOrderBy(SFieldMeta field, boolean ascending) {
		verifyFieldOkToUse(field);
		if (field instanceof SFieldReference) {
			Set<SFieldScalar> fields = ((SFieldReference<?>) field).getForeignKeyMetas();
			for (SFieldScalar fld : fields) {
				rawOrderBy(fld, ascending);
			}
		} else {
            OrderBy ob = appendNewOrderBy();
            ob.field = field;
            ob.ascending = ascending;
        }
		return this;
	}

    /** Just specifies the entire SQL statement, including the Select. */
    public SQuery rawSql(String rawSelectSql, Object... parameters) {
        this.rawSql = rawSelectSql;        
        for (Object par:parameters) rawParameter(par);
        return this;
    }


    
	/**
	 * Throws exception if field is not from this table, or any of the joined
	 * tables
	 */
	private void verifyFieldOkToUse(SFieldMeta field) {
		if (field.getRecordMeta() != record
				&& !joinTables.containsKey(field.getRecordMeta())) {
			throw new SException.Error("Field " + field
					+ " is not from record " + field.getRecordMeta());
		}
	}

	/**
	 * Add a parameter value to the internal array. These will be
	 * <code>setObject</code> later after the prepared statement is created
	 * but before it is executed.  Not normally used.
	 */
	SQuery<T> rawParameter(Object parameter) {
		queryParameters.add(parameter);
		return this;
	}

	/**
	 * Generates <code>field relop ?</code> and then subsequently sets the
	 * parameter value. Eg.
	 * <p>
	 * 
	 * <code>fieldRelopParameter(Employee.Name, "=", myName)</code>
	 * <p>
	 */
	public SQuery<T> fieldRelopParameter(
        SFieldScalar field, String relop,	Object value) {
		// If object passed in is really an SFieldMeta, use the method that is
		// appropriate
		if (value instanceof SFieldScalar)
			return this.fieldRelopParameter(field, relop, (SFieldScalar) value);

       fieldRelopParameterInner(field, relop).rightRaw = "?";
       
       rawParameter(value);

		return this;
	}

	/**
	 * Generates <code>field1 relop field2</code>
	 * 
	 * E.g.
	 * <code>fieldRelopParameter(Order.QuantityRequired, "=", Order.QuantityReceived)</code>
	 * <p>
	 * Mainly useful for Joins.
	 */
	public SQuery<T> fieldRelopParameter(
         SFieldScalar field1, String relop, SFieldScalar field2) {
       fieldRelopParameterInner(field1, relop).rightField = field2;
       return this;
	}

    private Where fieldRelopParameterInner(SFieldScalar field1, String relop) {
        Where nw = new Where();
//        if (subSelectRef != null && subSelectRef.getRecordMeta() != record)
//            throw new SException.Error("Reference " + subSelectRef + " not in " + record);
//        nw.subSelectRef = subSelectRef; 
        nw.leftField = field1;
        nw.operator = relop;
        addWhere(nw);
        return nw;
    }

	/**
	 * Generates <code>field clause</code>, ie the clause string is poked
	 * literally into the query. Eg.
	 * <p>
	 * <code>fieldQuery(Employee.Name, "= 'Fred'")</code>
	 * <p>
	 * 
	 * Use fieldRelopParameter instead for parameters determined at run time as
	 * blindly concatenating strings is dangerous.
	 */
	public SQuery<T> fieldQuery(SFieldScalar field, String clause) {

       Where nw = new Where();
       nw.leftField = field;
       nw.operator = "";
       nw.rightRaw = clause;
       addWhere(nw);

       return this;
	}

	/**
	 * Join to another table, based on the specified reference that is in the query table.
     * This peforms an eager lookup on the referenced tables, so avoiding the N+1 problem.
	 * <p>
	 * 
     * Joins only work from the query table to tables directly liked by the reference.
     * It is not currently possible to join a table to itself (eg. Employee.Manager).<p>
     * 
     * Normally the looked up records are also retrieved, although it is possible to
     * specify selectMode = NONE if the join is only for the WHERE clause.<p>
     * 
     * Currently implemented as Inner joins, but will be fixed to be left outer joins.<p>
     * 
     * Note that this is only useful if the number of joined in records is substantial. 
     * For example, if there are 1,000 employees in 10 departments, then it is probably
     * faster (and certainly simpler) to retrieve the departments lazily rather than
     * retrieve the fields for the 10 departments 1000 times and throw them away each time.<p>
     * 
     * Note also that Subselects can be used to reference fields in the where clause without
     * introduing outer join issues.<p>
	 */
	public SQuery<T> join(SFieldReference<?> reference) {
		return join(reference, SSelectMode.SNORMAL);
	}
	public SQuery<T> join(SFieldReference<?> reference, SSelectMode selectMode) {
        if (reference.getRecordMeta() != record)
            throw new SException.Error("Reference must be in record " + reference + " " + record);
		SRecordMeta<?> joinTable = reference.getReferencedRecordMeta();
		if (joinTables.containsKey(joinTable) || joinTable == record)
            throw new SException.Error("Table can not be joined multiple times " + joinTable);

		joinTables.put(joinTable, selectMode);
		if ( ! SSelectMode.SNONE.equals(selectMode)) 
				joinFields.add(reference); // Only retrieve if selected
	    // append joining statements to where clause
		eqJoinReference(reference);
		return this;
	}

	public Map<SRecordMeta<?>, SSelectMode> getJoinTables() {
		return joinTables;
	}
	
	public Set<SFieldReference> getJoinFields() {
		return joinFields;
	}
	
	public SFieldScalar[] getSelectList() {
		return selectList;
	}
	
	/**
	 * Generate the conjunction of equalities for the foreign key columns
	 * recursively. Used for joins
	 */
	private void eqJoinReference(SFieldReference<?> ref) {
		for (SFieldScalar fkey : ref.getForeignKeyMetas()) {
			fieldRelopParameter(fkey, "=", ref.getPrimaryKeyForForegnKey(fkey));
		}
	}

	/**
	 * Compares ref with value, recurively. operator is normally "=", but can be
	 * "NOT NULL" etc.
	 */
	private void opReference(SFieldReference<?> ref, SRecordInstance value,
							 String operator, boolean disjoin, boolean diadic) {

        int count=0;
		for (SFieldScalar fkey : ref.getForeignKeyMetas()) {
			SFieldScalar refed = ref.getPrimaryKeyForForegnKey(fkey);
			if (disjoin && count>0) 
                throw new SException.Error("Ref<>Ref not supported for multiple keys yet");
			if (diadic) {
				Object val = value.getObject(refed);
				fieldRelopParameter(fkey, operator, val);
			} else
				fieldQuery(fkey, operator);
		}
        count++;
	}

	SQuery<T> eqNeAux(SFieldMeta field, Object value, boolean isEq) {
		if (value == null)
			throw new SException.Error("Use isNull to test for nulls " + field);
		String op = isEq ? "=" : "<>";
		if (!(field instanceof SFieldReference)) {
			return fieldRelopParameter((SFieldScalar)field, op, value);
		} else {
			if (!(value instanceof SRecordInstance))
				throw new SException.Error("value " + value
						+ " must be an SRecordInstance for reference " + field
						+ " building " + this);
			SFieldReference<?> refFld = (SFieldReference<?>) field;
			SRecordMeta<?> refedRec = refFld.getReferencedRecordMeta();
			if (((SRecordInstance) value).getMeta() != refedRec)
				throw new SException.Error("Value " + value + " must be a "
						+ refedRec + " building " + this);
			opReference((SFieldReference<?>) field, (SRecordInstance) value, op,
					!isEq, true);
			return this;
		}
	}

	SQuery<T> nullAux(SFieldMeta field, boolean isNull) {
		String op = isNull ? "IS NULL" : "IS NOT NULL";
		if (!(field instanceof SFieldReference)) {
			SFieldScalar sclFld = (SFieldScalar) field;
			return fieldQuery(sclFld, op);
		} else {
			// SFieldReference refFld = (SFieldReference)field;
			opReference((SFieldReference<?>) field, null, op, isNull, false);
			return this;
		}
	}

	/**
	 * Normally just adds <code>fieldRelopParameter(field, "=",
	 value)</code>.
	 * <p>
	 * 
	 * If field is a reference it recursively expands the foreign keys, and
	 * value must be an instance of the same record type.
	 * <p>
	 * 
	 * value must not be null, you need the special case IS NULL test. (It would
	 * be possible to optimize this here, but what about field == field where
	 * one of them is null -- that would be inconsistent.)
	 * <p>
	 */
	public SQuery<T> eq(SFieldMeta field, Object value) {
		return eqNeAux(field, value, true);
	}

	public SQuery<T> eq(SFieldScalar field1, SFieldMeta field2) {
		return fieldRelopParameter(field1, "=", field2);
	}

	/**
	 * True if boolean field == writeFieldValue(value). Ie. value is converted
	 * from bool to "Y"/"N" etc.
	 */
	public SQuery<T> equivalent(SFieldBoolean field, boolean value) {
		return eq(field, field.writeFieldValue(value ? Boolean.TRUE
				: Boolean.FALSE));
	}

	/**
	 * shortcut for equivalent(field, true);
	 */
	public SQuery<T> isTrue(SFieldBoolean field) {
		return equivalent(field, true);
	}

	public SQuery<T> isFalse(SFieldBoolean field) {
		return equivalent(field, false);
	}

	/**
	 * Just adds <code>fieldRelopParameter(field, "<>", value)</code>.
	 * <p>
	 * 
	 * Note that there are few methods <code>ne(SfieldMeta, int)</code> etc.
	 * This is because 5 relops * 5 data types would require 25 methods! Java
	 * 1.5 boxing will (finally) make this unnecessary anyway.
	 */
	public SQuery<T> ne(SFieldMeta field, Object value) {
		return eqNeAux(field, value, false);
	}

	public SQuery<T> ne(SFieldScalar field1, SFieldMeta field2) {
		return fieldRelopParameter(field1, "<>", field2);
	}

//####    I would also like eq/ne(field, null) to be handled automatically by SQuery.  
//    (convert to IS NULL)  Need to be careful about Oracle where x = "" must also be converted.  
//    So the conversion needs to happen in SQuery.Sql.

	/** Just adds <code>fieldQuery(field, "IS NULL")</code> */
	public SQuery<T> isNull(SFieldMeta field) {
		return nullAux(field, true);
	}

	/** Just adds <code>fieldQuery(field, "IS NULL")</code> */
	public SQuery<T> isNotNull(SFieldMeta field) {
		return nullAux(field, false);
	}

	/** Just adds <code>fieldRelopParameter(field, "&gt;", value)</code> */
	public SQuery<T> gt(SFieldScalar field, Object value) {
		return fieldRelopParameter(field, ">", value);
	}

	public SQuery<T> gt(SFieldScalar field, int value) {
		return gt(field, new Integer(value));
	}

	public SQuery<T> gt(SFieldScalar field, long value) {
		return gt(field, new Long(value));
	}

	public SQuery<T> gt(SFieldScalar field, double value) {
		return gt(field, new Double(value));
	}

	public SQuery<T> gt(SFieldScalar field1, SFieldMeta field2) {
		return fieldRelopParameter(field1, ">", field2);
	}

	/** Just adds <code>fieldRelopParameter(field, "&lt;", value)</code> */
	public SQuery<T> lt(SFieldScalar field, Object value) {
		return fieldRelopParameter(field, "<", value);
	}

	public SQuery<T> lt(SFieldScalar field, int value) {
		return lt(field, new Integer(value));
	}

	public SQuery<T> lt(SFieldScalar field, long value) {
		return lt(field, new Long(value));
	}

	public SQuery<T> lt(SFieldScalar field, double value) {
		return lt(field, new Double(value));
	}

	public SQuery<T> lt(SFieldScalar field1, SFieldMeta field2) {
		return fieldRelopParameter(field1, "<", field2);
	}

	/** Just adds <code>fieldRelopParameter(field, "&lt;=", value)</code> */
	public SQuery<T> le(SFieldScalar field, Object value) {
		return fieldRelopParameter(field, "<=", value);
	}

	public SQuery<T> le(SFieldScalar field, int value) {
		return le(field, new Integer(value));
	}

	public SQuery<T> le(SFieldScalar field, long value) {
		return le(field, new Long(value));
	}

	public SQuery<T> le(SFieldScalar field, double value) {
		return le(field, new Double(value));
	}

	public SQuery<T> le(SFieldScalar field1, SFieldMeta field2) {
		return fieldRelopParameter(field1, "<=", field2);
	}

	/** Just adds <code>fieldRelopParameter(field, "&gt;=", value)</code> */
	public SQuery<T> ge(SFieldScalar field, Object value) {
		return fieldRelopParameter(field, ">=", value);
	}

	public SQuery<T> ge(SFieldScalar field, int value) {
		return ge(field, new Integer(value));
	}

	public SQuery<T> ge(SFieldScalar field, long value) {
		return ge(field, new Long(value));
	}

	public SQuery<T> ge(SFieldScalar field, double value) {
		return ge(field, new Double(value));
	}

	public SQuery<T> ge(SFieldScalar field1, SFieldMeta field2) {
		return fieldRelopParameter(field1, ">=", field2);
	}

	/** Use or clause to simulate the in clause */
	public SQuery<T> in(SFieldScalar field, Object... values) {
        StringBuffer buf = new StringBuffer(100);
        
		buf.append(" IN (");
		for (int ii = 0; ii < values.length; ii++) {
            if (ii>0) buf.append(", ");
            buf.append("?");
    		rawParameter(values[ii]);        
		}
		buf.append(")");
        
        fieldQuery(field, buf.toString());
		return this;
	}


	/** Just adds <code>fieldRelopParameter(field, "like", value)</code> */
	public SQuery<T> like(SFieldScalar field, Object value) {
		return fieldRelopParameter(field, "like", value);
	}

	/** <code>rawOrderBy(field.columnName)</code> */
	public SQuery<T> ascending(SFieldMeta field) {
		return rawOrderBy(field, true);
	}

	/** <code>rawOrderBy(field.columnName) DESC</code> */
	public SQuery<T> descending(SFieldMeta field) {
		return rawOrderBy(field, false);
	}

    /** See SSession.queryToString for a fuller print out. */
	public String toString() {
		return "[SQuery " + record + "]";
	}
    
    /////////////////////////////// empty properties //////////////////
    public ArrayList<Object> getQueryParameters() {
		return queryParameters;
	}

    public List<SQuery.Join> getJoins() {
        return joins;
    }

    public OrderBy getOrderBy() {
        return orderBy;
    }

    public Where getWhere() {
        return where;
    }
        
	public SQueryMode getQueryMode() {
		return queryMode;
	}

    public String getRawSql() {
        return rawSql;
    }
       
    
}
