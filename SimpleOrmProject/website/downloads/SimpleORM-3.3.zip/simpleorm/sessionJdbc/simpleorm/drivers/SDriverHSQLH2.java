/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package simpleorm.drivers;

import simpleorm.dataset.SFieldScalar;
import simpleorm.dataset.SRecordMeta;
import simpleorm.sessionjdbc.SDriver;
import simpleorm.sessionjdbc.SGenerator;

/**
 * Common code between HSQL and H2.
 * Note that thewe toy databases do not
 * support locking, so is not safe in multi user mode even with optimistic
 * locking. See {@link SDriver#supportsLocking}.
 * @author aberglas
 */
public abstract class SDriverHSQLH2 extends SDriver {
    
    	/** HSQL has a major hole but optimisic locking papers over it.  H2 might support locking?*/
	@Override public boolean supportsLocking() {
		return false;
	}

	@Override protected String columnTypeSQL(SFieldScalar field, String defalt) {
		if (defalt.equals("BYTES"))
			return "BINARY"; // Ie. just a byte array.
		else
			return defalt;
	}

	@Override protected long generateKeySequence(SRecordMeta<?> rec, SFieldScalar keyFld) {
    	Object sequenceName = ((SGenerator)keyFld.getTheGenerator()).getName();

		String qry = "SELECT NEXT VALUE FOR " + (String) sequenceName
				+ " FROM DUAL"; // ### Dual!
		// Thanks elifarley. Note that HSQL also supports Identity.

		Object next = getSession().rawQuerySingle(qry, false);
		
		if (next == null)
			return 0;
		if (next instanceof Number)
			return ((Number) next).longValue();
		else
			return Long.parseLong(next.toString());
	}

	@Override public boolean supportsKeySequences() {
		return true;
	}

	@Override protected String createSequenceDDL(String name) {
		return "CREATE SEQUENCE " + name;
	}

	@Override protected String dropSequenceDDL(String name) {
		return "DROP SEQUENCE " + name;
	}

    @Override
    protected OffsetStrategy getOffsetStrategy() {
        return OffsetStrategy.QUERY;
//		return OffsetStrategy.JDBC;
    }

    @Override
    protected String limitSQL(long offset, long limit) {
        StringBuffer sb = new StringBuffer();
        if (limit != Integer.MAX_VALUE) sb.append(" LIMIT " + limit);
        if (offset > 0) sb.append(" OFFSET " + offset);
        return sb.toString();
    }

}
