package simpleorm.sessionjdbc;

import simpleorm.dataset.*;
import simpleorm.sessionjdbc.SSessionJdbc;
import simpleorm.utils.SException;

/**
 * Generate keys using rows in a separate sequence table. This should be done in
 * a separate transaction to avoid locking problems.<p>
 * 
 * One instance per SFieldMeta, ie. not per session or per driver.
 */

abstract public class SGenerator {
    SFieldScalar field;
	SRecordMeta<?> record;
	String generatorName = null;

	SGenerator(SFieldScalar field, String name) {
        this.field = field;
		this.record = field.getRecordMeta();
		this.generatorName = name;
	}
	
    public static  SGenerator theGenerator(SFieldScalar fld) {
        SGenerator gen = (SGenerator)fld.getTheGenerator();
        if (gen == null) {
            switch (fld.getGeneratorMode()) {
            case SSELECT_MAX: 
                gen = new SGeneratorSelectMax(fld, (String)fld.getGeneratorParameter()[0]); break;
            case SSEQUENCE: 
                gen = new SGeneratorSequence(fld, (String)fld.getGeneratorParameter()[0]); break;
            case SINSERT: 
                gen = new SGeneratorInsertIdentity(fld, (String)fld.getGeneratorParameter()[0]); break;
            }        
        fld.setTheGenerator(gen);
        }
        return gen;
    }

	public String getName() {
		return generatorName;
	}

	/**
	 * Create a new record with a generated key.
	 */
	SRecordInstance createWithGeneratedKey(SSessionJdbc session,SRecordMeta<?> meta,
			SFieldScalar keyField) {

		if (meta != record)
			throw new SException.Error("Inconsistent record metas " + record
					+ " !=" + meta);
		// / Generate the key.
		long gened = generateKey(session, meta,keyField);

		// / Create the new record.
		SRecordInstance newRec = session.create(meta, new Long(gened));

		if (session.getLogger().enableQueries())
			session.getLogger().queries("createWithGeneratedKey: " + newRec);

		return newRec;
	}

	/**
	 * Update instance with a newly generated key. For example, when reattaching
	 * a record. ### needs to be unified with createWithGeneratedKey! The hard
	 * one is the Insert Identity.
	 */
	void updateWithGeneratedKey(SSessionJdbc session, SRecordInstance instance, SFieldScalar keyField) {

		SRecordMeta<?> meta = instance.getMeta();
		if (meta != record)
			throw new SException.Error("Inconsistent record metas " + record
					+ " !=" + meta);

		// / Generate the key.
		long gened = generateKey(session, meta,keyField);

		instance.setLong(keyField, gened);

		if (session.getLogger().enableQueries())
			session.getLogger().queries("updateWithGeneratedKey: " + instance);
	}

	public abstract long generateKey(SSessionJdbc session, SRecordMeta<?> meta, SFieldScalar keyField);

	/**
	 * returns DDL required to support number generation, Eg. "CREATE SEQUENCE
	 * FOO..." Returns a string rather than just doing it so that the caller can
	 * create a DDL file if they want to.
	 */
	public String createDDL(SSessionJdbc session) {
		return null;
	}

	public String dropDDL(SSessionJdbc session) {
		return null;
	}
	
	SRecordMeta<?> getRecordMeta() {
		return record;
	}
}
