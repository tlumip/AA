package simpleorm.sessionjdbc;

import static simpleorm.sessionjdbc.SDriver.OffsetStrategy.JDBC;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import simpleorm.dataset.SFieldMeta;
import simpleorm.dataset.SFieldReference;
import simpleorm.dataset.SFieldScalar;
import simpleorm.dataset.SQuery;
import simpleorm.dataset.SQueryMode;
import simpleorm.dataset.SRecordInstance;
import simpleorm.dataset.SRecordMeta;
import simpleorm.dataset.SSelectMode;
import simpleorm.utils.SException;
import simpleorm.utils.SLog;

/**
 * Internal class to creates the SQL that corresponds to an SQuery.
 */
class SQueryExecute {
    SSessionJdbc session; 
    SQuery query;

	SFieldScalar[] scalarSelectList = null;

	String sqlQuery = null;

	PreparedStatement jdbcPreparedStatement = null;

	SQueryExecute(SSessionJdbc session, SQuery query) {
        this.session = session;
        this.query = query;
	}
    
    <RI extends SRecordInstance> List<RI> executeQuery() {
        session.statistics.incrementNrQueryDatabase();
        ResultSet rs = null;
        try {
            SFieldScalar[] selectSet = addJoinedSelectFields(query.getSelectList(), query.getJoinTables(), query.getRecordMeta());
            this.scalarSelectList = selectSet;

            // / Create the Query
            if (query.getRawSql() != null)
                this.sqlQuery = query.getRawSql();
            else
        		this.sqlQuery = session.getDriver().selectSQL(
                  scalarSelectList, query.getRecordMeta(), joinClause(), whereClause(), orderByClause(), query.getQueryMode() == SQueryMode.SFOR_UPDATE, this);

            prepareStatement(query.getQueryMode(), query.getQueryParameters());

            try {
                rs = jdbcPreparedStatement.executeQuery();
            } catch (Exception rsex) {
                throw new SException.Jdbc("Executing " + sqlQuery, rsex);
            }
            offsetResultSet(rs);
            ArrayList<SRecordInstance> al = new ArrayList();
            for (int ax = 0; ax < query.getLimit() && rsNext(rs); ax++) {
                SRecordInstance ri = findOrCreateFromResultSet(rs);
                ri.doQueryRecord();
                al.add(ri);
            }
            return (List<RI>) al;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (Exception cl1) {
                throw new SException.Jdbc("Closing rs ", cl1);
            }
            try {
                if (jdbcPreparedStatement != null) {
                    jdbcPreparedStatement.close();
                }
            } catch (Exception clp) {
                throw new SException.Jdbc("Closing ps ", clp);
            }

        }
    }
     
	private SFieldScalar[] addJoinedSelectFields(
        SFieldScalar[] selectList, Map<SRecordMeta<?>, SSelectMode> joinTables, SRecordMeta<?> mainMeta) {
		
		SFieldScalar[] result = selectList == null ? mainMeta.getQueriedScalarFields() : selectList;
		for (Map.Entry<SRecordMeta<?>, SSelectMode> entry : joinTables.entrySet()) {
			int resSize = result.length;
			if ( ! SSelectMode.SNONE.equals(entry.getValue())) {
				SFieldScalar[] joinFlds = entry.getKey().fieldsForMode(entry.getValue());
				// result = Arrays.copyOf(result, result.length+joinFlds.length); Not in 1.5
                SFieldScalar[] result2 = new SFieldScalar[result.length+joinFlds.length];
                System.arraycopy(result, 0, result2, 0, result.length);
//				for (int i = 0; i < joinFlds.length; i++) {
//					result[i+resSize] = joinFlds[i];
//				}
                System.arraycopy(joinFlds, 0, result2, result.length, joinFlds.length);                
                result = result2;
			}
		}
		return result;
	}

    SRecordMeta[] getJoinTables() {
		return (SRecordMeta[]) query.getJoinTables().keySet().toArray(new SRecordMeta[0]);
	}
	
	void prepareStatement(SQueryMode queryMode, List params) {
		if (session.getLogger().enableQueries())
			session.getLogger().queries("Selecting " 
                + session.sessionHelper.substituteToString(sqlQuery, params));

        try {
			// fro - see if we want a scrollable ResultSet. Beware these may be inefficient depending on the jdbc driver and DB 
			int RsType = ResultSet.TYPE_FORWARD_ONLY; 
			if (query.getOffset() != 0 
					&& session.getDriver().getOffsetStrategy().equals(JDBC)) {
				RsType = ResultSet.TYPE_SCROLL_INSENSITIVE;
			}
			jdbcPreparedStatement =	session.getJdbcConnection().prepareStatement(sqlQuery, RsType, ResultSet.CONCUR_READ_ONLY);
			// Let the JDBC driver cache these.
		} catch (Exception psex) {
			throw new SException.Jdbc("Preparing '" + sqlQuery + "'", psex);
		}
        for (int px = 0; px < params.size(); px++) {
                setObject(px + 1, params.get(px)); // ## may cause problems some JDBC
         }

	}

	void setObject(int parameterIndex, Object value) {
		try {
			jdbcPreparedStatement.setObject(parameterIndex, value);
		} catch (Exception se) {
			throw new SException.Jdbc("Setting " + this + " '?' "
					+ (parameterIndex), se);
		}
	}
	
        /**
	 * Called just after executeQuery to Skip over records until offset has been
	 * reached. Drivers may optimize this in various ways, eg. LIMIT keywords
	 * where supported by the database, or by using the JDBC
	 */
	protected void offsetResultSet(ResultSet rs) {
		try {          
            //System.err.println("initResSet " + getDriver().getOffsetStrategy() + query.getOffset());
			if ( SDriver.OffsetStrategy.JDBC.equals(getDriver().getOffsetStrategy()) && query.getOffset() != 0 ) {
				rs.setFetchDirection(ResultSet.FETCH_UNKNOWN);
				rs.absolute((int) query.getOffset()); // 1 is first row, 0 is before first row.
			} else if ( SDriver.OffsetStrategy.SCAN.equals(getDriver().getOffsetStrategy()) ){
                boolean next = true;
				for (int rx=0; next && rx< query.getOffset(); rx++) {
          			next = rs.next();
                }
            }
		} catch (Exception ex) {
			throw new SException.Jdbc(ex);
		}
	}
    
    private boolean rsNext(ResultSet rs) {
        try {
            return rs.next();
		} catch (Exception ex) { throw new SException.Jdbc(ex); }        
    }

    SRecordInstance findOrCreateFromResultSet(ResultSet rs) {
		// / Create New Instance. Too early to know if already in transCache.
                
        HashMap<SRecordMeta, SRecordInstance> instanceMap  = new HashMap<SRecordMeta, SRecordInstance>();

        instanceMap.put(query.getRecordMeta(), 
            session.getDataSet().newInstanceNotInDataSet(query.getRecordMeta()));
        // create join records
        SRecordMeta<?> refMeta;
        Set<SFieldReference> flds = query.getJoinFields();
        for (SFieldReference refField : flds) {
            refMeta = refField.getReferencedRecordMeta();
            instanceMap.put(refMeta, session.getDataSet().newInstanceNotInDataSet(refMeta));
        }

		// Retrieve the row into Records.
		for (SRecordInstance inst : instanceMap.values()) {
			session.sessionHelper.retrieveRecord(
                inst, scalarSelectList, rs, query.getQueryMode() == SQueryMode.SREAD_ONLY, false);
		}

		// Check to see if it is already in Transaction Cache
        SLog logger = session.getLogger();
		for (SRecordInstance inst : instanceMap.values()) {
            SRecordInstance cache = session.getDataSet().findUsingPrototype(inst);
            if ( cache == null 
                || session.sessionHelper.needsRequery(cache, query.getQueryMode() == SQueryMode.SREAD_ONLY, scalarSelectList)) {
				session.getDataSet().pokeIntoDataSet(inst);
				if (logger.enableQueries())
					logger.queries("getRecord: " + inst + " (from database)");
			}
			else { 
				instanceMap.put(inst.getMeta(), cache);
				if (cache.getDataSet() != session.getDataSet())
					throw new SException.Error("Inconsistent Connections " + cache
							+ cache.getDataSet() + session.getDataSet());
				if (logger.enableQueries())
					logger.queries("getRecord: " + cache + " (from cache)");
			}
		}
        // (DataSets can now find referenced records even if detached.
		return instanceMap.get(query.getRecordMeta());
	}

	String getSQL() {
		return sqlQuery;
	}
	
	protected String joinClause() {
		StringBuffer sb = new StringBuffer();
		List<SQuery.Join> joins = query.getJoins();
		// TODO only rawJoins are implemented for now.
		// Here will go left joins and so on, as soon as I get time.
		for (SQuery.Join jn : joins) {
			sb.append(jn.getAllRaw()).append("\n");
		}
		return sb.toString();
	}

    protected String whereClause() {
        SQuery.Where where = query.getWhere();
        StringBuffer res = new StringBuffer(50);
        doWhere(where, res);
        return res.length()>0?res.toString():null;
    }
    
    protected void doWhere(SQuery.Where where, StringBuffer res) {
        if (where == null) 
            ;
        else if (where.getAllRaw() != null) {
            res.append(" ("); res.append(where.getAllRaw()); res.append(") ");
        } else {
            if (where.getLeft() != null) {
                res.append("(");
                doWhere(where.getLeft(), res);
                res.append(")");
            } else {
                appendField(where.getLeftField(), res);
            }
            res.append(" ");
            res.append(where.getOperator());
            res.append(" ");
            if (where.getRight() != null) {
                res.append("(");
                doWhere(where.getRight(), res);
                res.append(")");
            } else {
                if (where.getRightRaw() != null) {
                    res.append(" "); res.append(where.getRightRaw()); res.append(" ");
                } else
                  appendField(where.getRightField(), res);
            }
        }
    }
    protected String orderByClause() {
        SQuery.OrderBy ob = query.getOrderBy();
        StringBuffer res = new StringBuffer(30);
        while (ob != null) {
            if (res.length() > 0) res.append(", ");
            if (ob.getRaw() != null)  
               res.append(ob.getRaw());
            else {
               SFieldScalar sclField = (SFieldScalar) ob.getField();
                appendField(sclField, res);
			   if (!ob.isAscending()) 
				  res.append(" DESC");
			}
            ob = ob.getNext();
		}
        return res.length()>0?res.toString():null;
    }
    
    /** For Debug etc. only */
    protected String queryToString(SQuery query) {
        String res = "[SQuerySql " + query.getRecordMeta() + " WHERE " 
            + whereClause() + " ORDER " + orderByClause() + "]";
        return res;
    }

    private void appendField(SFieldScalar sclField, StringBuffer res) {
        getDriver().appendTableName(sclField.getRecordMeta(), res);
        res.append(".");
        getDriver().appendColumnName(sclField, res);
    }
    
    SDriver getDriver() {return session.getDriver();}
    
    public SQuery getQuery() { return query;}
    
	public String toString() {
		return "[SPreparedStatement " + sqlQuery + "]";
	}
}