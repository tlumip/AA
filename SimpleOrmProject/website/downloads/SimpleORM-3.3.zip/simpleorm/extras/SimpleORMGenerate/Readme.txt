Richard Schmidt's SimpleORM QuickStart/Generator

This Utility can interrogate JDBC meta data of a pre-existing database and generate record definitions.

See the javadocs for details.

richard.schmidt@solution6.com
