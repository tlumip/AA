package simpleorm.examples;

import simpleorm.core.*;

/** This test class defines the Employee table */
public class Employee extends SRecordInstance 
implements java.io.Serializable {
	
	public static final SRecordMeta meta = 
		new SRecordMeta(Employee.class, "XX_EMPLOYEE");
	// ie. SRecord objects describe SRecordInstances
	
	public static final SFieldString EMPEE_ID = 
		new SFieldString(meta, "EMPEE_ID", 20, SCon.SFD_PRIMARY_KEY);
	
	public static final SFieldString NAME  = 
		new SFieldString(meta, "NAME", 40, SCon.SFD_DESCRIPTIVE, SCon.SFD_MANDATORY);
	
	public static final SFieldString PHONE_NR = 
		new SFieldString(meta, "PHONE_NR", 20);
	
	public static final SFieldDouble SALARY = 
		new SFieldDouble(meta, "SALARY");
	
	public static final SFieldInteger NR_DEPENDENTS = 
		new SFieldInteger(meta, "NR_DEPENDENTS");
	
	static final SFieldReference DEPARTMENT = 
		new SFieldReference(meta, Department.meta, null);
	//SCon.SEXTRA_FKEY_DDL.pvalue(" Junk To test"));
	
	static final SFieldReference MANAGER = // Recursive Reference
		new SFieldReference(meta, Employee.meta, "MANAGER_");
	
	static final SFieldString RESUME = // Curriculam Vitae
		new SFieldString(meta, "RESUME", 200, SCon.SFD_UNQUERIED);
	// Not normally retrieved.
	
	static final SFieldString DEPT_NAME =
		new SFieldString(meta, "DEPT_NAME", 100, SCon.SFD_UNQUERIED,
				SCon.SCOLUMN_QUERY.pvalue(
				"(SELECT NAME FROM XX_DEPARTMENT D WHERE D.DEPT_ID = XX_EMPLOYEE.DEPT_ID)"));
	
	
	public SRecordMeta getMeta() { return meta; }; // specializes abstract method
	
	public static Employee findOrCreate(String empeeId) { // Convenience
		return (Employee)meta.findOrCreate(empeeId);
	}
	
	/** Called when the Salary is setDouble()d. */
	public void validateField(SFieldMeta field, Object newValue) {
		if (field == SALARY) {
			double sal = newValue==null?0:((Number)newValue).doubleValue();
			if (sal < 0)
				throw new SValidationException(
						"Salary {0} < 0.", SJSharp.newDouble(sal));
		}
	}
	
	/** Called when the record is flushed, and so both Departent and
	 Salary will have been set. */
	public void validateRecord() {
		if (isValid(SALARY)) {
			double sal = getDouble(SALARY);
			Department dept = (Department)getReference(DEPARTMENT);
			if (dept != null) {
				double max = dept.getDouble(Department.MAX_SALARY);
				if (sal > max)
					throw new SValidationException(
							"Salary {0} is greater than the Departments Maximum {1}.",
							new Object []{SJSharp.newDouble(sal), SJSharp.newDouble(max)},
							this); // Always add the record instance for validate record.
			}
		}
	}
}

