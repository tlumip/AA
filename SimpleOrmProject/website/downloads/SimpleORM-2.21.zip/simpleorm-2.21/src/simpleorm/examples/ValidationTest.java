package simpleorm.examples;

import simpleorm.core.*;
// .* OK, all classes prefixed with "S".

/** Tests validation, OnFieldValidate etc. 
 *  (Basic validation test is also in ADemo/Employee.)
 * */

public class ValidationTest implements SConstants {
	
	static public class Validated extends SRecordInstance 
	implements java.io.Serializable {
		
		public static final SRecordMeta meta = 
			new SRecordMeta(Validated.class, "XX_VALIDATED");
		
		public static final SFieldString VALID_ID = 
			new SFieldString(meta, "VALID_ID", 20, SCon.SFD_PRIMARY_KEY);
		
		public static final SFieldString NAME  = 
			new SFieldString(meta, "NAME", 40, SCon.SFD_DESCRIPTIVE);
		
		public static final SFieldString PHONE_NR = 
			new SFieldString(meta, "PHONE_NR", 20);
		
		public static final SFieldDouble SALARY = 
			new SFieldDouble(meta, "SALARY");
		
		static final SFieldReference MANAGER = // Recursive Reference
			new SFieldReference(meta, Validated.meta, "MANAGER_");
				
		public SRecordMeta getMeta() { return meta; }; // specializes abstract method
				
		Object salary, validId, name; // Only used for tests.
		
		/** Called when the Salary is setDouble()d. */
		public void validateField(SFieldMeta field, Object newValue) {
			SLog.slog.fields("Validated.field " + field + " := " + newValue);
			if (field == VALID_ID) {
				validId = newValue;
			}
			if (field == NAME) {
				name = newValue;
			}
			if (field == SALARY) {
				salary = newValue;
				double sal = newValue==null?0:((Number)newValue).doubleValue();
				if (sal < 0)
					throw new SValidationException(
							"Salary {0} < 0.", SJSharp.newDouble(sal));
			}
		}
		
		boolean validated = false;
		/** Called when the record is flushed, and so both Departent and
		 Salary will have been set. */
		public void validateRecord() {
			SLog.slog.fields("Validated.record " + this);
			validated = true;
			if (isValid(SALARY)) {
				double sal = getDouble(SALARY);
				//Department dept = (Department)getReference(DEPARTMENT);
				//if (dept != null) {
					//double max = dept.getDouble(Department.MAX_SALARY);
				  double max = 100000;
					if (sal > max)
						throw new SValidationException(
								"Salary {0} is greater than the Departments Maximum {1}.",
								new Object []{SJSharp.newDouble(sal), SJSharp.newDouble(max)},
								this); // Always add the record instance for validate record.
				
			}
		}
	} // Validated

	public static void main(String[] argv) throws Exception {
		TestUte.initializeTest(ValidationTest.class); // Look at this code.
		try {
			testInit();
			validationTest();
		} finally {
			SConnection.detachAndClose();
		}
	}
	
	/** Prepare for tests, Delete old data. */
	static void testInit() throws Exception {
		System.out.println("################ Init #################");
		SConnection.begin();
		
		/// Delete any old data from a previous run.
		TestUte.dropAllTables();
		
		SConnection.rawUpdateDB(Validated.meta.createTableSQL());
		
		SConnection.commit();
	}
	
	static void validationTest() { // Foreign Keys
		System.out.println("################ validationTest #################");
		SConnection.begin();
			
		/// Create a validated
		SDataLoader vldDL = new SDataLoader(Validated.meta);
		Validated[] recs  = (Validated[])vldDL.insertRecords(new Object[][]{
				{"100", "One00", "123 456 7890", "10000", null},
				{"200", "Too00", "123 456 7890", "10000", null}
		});
		
		assertTrue("Too00".equals(recs[1].name));
		assertTrue("100".equals(recs[0].validId));
		
		recs[1].validated = false;
		SConnection.commit();
		assertTrue(recs[1].validated);
		SConnection.begin();
			
		/// Create empty v300
		Validated v300 = (Validated)Validated.meta.create("300"); //new
		assertTrue("300".equals(v300.validId)); 
		SConnection.flush();
		assertTrue(v300.validated); // despite no non-key fields set.

		/// Non-creation of empty v400.
		Validated v400 = (Validated)Validated.meta.findOrCreate("400"); //new
		assertTrue("400".equals(v400.validId));
		// v400.setDirty()   needed to make record dirty and thus insert.  cf. create(keys).
		SConnection.flush();
		assertTrue(! v400.validated); 

		/// Attempt to pay e200 -ve is traped immediately.
		Validated e200 = (Validated)Validated.meta.findOrCreate("200");
		try {
			e200.setDouble(e200.SALARY, -1);
			throw new SException.Test("Negative Salary not detected.");
		} catch (SValidationException ve) {
			SLog.slog.message("Salary Negative message: " + ve.getMessage());
		}
		
		/// Attempt to pay e200 too much is detected at Commit/Flush time.
		e200.setDouble(e200.SALARY, 500000);
		try {
			SConnection.commit();
			throw new SException.Test("Big Salary not detected.");
		} catch (SValidationException ve) {
			SLog.slog.message(
					"Big Salary message: " + ve.getRecordInstance() + ve.getMessage());
			SConnection.rollback();
		}
		
	}
	
	static void assertTrue(boolean cond) {TestUte.assertTrue(cond);}
}
