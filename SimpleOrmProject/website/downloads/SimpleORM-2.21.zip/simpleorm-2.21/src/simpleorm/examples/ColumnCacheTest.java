package simpleorm.examples;

import simpleorm.core.*; // .* OK, all classes prefixed with "S".
import java.io.*;

/** Tests and demonstrates selective column queries, locking and
 flushing details as well as derived columns and joins.  Note
 that care is taken to trap attempts to access unqueried fields
 and so prevent errors that could otherwise be the source of
 nasty bugs as the application scales.*/
public class ColumnCacheTest implements SConstants {
	
	public static void main(String[] argv) throws Exception {
		TestUte.initializeTest(ColumnCacheTest.class); // Look at this code
		try {
			TestUte.createDeptEmp();
			findOrCreateTest();
			selectTest();
			referenceTest();
			updateOrderTest();
			columnQueryTest();
		} finally {
			SConnection.detachAndClose();
		}
	}
	
	static void findOrCreateTest() {
		SConnection.begin();
		
		/// Employee.RESUME not normally retrieved, need to explicitly query.
		/// Firs create a Resume.  Setting unqueried fields is OK.
		Employee e100a = (Employee)Employee.meta.findOrCreate("100");
		String res = "My life is but a walking shadow ... signifying nothing.";
		e100a.setString(e100a.RESUME, res);
		
		SConnection.commit();
		SConnection.begin();
		
		/// Trap attempt to access unqueried RESUME
		Employee e100b = (Employee)Employee.meta.findOrCreate("100");
		try {
			e100b.getString(e100b.RESUME); // Unqueried;
			throw new SException.Test("Unqueried Resume not trapped");
		} catch (SException.Error re) {
			SLog.slog.message("Get Failure " + re);
		}
		
		/// Retrieve it properly and check value.
		Employee e100c = (Employee)Employee.meta.findOrCreate("100", SQY_UNQUERIED);
		// This actually issues a query to get the extra column.
		TestUte.assertTrue(res.equals(e100c.getString(e100b.RESUME)));
		TestUte.assertTrue(e100b == e100c);
		
		try {
			e100b.setString(e100b.EMPEE_ID, "XXX"); // Primary Key
			throw new SException.Test("Set Primary Key not trapped");
		} catch (SException.Error ke) {
			SLog.slog.message("Key Failure " + ke);
		}
		
		SConnection.commit();
		SConnection.begin();
		
		
		/// Retrieve a record without Lokcing and try to update or delete it.
		Department d100a = (Department)Department.meta.findOrCreate(
				"100", SQY_READ_ONLY);
		try {
			d100a.setString(d100a.NAME, "OOPS"); // Should fail
			throw new SException.Test("Set unlocked record " + d100a);
		} catch (SException.Error se) {
			SLog.slog.message("Set Failure " + se);
		}
		try {
			d100a.deleteRecord(); // Should fail
			throw new SException.Test("Deleted unlocked record " + d100a);
		} catch (SException.Error de) {
			SLog.slog.message("Delete Failure " + de);
		}
		
		/// Try to update a non-queried for update field
		Department d100b = (Department)Department.meta.findOrCreate(
				"100", SQY_DESCRIPTIVE);
		d100b.setString(d100b.NAME, "One00a"); // OK, queried and locked
		d100b.getDouble(d100b.BUDGET);         // OK, queried but not locked
		if (d100a != d100b) 
			throw new SException.Test("Diff Depts " + d100a + d100b);
		try {
			d100b.setDouble(d100b.BUDGET, 666); // Should fail
			throw new SException.Test("Update unlocked field " + d100b);
		} catch (SException.Error e) {}
		
		Department d100c = (Department)Department.meta.findOrCreate("100");
		d100b.setDouble(d100b.BUDGET, 1234); // Should finally be OK
		
		/// Create a new Record.  Can update fields because new, so we
		/// reliably know the values of all columns (null, or default
		/// later).
		Department d900 = (Department)Department.meta.findOrCreate(
				"900", SQY_DESCRIPTIVE);
		d900.assertNewRow();
		
		d900.setString(d900.NAME, "Five00"); 
		
		SConnection.flush(); // Inserts DEPT_ID, NAME
		
		d900.setDouble(d900.BUDGET, 777); // OK because new record.
		SConnection.commit(); // Updates BUDGET only.
		
		SConnection.begin();
		
		Department d900a = (Department)Department.meta.findOrCreate("900");
		if (d900a.getDouble(d900a.BUDGET) != 777)
			throw new SException.Test("Bad Budget " + d900a);
		
		SConnection.commit();
		SConnection.begin();
		
		/// Use an explicit list of fields
		Department d200a = (Department)Department.meta.findOrCreate(
				"200", 0, new SFieldMeta[]{Department.BUDGET});
		try {
			d200a.getString(d200a.NAME); // Should fail
			throw new SException.Test("Get unqueried record " + d200a);
		} catch (SException.Error g2e) {
			SLog.slog.message("Set Failure " + g2e);
		}
		TestUte.assertTrue(d200a.getDouble(d200a.BUDGET) == 20000);
		
		
		SConnection.commit();
		
	}
	
	static void selectTest() {
		SConnection.begin();
		
		SResultSet res = Department.meta.newQuery(SQY_DESCRIPTIVE | SQY_READ_ONLY)
		.gt(Department.BUDGET, SJSharp.newInteger(10000))
		.descending(Department.NAME)
		.execute();
		res.hasNext();
		Department dept = (Department)res.getRecord();
		dept.getString(dept.NAME); // OK
		try {
			dept.getString(dept.BUDGET); // Unqueried;
			throw new SException.Test("Unqueried Budget not trapped");
		} catch (SException.Error ge) {
			SLog.slog.message("Get Failure " 
					+ dept + " " + dept.getString(dept.NAME) + " " + ge);
		}
		try {
			dept.setString(dept.NAME, "XXX"); // ReadOnly;
			throw new SException.Test("ReadONLY not trapped");
		} catch (SException.Error se) {
			SLog.slog.message("Set Failure " 
					+ dept + " " + dept.getString(dept.NAME) + " " + se);
		}
		
		
		SConnection.commit();
	}
	
	/** Test partial queries of references. */
	static void referenceTest() {
		SConnection.begin();
		{
			Employee e100a = (Employee)Employee.meta.findOrCreate("100",0,
					new SFieldMeta [] {Employee.DEPARTMENT});
			
			Department d100a = (Department)e100a.getReference(e100a.DEPARTMENT);
			TestUte.assertTrue("D100".equals(d100a.getString(d100a.NAME)));
			
			try {
				e100a.getString(e100a.SALARY); // Unqueried;
				throw new SException.Test("Unqueried Salary not trapped");
			} catch (SException.Error se) {
				SLog.slog.message("Get Failure " + se);
			}
			
			Department d200a = (Department)Department.meta.findOrCreate("200");
			e100a.setReference(e100a.DEPARTMENT, d200a);
		}
		
		SConnection.commit();
		SConnection.begin();
		
		{
			Employee e100b = (Employee)Employee.meta.findOrCreate("100", SQY_READ_ONLY,
					new SFieldMeta [] {Employee.DEPARTMENT});
			
			Department d200b = (Department)e100b.getReference(e100b.DEPARTMENT);
			TestUte.assertTrue("D200".equals(d200b.getString(d200b.NAME)));
			
			try {
				Department d300a = (Department)Department.meta.findOrCreate("300");
				e100b.setReference(e100b.DEPARTMENT, d300a);
				throw new SException.Test("Read Only Dept not trapped");
			} catch (SException.Error sde) {
				SLog.slog.message("Set Failure " + sde);
			}
		}
		
		SConnection.commit();
		SConnection.begin();
		
		{
			Employee e100r = (Employee)Employee.meta.findOrCreate("100");
			Department dept = (Department)e100r.getReference(
					e100r.DEPARTMENT, SQY_DESCRIPTIVE);
			TestUte.assertTrue("D200".equals(dept.getString(dept.NAME)));
			
			try {
				dept.getString(dept.BUDGET);
				throw new SException.Test("Descriptive Dept not trapped");
			} catch (SException.Error dre) {
				SLog.slog.message("Get Descr Failure " + dre);
			}
		}
		
		SConnection.commit();
		
	}
	
	/** Make sure referenced records are updated first. */
	static void updateOrderTest() {
		SConnection.begin();
		
		Department d800a = (Department)Department.meta.findOrCreate("800");
		d800a.assertNewRow();
		//d800a.setDirty(); // To avoid the exception.   Or set the depts name!
		
		Employee e300c = (Employee)Employee.meta.findOrCreate("300");
		e300c.setDouble(e300c.SALARY, 0);
		try {
			e300c.setReference(e300c.DEPARTMENT, d800a); 
			throw new SException.Test("Bad FKey update order not trapped");
		} catch (SException.Error re) {
			SLog.slog.message("RSet Failure " + re);
		}
		
		Department d700a = (Department)Department.meta.findOrCreate("700");
		d700a.assertNewRow();
		d700a.setDirty(); // Check no errors with just key set.
		
		SConnection.commit();
		SConnection.begin();
		
		Department d700b = (Department)Department.meta.findOrCreate("700");
		d700b.assertNotNewRow();
		d700b.setDirty(); // Trap empty UPDATE ... SET WHERE... 
		
		SConnection.commit();
	}
	
	/** Test SCOLUMN_QUERY */
	static void columnQueryTest() {
		SConnection.begin();
		
		Employee e100 = (Employee)Employee.meta.findOrCreate("100", SQY_UNQUERIED);
		String dname = e100.getString(e100.DEPT_NAME);
		TestUte.assertTrue("D200".equals(dname));
		
		try {
			e100.setString(e100.DEPT_NAME, "Changed"); 
			throw new SException.Test("Attempt to set read only Dept_Name not trapped");
		} catch (SException.Error se) {
			SLog.slog.message("Set Failure " + se);
		}
		
		SConnection.commit();
		SConnection.begin();
		
		SResultSet res = Employee.meta.newQuery(SQY_UNQUERIED)
		.eq(Employee.EMPEE_ID, "100").execute();
		res.hasNext(1);
		Employee e100b = (Employee)res.getRecord();
		String dname2 = e100b.getString(e100.DEPT_NAME);
		TestUte.assertTrue("D200".equals(dname2));    
		res.hasNext(1);
		
		SConnection.commit();
	}
}



