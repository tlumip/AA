package simpleorm.examples;

import simpleorm.core.*; // .* OK, all classes prefixed with "S".
import java.sql.*;
import java.util.Random;
import java.util.HashMap;

/** Basic benchmarks that compare SimpleORM performance to raw JDBC.
 No significant degedation has been found.  See the whitepaper for a
 full description of the tests and results.<p>
 */


public class Benchmarks implements SConstants {
	
	final static int nrRows = 1000;
	static long startTime;
	static double timeTaken;
	
	public static void main(String[] argv) throws Exception {
		TestUte.initializeTest(Benchmarks.class); // Look at this code.
		try {
			SLog.slog.level = 0;
			//rawTests();
			testInit();
			jdbcInsert();
			jdbcQuerySequential();
			jdbcQueryRandom();
			jdbcQueryField();
			jdbcUpdateRandom();
			jdbcUpdateBulk();
			
			testInit();
			simpleormInsert();
			simpleormQuerySequential();
			simpleormQueryRandom();
			simpleormQueryField();
			simpleormUpdateRandom();
			simpleormUpdateBulk();
		} finally {
			SConnection.detachAndClose();
		}
	}
	
	/** Rough simulation of key SimpleORM steps. */
	static void rawTests() {
		SConnection.begin();
		startTime = System.currentTimeMillis();
		HashMap hm = new HashMap();
		for (int hx=0; hx<nrRows*10; hx++){
			// Empty Loop
			//foo("zz");
			String key = "that " + hx; // 0.004 ms
			hm.put(key, "YYYY"); // 0.005 ms (inlc str concat)
			hm.get(key); // 0.002 ms
			//Connection con = SConnection.getBegunJDBCConnection();
		}
		SLog.slog.message("rawTests " + timeTaken());
	}
	static boolean foo(String bar){return (bar.equals("xxx"));}
	
	/** Prepare for tests, Delete old data. */
	static void testInit() throws Exception {
		SLog.slog.message("Initializing");
		SConnection.begin();
		
		/// Delete any old data from a previous run.
		try {
			SConnection.rawUpdateDB("DROP TABLE XX_EMPLOYEE");
			SConnection.rawUpdateDB("DROP TABLE XX_DEPARTMENT");
		} catch (SException.JDBC ex) {};  // Tables may not exist.
		SConnection.rawUpdateDB(Department.meta.createTableSQL());
		SConnection.rawUpdateDB(Employee.meta.createTableSQL());
		
		SDataLoader deptDL = new SDataLoader(Department.meta);
		deptDL.insertRecords(new Object[][]{
				{"D100", "One00", "Count Pennies", "10000", "200000"},
				{"D200", "Two00", "Be Happy", "20000", "150000"},
				{"D300", "Three00", "Enjoy Life", "30000", "100000"}});
		
		SConnection.commit();
	}
	
	static double theTotSal;
	static double insertTime;
	static void jdbcInsert() throws Exception {
		SConnection.begin();
		Connection con = SConnection.getBegunDBConnection();
		startTime = System.currentTimeMillis();
		
		PreparedStatement insp = con.prepareStatement(
		"INSERT INTO XX_EMPLOYEE (EMPEE_ID, NAME, PHONE_NR, SALARY, NR_DEPENDENTS, DEPT_ID) VALUES (?, ?, ?, ?, ?, ?)");
		
		double totSal = 0;
		for (int row=0; row < nrRows; row++) {
			insp.setString(1, row + 1000000 + "");
			insp.setString(2, "Name " + row);
			insp.setString(3, "(123) 456 789");
			insp.setDouble(4, row * 100);
			totSal += row * 100;
			insp.setInt(   5, row % 4);
			insp.setString(6, "D" + ((row % 3)+1) + "00");
			insp.executeUpdate();
		}
		
		SConnection.commit();
		SLog.slog.message("jdbcInsert " + timeTaken() + " " + totSal);
		insertTime = timeTaken;
		theTotSal = totSal;
	}
	
	static void simpleormInsert() throws Exception {
		startTime = System.currentTimeMillis();
		SConnection.begin();
		
		double totSal = 0;
		for (int row=0; row < nrRows; row++) {
			Employee insp = (Employee)Employee.meta.findOrCreate(
					row + 1000000 + "", SQY_ASSUME_CREATE);
			insp.setString(Employee.NAME, "Name " + row);
			insp.setString(Employee.PHONE_NR, "(123) 456 789");
			insp.setDouble(Employee.SALARY, row * 100);
			totSal += row * 100;
			insp.setInt(   Employee.NR_DEPENDENTS, row % 4);
			insp.setReference(Employee.DEPARTMENT, 
					(Department)Department.meta.findOrCreate(
							"D" + ((row % 3)+1) + "00"));
		}
		
		SConnection.commit();
		SLog.slog.message("simpleormInsert " + timeTaken()  + " " + totSal);
		TestUte.assertTrue(totSal == theTotSal);
		timeAssert(timeTaken < insertTime * 2);
	}
	
	static double seqTime;
	static double theTotBud = 0;
	static void jdbcQuerySequential() throws Exception {
		SConnection.begin();
		Connection con = SConnection.getBegunDBConnection();
		startTime = System.currentTimeMillis();
		
		PreparedStatement selp = con.prepareStatement(
		"SELECT EMPEE_ID, E.NAME, PHONE_NR, SALARY, NR_DEPENDENTS, BUDGET FROM XX_EMPLOYEE E, XX_DEPARTMENT D WHERE E.DEPT_ID = D.DEPT_ID"); 
		// Warning: this is an inner join.  A better query on most DBMSs
		// is to use a subsect which will effectively produce an outer join.
		
		ResultSet rs1 = selp.executeQuery();
		double totSal=0;
		while (rs1.next()) {
			String id = rs1.getString(1);
			String name = rs1.getString(2);
			String phone = rs1.getString(3);
			double sal = rs1.getDouble(4);
			totSal += sal;
			int deps = rs1.getInt(5);
			double bud = rs1.getDouble(6);
			theTotBud += bud;
		}
		rs1.close();
		
		SConnection.commit();
		SLog.slog.message(
				"jdbcQuerySequential " + timeTaken() + " " + totSal + " " + theTotBud);
		seqTime = timeTaken;
		TestUte.assertTrue(totSal == theTotSal);
	}
	
	static void simpleormQuerySequential() throws Exception {
		startTime = System.currentTimeMillis();
		SConnection.begin();
		
		SPreparedStatement selp = Employee.meta.select((String)null, null);
		SResultSet rs1 = selp.execute();
		double totSal=0;
		double totBud=0;
		while (rs1.hasNext()) {
			Employee emp = (Employee)rs1.getRecord();
			String id = emp.getString(Employee.EMPEE_ID);
			String name = emp.getString(Employee.NAME);
			String phone = emp.getString(Employee.PHONE_NR);
			double sal = emp.getDouble(Employee.SALARY);
			totSal += sal;
			int deps = emp.getInt(Employee.NR_DEPENDENTS);
			Department dept = (Department)emp.getReference(emp.DEPARTMENT);
			double bud = dept.getDouble(dept.BUDGET);
			totBud += bud;
		}
		
		SConnection.commit();
		SLog.slog.message(
				"simpleormQuerySequential " + timeTaken()  
				+ " " + totSal + " " + totBud);
		TestUte.assertTrue(totSal == theTotSal);
		TestUte.assertTrue(totBud == theTotBud);
		timeAssert(timeTaken < seqTime * 2);
	}
	
	static double theRandTotSal;
	static double randTime;
	static void jdbcQueryRandom() throws Exception {
		SConnection.begin();
		Connection con = SConnection.getBegunDBConnection();
		startTime = System.currentTimeMillis();
		
		PreparedStatement selp = con.prepareStatement(
		"SELECT NAME, PHONE_NR, SALARY, NR_DEPENDENTS FROM XX_EMPLOYEE WHERE EMPEE_ID = ?");
		
		Random rand = new Random(0);
		double totSal=0;
		for (int row=0; row < nrRows; row++) {
			int key = (rand.nextInt() & 0x7FFFFFFF) % nrRows + 1000000;
			selp.setInt(1, key);
			ResultSet rs1 = selp.executeQuery();
			if (!rs1.next()) throw new SException.Test("Could not find " + key);
			String name = rs1.getString(1);
			String phone = rs1.getString(2);
			double sal = rs1.getDouble(3);
			totSal += sal;
			int deps = rs1.getInt(4);
			rs1.close();
		}
		
		SConnection.commit();
		SLog.slog.message("jdbcQueryRandom " + timeTaken() + " " + totSal);
		randTime = timeTaken;
		theRandTotSal = totSal;
	}
	
	static void simpleormQueryRandom() throws Exception {
		startTime = System.currentTimeMillis();
		SConnection.begin();
		
		Random rand = new Random(0);
		double totSal=0;
		for (int row=0; row < nrRows; row++) {
			int key = (rand.nextInt() & 0x7FFFFFFF) % nrRows + 1000000;
			Employee emp = (Employee)Employee.meta.findOrCreate(key+"");
			String id = emp.getString(Employee.EMPEE_ID);
			String name = emp.getString(Employee.NAME);
			String phone = emp.getString(Employee.PHONE_NR);
			double sal = emp.getDouble(Employee.SALARY);
			totSal += sal;
			int deps = emp.getInt(Employee.NR_DEPENDENTS);
		}
		
		SConnection.commit();
		SLog.slog.message("simpleormQueryRandom " + timeTaken()  + " " + totSal);
		TestUte.assertTrue(totSal == theRandTotSal);
		timeAssert(timeTaken < randTime);
	}
	
	static double fieldTime;
	static void jdbcQueryField() throws Exception {
		SConnection.begin();
		Connection con = SConnection.getBegunDBConnection();
		
		PreparedStatement selp = con.prepareStatement(
		"SELECT NAME, PHONE_NR, SALARY, NR_DEPENDENTS FROM XX_EMPLOYEE WHERE EMPEE_ID = ?");
		
		double totSal=0;
		selp.setInt(1, 1000000);
		ResultSet rs1 = selp.executeQuery();
		rs1.next();
		startTime = System.currentTimeMillis();
		for (int row=0; row < nrRows*10; row++) {
			String name = rs1.getString(1);
			String phone = rs1.getString(2);
			double sal = rs1.getDouble(3);
			totSal += sal;
			int deps = rs1.getInt(4);
		}
		rs1.close();
		
		SConnection.commit();
		SLog.slog.message("jdbcQueryField " + timeTaken() + "/10 " + totSal);
		fieldTime = timeTaken;
	}
	
	static void simpleormQueryField() throws Exception {
		SConnection.begin();
		
		double totSal=0;
		Employee emp = (Employee)Employee.meta.findOrCreate("1000000");
		startTime = System.currentTimeMillis();
		for (int row=0; row < nrRows*10; row++) {
			String id = emp.getString(Employee.EMPEE_ID);
			String name = emp.getString(Employee.NAME);
			String phone = emp.getString(Employee.PHONE_NR);
			double sal = emp.getDouble(Employee.SALARY);
			totSal += sal;
			int deps = emp.getInt(Employee.NR_DEPENDENTS);
		}
		
		SConnection.commit();
		SLog.slog.message("simpleormQueryField " + timeTaken()  + "/10 " + totSal);
		timeAssert(timeTaken < fieldTime * 2);
	}
	
	static double theUpdTotSal;
	static double rupdTime;
	static void jdbcUpdateRandom() throws Exception {
		SConnection.begin();
		Connection con = SConnection.getBegunDBConnection();
		startTime = System.currentTimeMillis();
		
		PreparedStatement selp = con.prepareStatement(
		"UPDATE XX_EMPLOYEE SET SALARY = ? WHERE EMPEE_ID = ?");
		
		Random rand = new Random(1);
		double totSal=0;
		for (int row=0; row < nrRows; row++) {
			int key = (rand.nextInt() & 0x7FFFFFFF) % nrRows + 1000000;
			selp.setInt(2, key);
			double sal = key - 1000000;
			totSal += sal;
			selp.setInt(1, key);
			selp.executeUpdate();
		}
		
		SConnection.commit();
		SLog.slog.message("jdbcUpdateRandom " + timeTaken() + " " + totSal);
		theUpdTotSal = totSal;
		rupdTime = timeTaken;
	}
	
	static void simpleormUpdateRandom() throws Exception {
		startTime = System.currentTimeMillis();
		SConnection.begin();
		
		Random rand = new Random(1);
		double totSal=0;
		for (int row=0; row < nrRows; row++) {
			int key = (rand.nextInt() & 0x7FFFFFFF) % nrRows + 1000000;
			Employee emp = (Employee)Employee.meta.findOrCreate(key+"");
			double sal = key - 1000000;
			totSal += sal;
			emp.setDouble(emp.SALARY, sal);
		}
		
		SConnection.commit();
		SLog.slog.message("simpleormUpdateRandom " + timeTaken()  + " " + totSal);
		TestUte.assertTrue(totSal == theUpdTotSal);
		timeAssert(timeTaken < rupdTime);
	}
	
	static void jdbcUpdateBulk() throws Exception {
		SConnection.begin();
		Connection con = SConnection.getBegunDBConnection();
		startTime = System.currentTimeMillis();
		
		PreparedStatement selp = con.prepareStatement(
		"UPDATE XX_EMPLOYEE SET SALARY = SALARY * 0.1");
		selp.executeUpdate();
		
		SConnection.commit();
		SLog.slog.message("jdbcUpdateBulk " + timeTaken());
	}
	
	static void simpleormUpdateBulk() throws Exception {
		SConnection.begin();
		Connection con = SConnection.getBegunDBConnection();
		startTime = System.currentTimeMillis();
		
		SConnection.rawUpdateDB(
		"UPDATE XX_EMPLOYEE SET SALARY = SALARY * 0.1");
		
		SConnection.commit();
		SLog.slog.message("simpleormUpdateBulk " + timeTaken());
	}
	
	static String timeTaken() { 
		timeTaken =(System.currentTimeMillis() - startTime + 0.0) / nrRows;
		return timeTaken + "";
	}
	
	/** Makes timeing assertions, but only for PostgreSQL.  Other
	 databases vary, especially HSQL with its in memory/checkpointing
	 model. */
	static void timeAssert(boolean test) {
		if (SConnection.getDriver() instanceof SDriverPostgres && !test)
			throw new SException.Test("Result is too slow for Postgres?");
	}
	
}



