package simpleorm.examples;

import simpleorm.core.*;
import java.sql.*;
import java.io.*;

/** 
 This provides a basic test of foreign key references and in
 particular identifying foreign keys.  The internal data structures
 created by these record definitions is illustrated in the following
 diagram which may be useful.
 
 <img src="../../extraDocs/SOrmEgUML.png"> */
public class ReferenceTest {
	public static void main(String[] argv) throws Exception {
		TestUte.initializeTest(ReferenceTest.class);
		System.err.println(XX.meta.allFieldsString());
		System.err.println(YY.meta.allFieldsString());
		System.err.println(ZZ.meta.allFieldsString());
		createTables();
		SConnection.detachAndClose();
	}
	
	
	
	/** Helper that just creates the createdb.sql script file for the
	 database.  This can be referenced as part of the build process.*/
	static void createTables() throws Exception {
		
		//File file = new File("createdb.sql");
		//FileOutputStream fis = new FileOutputStream(file);
		PrintStream out = System.out;  //new PrintStream(fis);
		out.println(XX.meta.createTableSQL() + ";\n");
		out.println(YY.meta.createTableSQL() + ";\n");
		out.println(ZZ.meta.createTableSQL() + ";\n");
		
		//out.close();
	}
	
	public static class YY extends SRecordInstance implements SConstants {
		
		public static final SRecordMeta meta = 
			new SRecordMeta(YY.class, "XX_YY");
		
		static final SFieldReference XXR = 
			new SFieldReference(meta, XX.meta, null, SFD_PRIMARY_KEY);
		
		public static final SFieldString YY_ID = 
			new SFieldString(meta, "YY_ID", 10, SFD_PRIMARY_KEY);
		
		public static final SFieldString YNAME  = 
			new SFieldString(meta, "YNAME", 10, SFD_DESCRIPTIVE);
		
		public SRecordMeta getMeta() { return meta; }; 
	}
	public static class ZZ extends SRecordInstance implements SConstants {
		
		public static final SRecordMeta meta = 
			new SRecordMeta(ZZ.class, "XX_ZZ");
		
		static final SFieldReference YYR = 
			new SFieldReference(meta, YY.meta, "", SFD_PRIMARY_KEY);
		
		public static final SFieldInteger ZZ_ID = 
			new SFieldInteger(meta, "ZZ_ID", SFD_PRIMARY_KEY);
		
		public static final SFieldString YNAME  = 
			new SFieldString(meta, "ZNAME", 10, SFD_DESCRIPTIVE);
		
		public SRecordMeta getMeta() { return meta; }; 
	}
	public static class XX extends SRecordInstance implements SConstants {
		
		public static final SRecordMeta meta = 
			new SRecordMeta(XX.class, "XX_XX");
		
		public static final SFieldInteger XX_ID = 
			new SFieldInteger(meta, "XX_ID", SFD_PRIMARY_KEY);
		
		public static final SFieldString XNAME  = 
			new SFieldString(meta, "XNAME", 10, SFD_DESCRIPTIVE);
		
		public SRecordMeta getMeta() { return meta; }; 
	}
	
}



