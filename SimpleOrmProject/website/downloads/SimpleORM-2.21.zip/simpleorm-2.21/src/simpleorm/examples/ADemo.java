package simpleorm.examples;

import simpleorm.core.*; // .* OK, all classes prefixed with "S".

/** <b>START HERE</b> -- this class provides basic examples of the
 main SimpleORM features.  It demonstrates simple record
 manipulations including non-identifying foreign keys.<p>
 */

public class ADemo implements SConstants {
	
	public static void main(String[] argv) throws Exception {
		TestUte.initializeTest(ADemo.class); // Look at this code.
		try {
			testInit();
			deptTest();
			empTest();
		} finally {
			SConnection.detachAndClose();
		}
	}
	
	/** Prepare for tests, Delete old data. */
	static void testInit() throws Exception {
		System.out.println("################ Init #################");
		SConnection.begin();
		
		/// Delete any old data from a previous run.
		TestUte.dropAllTables();
		
		/// Suppress FOREIGN KEY DDL for this example only, can cause problems on some DBs.
		if (true)
			SConnection.getConnection().setPropertyValue(SFD_NO_FOREIGN_KEY);
		
		//SConnection.commit();
		//SConnection.begin();
		
		/// Create the tables.
		SConnection.rawUpdateDB(Department.meta.createTableSQL());
		
		SConnection.rawUpdateDB(Employee.meta.createTableSQL());
		
		SConnection.commit();
	}
	
	/** Basic examples/tests not involving foreign keys. */
	static void deptTest() throws Exception {
		System.out.println("################ deptTest #################");
		SConnection.begin();
		
		/// Create some Departments using the SDataLoader
		SDataLoader deptDL = new SDataLoader(Department.meta);
		
		deptDL.insertRecords(new Object[][]{
				{"100", "One00", "Count Pennies", "10000", "200000"},
				{"200", "Two00", "Be Happy", "20000", "300000"},
				{"300", "Three00", "Enjoy Life", "30000", "150000"}});
		
		/// Flush the records to the database and commit the transaction.
		SConnection.commit();
		SConnection.begin();
		
		/// Retrieve a Department and check that we have the right one.
		String key = "100";
		Department department = (Department)Department.meta.mustFind(key);
		assertTrue(department.getString(Department.NAME).equals("One00"));
		
		/// Query the same Department again.  This does not query the database.
		Department department2 = (Department)Department.meta.find("100");
		assertTrue(department == department2);
		
		/// Create a new, empty department and set some column values.
		Department newDept = 
			(Department)Department.meta.create("900");
		newDept.setString(Department.NAME, "New900");
		newDept.setString(Department.BUDGET, "90000");
		
		SConnection.dumpCache(); 
		SConnection.flush(); // To the database
		SConnection.dumpCache();
		
		/// At this point there should be three departments with > $10,000.
		selectDepartments(20000+30000+90000);
		
		/// Rollback new 900 Department.  Flush() does not mean commit.
		SConnection.rollback();
		SConnection.dumpCache();
		
		SConnection.begin();
		
		/// Delete Department 300.  
		/// findOrCreate will (temporarily) create record 300 if it did not exist.
		Department delDept = 
			(Department)Department.meta.findOrCreate("300");
		delDept.deleteRecord();
		
		SConnection.commit();
		SConnection.begin();
		
		/// Check only one department left > $10,000.
		selectDepartments(20000);
		
		SConnection.commit();
	}
	
	/** Query all the departments with Budget > 10000 and check that the
	 total budget == total.*/
	static void selectDepartments(int total) {
		
		int qbudget = 10000;
		
		/// Prepare and execute the query.  The two queries are identical,
		//  but one uses raw SQL and the other uses the query builder.
		SResultSet res = null;
		if (true) { // Query interface style
			res = Department.meta.newQuery()
			.gt(Department.BUDGET, SJSharp.newInteger(qbudget))
			.descending(Department.NAME)
			.execute();
		} else { // Direct SQL Style
		SPreparedStatement stmt = Department.meta.select("BUDGET > ?", "NAME DESC");
		stmt.setInt(1, qbudget);
		res = stmt.execute();
		}
		
		/// loop through the results, adding up the budgets.
		double totBudget = 0;
		while (res.hasNext()) {
			Department dept = (Department)res.getRecord();
			double budget = dept.getDouble(Department.BUDGET);
			totBudget += budget;
		}
		
		/// Check that the total is what we expect.
		assertTrue(totBudget == total);
	}
	
	/**
	 Examples non identifying foreign key relationship
	 from Employee to Department, and from Employee to
	 Employee.Manager. */
	static void empTest() { // Foreign Keys
		System.out.println("################ empTest #################");
		SConnection.begin();
		
		/// Dump all the fields in the Employee record.  Note that the
		/// DEPT_ID is included even though it is not explicitly part of the
		/// Employee record's definition.
		System.out.println("Employee Fields " 
				+ Employee.meta.allFieldsString());
		
		/// Create an Employee
		SDataLoader empDL = new SDataLoader(Employee.meta);
		Employee e100 = (Employee)empDL.insertRecord(new Object[]{
				"100", "One00", "123 456 7890", "10000", "3", null, null});
		
		/// Explicitily set the Department
		Department d100 = (Department)Department.meta.findOrCreate("100");
		e100.setReference(e100.DEPARTMENT, d100);
		// Compare allFields() with the concise toString() that just shows keys.
		System.out.println("e100#" + e100.allFields());
		
		/// Create more Employees setting the Department using the DataLoader
		Department d200 = (Department)Department.meta.findOrCreate("200");
		empDL.insertRecords(new Object[][]{ // Twice should not cause grief
				{"200", "Two00",   "123 456 7890", "20000", "0",  d200, e100},
				{"300", "Three00", "123 456 7890", "30000", "1",  null, e100}});
		
		SConnection.flush();
		
		Employee e300 = (Employee)Employee.meta.newQuery()
		.eq(Employee.NAME, "Three00")
		.execute().getOnlyRecord();
		assertTrue("123 456 7890".equals(e300.getString(e300.PHONE_NR)));
		
		SConnection.commit();
		SConnection.begin();
		
		/// Check e100 record NOT valid after a commit() 
		/// (locks released so need to requery).
		try {
			e100.getString(Employee.NAME); // Error as e100 destroyed by commit.
			throw new SException.Test("e100 not destroyed.");
		} catch (SException.Error er) {
			SLog.slog.message(
					"Destroyed Record Message: " + er);
		}
		
		/// Retrieve e100's Department.
		Employee e100a = (Employee)Employee.meta.findOrCreate("100");
		Department d100a = (Department)e100a.getReference(e100a.DEPARTMENT);
		assertTrue(d100a.getString(Department.NAME).equals("One00"));
		
		
		/// Attempt to pay e200 -ve is traped immediately.
		Employee e200 = (Employee)Employee.meta.findOrCreate("200");
		try {
			e200.setDouble(e200.SALARY, -1);
			throw new SException.Test("Negative Salary not detected.");
		} catch (SValidationException ve) {
			SLog.slog.message("Salary Negative message: " + ve.getMessage());
		}
		
		/// Attempt to pay e200 too much is detected at Commit/Flush time.
		e200.setDouble(e200.SALARY, 500000);
		try {
			SConnection.commit();
			throw new SException.Test("Big Salary not detected.");
		} catch (SValidationException ve) {
			SLog.slog.message(
					"Big Salary message: " + ve.getRecordInstance() + ve.getMessage());
			SConnection.rollback();
		}
		
	}
	
	static void assertTrue(boolean cond) {TestUte.assertTrue(cond);}
}
