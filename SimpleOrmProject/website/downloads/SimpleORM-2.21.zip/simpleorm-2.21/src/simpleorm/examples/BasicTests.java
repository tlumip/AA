package simpleorm.examples;

import simpleorm.core.*; // .* OK, all classes prefixed with "S".
import java.util.HashMap;
import java.util.ArrayList;

/** Similar to ADemo tests, but with more assertions.
 */

public class BasicTests implements SConstants {
	
	public static void main(String[] argv) throws Exception {
		// SLog.level = 20; //Uncomment to reduce trace output.
		TestUte.initializeTest("BasicTests", true); // use deprecated attach.
		try {
			createDeptEmp();
			deptTest();
			empTest();
			metaTest();
			queryTest();
		} finally {
			SConnection.detachAndClose();
		}
	}
	
	/** Prepare for tests, Delete old data. */
	static void createDeptEmp() throws Exception {
		SLog.slog.message("################ CreateDeptEmp #################");
		SConnection.begin();
		
		TestUte.dropAllTables();
		SConnection.rawUpdateDB(Department.meta.createTableSQL());
		SConnection.rawUpdateDB(Employee.meta.createTableSQL());
		
		SConnection.commit();
	}
	
	/** Basic examples/tests not involving foreign keys. */
	static void deptTest() throws Exception {
		SLog.slog.message("################ deptTest #################");
		SConnection.begin();
		
		/// Create some Departments using the SDataLoader
		SDataLoader deptDL = new SDataLoader(Department.meta);
		Department d2 = (Department)deptDL.insertRecord(new String[]{
				"100", "One00XX", "Count Pennies", "10000", "200000"});
		SConnection.flush(); // SQL Insert
		d2.setString(d2.NAME, "One00"); // Causes SQL Update. 
		deptDL.insertRecords(new Object[][]{
				{"200", "Two00", "Be Happy", "20000", "150000"},
				{"300", "Three00", "Enjoy Life", "30000", "300000"}});
		
		SConnection.commit();
		SConnection.begin();
		
		/// Retrieve a Department and check that we have the right one.
		String key = "100";
		Department department = 
			(Department)Department.meta.findOrCreate(key);
		department.assertNotNewRow();
		
		/// Retrieve the Name using explicit meta data.
		HashMap deptMap = (HashMap)Department.meta.getProperty(SFIELD_MAP);
		SFieldMeta deptName = (SFieldMeta)deptMap.get("NAME");
		SFieldMeta deptName2 = Department.meta.getField("NAME");
		TestUte.assertTrue(deptName == deptName2);
		String name  = department.getString(deptName);
		if (!"One00".equals(name)) throw new Exception("Dept Name " + name);
		TestUte.assertEqual("NAME", Department.NAME.getString(SSimpleORMProperties.SCOLUMN_NAME));
		
		/// Query the same Department again.  This does not query the database.
		String oo = "1";
		String key2 = oo + "00"; // don't want it == key
		TestUte.assertTrue(!department.wasInCache());
		Department department2 = 
			(Department)Department.meta.findOrCreate(key2);
		TestUte.assertTrue(department2.wasInCache());
		if (department != department2) throw new Exception(
				"Departments not identical" + department + department2);
		
		/// Create a new, empty department and set some column values.
		Department newDept = 
			(Department)Department.meta.findOrCreate("900");
		newDept.assertNewRow();
		newDept.setString(Department.NAME, "New900");
		newDept.setString(Department.BUDGET, "90000");
		
		SConnection.flush();
		
		/// At this point there should be three departments with > $10,000.
		selectDepartments(20000+30000+90000);
		
		/// Rollback new 900 Department.  Flush() does not mean commit.
		SConnection.rollback();
		
		SConnection.begin();
		
		/// Delete Department 300
		Department delDept = 
			(Department)Department.meta.findOrCreate("300");
		delDept.deleteRecord();
		
		/// Insert and then Delete Department 500 -- ie do nothing.
		Department insDelDept = 
			(Department)Department.meta.findOrCreate("500");
		insDelDept.setString(Department.BUDGET, "666");
		insDelDept.deleteRecord(); // No SQL generated.
		
		SConnection.commit();
		SConnection.begin();
		
		/// Check only one department left > $10,000.
		selectDepartments(20000);
		selectDepartments(20000 + 10);
		
		SConnection.commit();
		SConnection.begin();
		
		selectDepartments(20000 + 20); // Now updated.
		
		SArrayList al = Department.meta.select("BUDGET > 10000", "NAME")
		.execute().getArrayList(1000);
		if (al.size() != 1)
			throw new SException.Test("Wrong ArrayList size " + al.size());
		
		SConnection.commit();
	}
	
	/** Query all the departments with Budget > 10000 and check that the
	 total budget == total.
	 This uses the lower level SQL interface, 
	 ADemo does the same thing using the Query interface. */
	static void selectDepartments(int total) {
		
		/// Prepare and execute the query.  See QueryTest.java for the query builder.
		SPreparedStatement stmt = Department.meta.select("BUDGET > ?", "NAME DESC");
		stmt.setDouble(1, 10000);
		SResultSet res = stmt.execute();
		
		/// loop through the results, adding up the budgets.
		double totBudget = 0;
		while (res.hasNext()) {
			Department dept = (Department)res.getRecord();
			double budget = dept.getDouble(Department.BUDGET);
			SLog.slog.message("DEPARTMENT: " + dept.getString(Department.NAME)
					+ " $" + budget);
			totBudget += budget;
			dept.setDouble(dept.BUDGET, budget+10);
		}
		
		/// Check that the total is what we expect.
		if (totBudget != total)
			throw new SException.Test("Wrong Total " + totBudget);
	}
	
	/**
	 Examples/Tests of the (non identifying) foreign key relationship
	 from Employee to Department, and from Employee to
	 Employee.Manager. */
	static void empTest() { // Foreign Keys
		SLog.slog.message("################ empTest #################");
		SConnection.begin();
		
		/// Dump all the fields in the Employee record.  Note that the
		/// DEPT_ID is included even though it is not explicitly part of the
		/// Employee record's definition.
		SLog.slog.message("Employee Fields " 
				+ Employee.meta.allFieldsString());
		
		TestUte.assertEqual((String)Employee.meta.sFieldNames.get(9), "RESUME");
		
		/// Create an Employee
		SDataLoader empDL = new SDataLoader(Employee.meta);
		Employee e100 = (Employee)empDL.insertRecord(new Object[]{
				"100", "One00", "123 456 7890", "10000", "3", null, null});
		
		/// Explicitily set the Department
		Department d100 = (Department)Department.meta.findOrCreate("100");
		Department d200 = (Department)Department.meta.findOrCreate("200");
		
		e100.setReference(e100.DEPARTMENT, d200);
		
		/// Retrieve the Department using explicit meta data.
		SFieldReference deptRef = (SFieldReference)Employee.meta.getField("XX_DEPARTMENT");
		Department dept1 = (Department)e100.getReference(deptRef);
		if (!dept1.getString(d100.NAME).equals("Two00"))
			throw new SException.Test("Bad Dept Two00 " + e100 + dept1);
		
		/// Null the Departent
		e100.setReference(e100.DEPARTMENT, null);
		Department dept2 = (Department)e100.getReference(e100.DEPARTMENT);
		if (dept2 != null)
			throw new SException.Test("Bad Dept Null " + e100 + dept2);
		
		/// And reassign it.
		e100.setReference(e100.DEPARTMENT, d100);
		Department dept3 = (Department)e100.getReference(e100.DEPARTMENT);
		if (!dept3.getString(d100.NAME).equals("One00"))
			throw new SException.Test("Bad Dept One00 " + e100 + dept3);
		
		SLog.slog.message("e100#" + e100.allFields());
		
		/// Create more Employees setting the Department using the DataLoader
		Employee[] emps1 = (Employee[])empDL.insertRecords(new Object[][]{
				{"200", "Two00",   null, null, "0",  null, e100},
				{"300", "Three00", "123 456 7890", "31000", "1",  d200, e100}});
		if ( emps1[0].getString(Employee.PHONE_NR)!= null 
				|| emps1[0].getInt(   Employee.SALARY) != 0 // 0 for null follows JDBC
				|| !emps1[0].isEmpty( Employee.SALARY)
				|| emps1[0].getObject(Employee.SALARY) != null)
			throw new SException.Test("Bad Employee Nulls" + emps1[0]);
		empDL.insertRecords(new Object[][]{ // Twice should not cause grief
				{"200", "Two00",   "123 456 7890", "20000", "0",  d200, e100},
				{"300", "Three00", "123 456 7890", "30000", "1",  null, e100}});
		
		/// Check e100 still valid after a flush()
		SConnection.flush();
		if (!e100.getString(Employee.NAME).equals("One00"))
			throw new SException.Test("Flush() corrupted " + e100);
		
		SConnection.commit();
		SConnection.begin();
		
		/// Check e100 record NOT valid after a commit() 
		/// (locks released so need to requery).
		try {
			e100.getString(Employee.NAME); // Error as e100 destroyed by commit.
			throw new SException.Test("e100 not destroyed.");
		} catch (SException.Error er) {} // We want an exception here.
		
		/// Retrieve e100 again, and show all its field values.
		/// Compare allFields() with the concise toString() that just shows keys.
		Employee e100a = (Employee)Employee.meta.findOrCreate("100");
		SLog.slog.message("e100a#" + e100a.allFields());    
		
		/// Get the referenced d100 Department.  Noe that the SQL query
		/// only happens here.
		Department d100a = (Department)e100a.getReference(e100a.DEPARTMENT);
		SLog.slog.message("d100a#" + d100a.allFields());    
		
		/// Change an Employee's manager, creating a loop, and check.
		Employee e300 = (Employee)Employee.meta.findOrCreate("300");
		e100a.setReference(e100a.MANAGER, e300);
		// So e200, e300 --> e100; e100 --> e300; ie. a loop, OK.
		Employee e100b = (Employee)e300.getReference(e300.MANAGER);
		if (e100b != e100a) 
			throw new SException.Test("e300.getReference " + e100a + e300 + e100b);
		
		/// Check database updated correctly, this time using rawQueryJDBC().
		SConnection.flush();
		Object salSum = SConnection.rawQueryDB(
				"SELECT SUM(M.SALARY) FROM XX_EMPLOYEE M, XX_EMPLOYEE E " +
		" WHERE M.EMPEE_ID = E.MANAGER_EMPEE_ID ");
		
		//"SELECT SUM("   // No Subselects in MySQL
		//+ "  (SELECT SALARY FROM XX_EMPLOYEE M "
		//+ "    WHERE M.EMPEE_ID = E.MANAGER_EMPEE_ID)) "
		//+ "FROM XX_EMPLOYEE E"); // Sum of all manager's salary.
		if (((Number)salSum).intValue() != 10000+10000+30000)
			throw new SException.Test("Bad Mgr Salary sum " + salSum);
		
		SConnection.commit();
	}
	
	/** Test of meta data and properties. */
	static void metaTest() {
		SFieldMeta empeeId = Employee.meta.getField("EMPEE_ID");
		TestUte.assertTrue(empeeId == Employee.EMPEE_ID);
		Integer size = (Integer)empeeId.getProperty(SBYTE_SIZE);
		TestUte.assertTrue(size.intValue() == 20);
				
		
		SFieldMeta mgr = Employee.MANAGER;
		int idx = SJSharp.object2Int(mgr.getProperty(SFIELD_INDEX));
		SRecordMeta emp = (SRecordMeta)mgr.getProperty(SRECORD_META);
		SFieldMeta [] flds = (SFieldMeta [])emp.getProperty(SFIELD_METAS);
		TestUte.assertTrue(mgr == flds[idx]);
	}
	
	static void queryTest() {
		SConnection.begin();
		
		/// BUDGET > ?, IN
		SQuery deptq = Department.meta.newQuery()
		.gt(Department.BUDGET, SJSharp.newInteger(1234))
		//.and()
		.lt(Department.NAME, "J")
		.in(Department.DEPT_ID, new Object[] {"100", "200"})
		.descending(Department.NAME);
		TestUte.assertEqual(deptq.toString(), 
		"[SQuery [SRecordMeta Department] XX_DEPARTMENT.\"BUDGET\" > ? AND XX_DEPARTMENT.\"NAME\" < ? AND XX_DEPARTMENT.\"DEPT_ID\"  IN ( ? ,  ? )  BY XX_DEPARTMENT.\"NAME\" DESC]");

        /// Mission -- mixed case
        SQuery deptqCase = Department.meta.newQuery()
        .eq(Department.MISSION,  "Be Happy").ascending(Department.MISSION);
        SResultSet deptqCaseR = deptqCase.execute();
        deptqCaseR.hasNext(1);
        Department d200m = (Department)deptqCaseR.getRecord();
        TestUte.assertEqual(d200m.getString(d200m.NAME), "Two00");

        /// Simple Foreign Key
		Department d100 = (Department)Department.meta.findOrCreate("100");
		Department d200 = (Department)Department.meta.findOrCreate("200");
		SQuery empdeptq = Employee.meta.newQuery()
		.eq(Employee.DEPARTMENT, d100)
		.ne(Employee.DEPARTMENT, d200)
		.isNotNull(Employee.DEPARTMENT); // silly query just for testing
		//empdeptq.putProperty(SQOFFSET, 10);
		//empdeptq.putProperty(SQLIMIT, 20);
		
		TestUte.assertEqual(empdeptq.toString(),
		"[SQuery [SRecordMeta Employee] ( XX_EMPLOYEE.\"DEPT_ID\" = ? ) AND ( XX_EMPLOYEE.\"DEPT_ID\" <> ? ) AND ( XX_EMPLOYEE.\"DEPT_ID\" IS NOT NULL )  BY ]");
		SResultSet empdr = empdeptq.execute();
		empdr.hasNext(1);
		Employee e100 = (Employee)empdr.getRecord();
		TestUte.assertEqual(e100.getString(e100.NAME), "One00");
		
		// Join test
		SQuery joinQ = Employee.meta.newQuery()
		.join(Employee.DEPARTMENT)
		.eq(Department.NAME, "One00");
		TestUte.assertEqual(joinQ.toString(),
		"[SQuery [SRecordMeta Employee] ( XX_EMPLOYEE.\"DEPT_ID\" = XX_DEPARTMENT.\"DEPT_ID\" ) AND XX_DEPARTMENT.\"NAME\" = ?  BY ]");
		SResultSet joinR = joinQ.execute();
		joinR.hasNext(1);
		Employee e100Q = (Employee)joinR.getRecord();
		TestUte.assertEqual(e100Q.getString(e100Q.NAME), "One00");   
		
		// offset/limit tests
		SPreparedStatement limitps = new SPreparedStatement();
		limitps.setOffset(1);
		limitps.setLimit(1);
		SResultSet limitR = Employee.meta.newQuery()
		.ascending(Employee.EMPEE_ID)
		.execute(limitps);
		double sum=0;
		while (limitR.hasNext()) {
			Employee eeLimit = (Employee)limitR.getRecord();
			//SLog.slog.debug(
			//  "Limit " + eeLimit.getString(eeLimit.NAME) + " " 
			//  + eeLimit.getDouble(eeLimit.SALARY));
			sum += eeLimit.getDouble(eeLimit.SALARY);
		}
		TestUte.assertTrue(sum == 20000);
		
		SConnection.commit();
	}
}
