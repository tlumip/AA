
package simpleorm.examples;

import simpleorm.core.*;
import simpleorm.properties.*;

/** This test class defines the Payroll tables as static inner tables
 which demonstrate identifying foreign keys. */
public class Payroll {
	
	static public class Period extends SRecordInstance {
		
		public static final SRecordMeta meta = 
			new SRecordMeta(Period.class, "XX_PAY_PERIOD");
		
		public static final SFieldInteger YEAR = 
			new SFieldInteger(meta, "YEAR", SCon.SFD_PRIMARY_KEY);
		
		public static final SFieldInteger PERIOD = 
			new SFieldInteger(meta, "PERIOD", SCon.SFD_PRIMARY_KEY);
		
		public static final SFieldDouble TOTAL_PAYROLL = 
			new SFieldDouble(meta, "TOTAL_PAYROLL");
		
		public SRecordMeta getMeta() { return meta; };
	}
	
	static public class PaySlip extends SRecordInstance {
		
		public static final SRecordMeta meta = 
			new SRecordMeta(PaySlip.class, "XX_PAY_SLIP");
		
		static final SFieldString INCONSISTENT_EMP_NR = // not recommended
			new SFieldString(meta, "INCONSIST_EMP_NR", 20, SCon.SFD_PRIMARY_KEY);
		
		static final SFieldReference EMPLOYEE = 
			new SFieldReference(meta, Employee.meta,
					new SFieldMeta[]{INCONSISTENT_EMP_NR},
					new SPropertyValue [] {SCon.SFD_PRIMARY_KEY, 
					SCon.SFIELD_NAME.pvalue("INCONS")}); // Name for Foreign Key Constraint etc.
		
		static final SFieldReference PERIOD = 
			new SFieldReference(meta, Period.meta,
					(String)null, SCon.SFD_PRIMARY_KEY);
		
		//static final SFieldReference PAYSLIP = 
		//  new SFieldReference(meta, PaySlip.meta,
		//    (String)null, SFD_PRIMARY_KEY);
		
		public static final SFieldString COMMENTS = 
			new SFieldString(meta, "COMMENTS", 200);
		
		public SRecordMeta getMeta() { return meta; };
	}
	
	
	static public class PaySlipDetail extends SRecordInstance {
		
		public static final SRecordMeta meta = 
			new SRecordMeta(PaySlipDetail.class, "XX_PSLIP_DTL");
		
		static final SFieldReference PAY_SLIP = 
			new SFieldReference(meta, PaySlip.meta,
					(String)null, SCon.SFD_PRIMARY_KEY, SCon.SFD_INNER_FOREIGN_KEY);
		
		public static final SFieldInteger DETAIL_TYPE = // Should be Enum
			new SFieldInteger(meta, "DETAIL_TYPE", SCon.SFD_PRIMARY_KEY);
		
		public static final SFieldDouble VALUE = 
			new SFieldDouble(meta, "VALUE");
		
		public SRecordMeta getMeta() { return meta; };
	}
	
	
	static public class UglyPaySlipDetail extends SRecordInstance {
		
		public static final SRecordMeta meta = 
			new SRecordMeta(UglyPaySlipDetail.class, "XX_UGLY_PAY_DTL");
		
		static final SFieldString UGLY_EMP_NR =
			new SFieldString(meta, "UGLY_EMP_NR", 20, SCon.SFD_PRIMARY_KEY);
		
		static final SFieldReference EMPLOYEE = 
			new SFieldReference(meta, PaySlip.EMPLOYEE,
					new SFieldMeta[]{UGLY_EMP_NR},
					new SPropertyValue [] {SCon.SFD_PRIMARY_KEY, 
					SCon.SFIELD_NAME.pvalue("UGLYEMP")});
		
		static final SFieldReference PERIOD = 
			new SFieldReference(meta, PaySlip.PERIOD,
					(String)null, new SPropertyValue[]{SCon.SFD_PRIMARY_KEY});
		
		static final SFieldReference PAY_SLIP = 
			new SFieldReference(meta, PaySlip.meta,
					new SFieldMeta[]{EMPLOYEE, PERIOD},
					new SPropertyValue [] {SCon.SFD_PRIMARY_KEY, SCon.SFD_INNER_FOREIGN_KEY,
					SCon.SFIELD_NAME.pvalue("UGLY_PAYSLIP")});
		
		public static final SFieldInteger DETAIL_TYPE = // Should be Enum
			new SFieldInteger(meta, "DETAIL_TYPE", SCon.SFD_PRIMARY_KEY);
		
		public static final SFieldDouble VALUE = 
			new SFieldDouble(meta, "VALUE");
		
		public SRecordMeta getMeta() { return meta; };
	}
}
