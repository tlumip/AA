package simpleorm.examples;

import simpleorm.core.*; // .* OK, all classes prefixed with "S".
import java.io.*;

/** Demonstrates Cache/locking issues, in particular a long, user interaction
 transaction (optimistic locking), thread test.<p>
 
 An Employee record is read, and then detatched.  It is then
 serialized to a file and read back to simulate its journey to
 another tier.  It is then modified, and reattached to a SimpleORM
 connection.<p>  */
public class LongTransactionTest implements SConstants {
	
	public static void main(String[] argv) throws Exception {
		TestUte.initializeTest(LongTransactionTest.class); // Look at this code
		try {
			TestUte.createDeptEmp();
			basicOptimisticTest();
			longTest();
			detatchTest();
			flushAndPurgeTest();
			threadTest();
			whereNullTest();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			SConnection.detachAndClose();
		}
	}
	
	/** Basic single record optimistic tests. */
	public static void basicOptimisticTest() throws Exception{
		SLog.slog.message("################ BasiciOptimisiticTest #################");
		SConnection.begin();
		
		Department d=null;
		
		Department dept400 = (Department)Department.meta.select(
				"DEPT_ID = 400", null).execute().getOnlyRecord();
		
		dept400.detach();
		dept400.detach(); // Not an error.
		SConnection.commit();
		
		SConnection.detachAndClose();
		
		/// Update dept400 in detached state.
		dept400.setDouble(dept400.BUDGET, 50000); // Same as Dept500
		
		TestUte.initializeTest(LongTransactionTest.class);
		SConnection.begin();
		
		dept400 = (Department)dept400.attach();
		TestUte.assertTrue(dept400.isDirty());
		
		/// Check double flushing OK
		SConnection.flush();
		SConnection.commit();
		
		/// Check that the update really happened.
		SConnection.begin();
		TestUte.assertTrue(((Number)SConnection.rawQueryJDBC(
		"SELECT BUDGET FROM XX_DEPARTMENT WHERE DEPT_ID = '400'")).intValue()
		== 50000);
		SConnection.commit();
		
		
		/// Now check breaking a lock with update.
		SConnection.begin();
		Department d400 = (Department)Department.meta.findOrCreate(
				"400", SQY_OPTIMISTIC);
		d400.setDouble(Department.BUDGET, 3333);
		
		// Break the lock.  This could be happening in another transaction.
		SConnection.rawUpdateDB(
		"UPDATE XX_DEPARTMENT SET BUDGET = 4444 WHERE DEPT_ID = 400");
		
		try {
			SConnection.commit();
			throw new SException.Test("Broken Optimistic Lock Update not detected.");
		} catch (SRecordInstance.BrokenOptimisticLockException beu) {}
		
		SConnection.rollback();
		
		/// Now check breaking a lock with delete.
		SConnection.begin();
		Department d400d = (Department)Department.meta.findOrCreate(
				"400", SQY_OPTIMISTIC);
		d400d.deleteRecord();
		
		// Break the lock.  This could be happening in another transaction.
		SConnection.rawUpdateDB(
		"UPDATE XX_DEPARTMENT SET BUDGET = 444 WHERE DEPT_ID = 400");
		
		try {
			SConnection.commit();
			throw new SException.Test("Broken Optimistic Lock Delete not detected.");
		} catch (SRecordInstance.BrokenOptimisticLockException bed) {}
		
		SConnection.rollback();
	}
	
	
	
	/** Detatach and seriealize before loading and reattaching, do multi
	 record detach.  More vigourous test. */
	public static void longTest() throws Exception{
		/// Query Employee 200 and detatch it.
		SLog.slog.message("################ LongTransTest #################");
		SConnection.begin();
		
		// Ceck getReferenceNoQuery && IsDirty
		Employee emp200 = (Employee)Employee.meta.findOrCreate("200");
		Object d200NoQ1 = emp200.getReferenceNoQuery(emp200.DEPARTMENT);
		Object d200NoQ2 = emp200.getReferenceNoQuery(emp200.DEPARTMENT);
		TestUte.assertTrue(d200NoQ1 == Boolean.FALSE && d200NoQ2 == Boolean.FALSE);
		Department dept200 =
			(Department)emp200.getReference(emp200.DEPARTMENT);
		Object d200NoQ3 = emp200.getReferenceNoQuery(emp200.DEPARTMENT);
		TestUte.assertTrue(d200NoQ3 == dept200);
		TestUte.assertTrue(!emp200.isDirty(emp200.DEPARTMENT));
		emp200.setReference(emp200.DEPARTMENT, dept200);
		TestUte.assertTrue(!emp200.isDirty(emp200.DEPARTMENT));
		
		
		Employee emp100 =
			(Employee)emp200.getReference(emp200.MANAGER);
		dept200.detach();
		emp200.detach();
		emp200.detach(); // Not an error.
		// Note that emp100 is not detatched.
		SConnection.commit();
		SConnection.detachAndClose();
		
		/// Serialize the Employee.  This also serializes the
		// referenced and detatched department but not the non-retrieved
		// manager.  This may change, see white paper.
		
		File file = new File("../temp/serialized.tmp");
		
		System.out.println("Serializing...");
		FileOutputStream out = new FileOutputStream(file);
		ObjectOutputStream outs = new ObjectOutputStream(out);
		outs.writeObject(emp200); // Will also write dept200 but not emp100.
		outs.flush();
		out.close();
		
		// Send the the Employee far away...and bring it back.
		
		/// DeSerialize
		FileInputStream in = new FileInputStream(file);
		ObjectInputStream ins = new ObjectInputStream(in);
		Employee emp2 = (Employee)ins.readObject();
		in.close();
		TestUte.assertTrue(emp200 != emp2);
		
		/// Update the Employee, say from a user input.
		emp2.getDouble(emp2.SALARY);
		emp2.setDouble(emp2.SALARY, 2222);
		
		
		/// Create a new Employee while still detached
		Employee e800 = (Employee)Employee.meta.createDetached("800");
		e800.setString(Employee.NAME, "New800");
		
		
		/// The Departement Record is available
		Department dept2 =
			(Department)emp2.getReference(emp2.DEPARTMENT); // OK
		TestUte.assertTrue("D200".equals(dept2.getString(dept2.NAME)));
		TestUte.assertTrue(!dept2.isAttached());
		
		/// But the Manger record is not available
		try {
			emp2.getReference(emp2.MANAGER); // Should Fail
			throw new SException.Test(
			"Could get unattached Manager sithout a begun transaction.");
		} catch (SException.Error se) {}
		
		/// Although the key used for the reference is still available.
		TestUte.assertTrue(
				emp2.getString(emp2.meta.getField("MANAGER_EMPEE_ID")).equals("100"));
		
		/// Attach the Employee and flush.
		TestUte.initializeTest(LongTransactionTest.class);
		SConnection.begin();
		
		emp2 = (Employee)emp2.attach(); // recursively attaches dept200
		TestUte.assertTrue(emp2.isDirty());
		TestUte.assertTrue(emp2.getDouble(emp2.SALARY) == 2222);
		SLog.slog.debug(emp2.allFields());
		
		TestUte.assertTrue(dept2.isAttached()); // by emp2.attach.
		Employee mgr = (Employee)emp2.getReference(emp2.MANAGER); // OK Now
		TestUte.assertTrue("One00".equals(mgr.getString(mgr.NAME)));
		
		Object [] e200q = (Object [])SConnection.rawQueryDB(
				"SELECT * FROM XX_EMPLOYEE WHERE EMPEE_ID = '200'", null, 7);
		SLog.slog.debug("JDBC Emp " + SUte.arrayToString(e200q));
		
		/// Attache e800
		e800 = (Employee)e800.attach();
		
		/// Check double flushing OK
		SConnection.flush();
		emp2.setDouble(emp2.SALARY, 3333);
		
		SConnection.commit();
		
		/// Check that the update really happened.
		SConnection.begin();
		TestUte.assertTrue(((Number)SConnection.rawQueryJDBC(
		"SELECT SALARY FROM XX_EMPLOYEE WHERE EMPEE_ID = '200'")).intValue()
		== 3333);
		TestUte.assertEqual((String)SConnection.rawQueryJDBC(
		"SELECT NAME FROM XX_EMPLOYEE WHERE EMPEE_ID = '800'"), "New800");
		SConnection.commit();
		
	}
	
	/** This mainly tests J2EE detach without closing functionality. */
	public static void detatchTest() throws Exception{
		System.out.println("====== detatchTest =======");
		
		SConnection.begin();
		java.sql.Connection con = SConnection.getBegunDBConnection();
		
		Department dept100 =
			(Department)Department.meta.findOrCreate("100");
		dept100.setString(Department.BUDGET, "12345");
		
		SConnection.flush(); // But no Commit!
		SConnection.detachWithoutClosing(); // Not detatchAndClose
		
		// New SimpleORM connection, same JDBC connection.
		SConnection.attach(con, "ReAttached");
		SConnection.begin();
		
		Department dept100a =
			(Department)Department.meta.findOrCreate("100");
		
		TestUte.assertTrue(dept100a.getDouble(dept100a.BUDGET) == 12345);
		TestUte.assertTrue(dept100 != dept100a); // Cache destroyed by detatch.
		
		SConnection.commit();
	}
	
	static void flushAndPurgeTest() throws Exception {
		SLog.slog.message("################ FlushAndPurgeTest #################");
		SConnection.begin();
		
		Department dept100a =
			(Department)Department.meta.findOrCreate("100");
		dept100a.setDouble(Department.BUDGET, 123);
		
		SConnection.flushAndPurge();
		
		SConnection.rawUpdateDB(
		"UPDATE xx_DEPARTMENT SET BUDGET = BUDGET * 2 WHERE DEPT_ID = '100'");
		
		// Check that the changed value is reflected in the in memory
		// Department.
		Department dept100b =
			(Department)Department.meta.findOrCreate("100");
		TestUte.assertTrue(dept100b.getDouble(Department.BUDGET) == 246);
		TestUte.assertTrue(dept100a != dept100b);
		
		// Show dubious detach/attach routines.
		SConnection scon = SConnection.unsafeDetachFromThread();
		scon.unsafeAttachToThread();
		Department dept100c =
			(Department)Department.meta.findOrCreate("100");
		TestUte.assertTrue(dept100b == dept100c);
		
		SConnection.commit();
	}
	
	
	
	/** Check locking works OK using two threads. */
	static void threadTest() throws Exception {
		SLog.slog.message("################ threadTest #################");
		SConnection.begin();
		
		Employee emp200 = (Employee)Employee.meta.findOrCreate(
				"200", SQY_READ_ONLY);
		
		
		Department d100 =
			(Department)Department.meta.findOrCreate("100");
		d100.setDouble(d100.BUDGET, 2143);
		d100.flush();
		
		final Object waiter = new Object();
		
		// d100 should be locked, so this thread will wait.
		Thread t2 = new Thread() {
			public void run() {
				try {
					try {
						TestUte.initializeTest(LongTransactionTest.class); // Sometimes fails for HSQL?
					} catch (Exception ex) {
						throw new SException.Error(ex);
					}
					SConnection.begin();
					threadCheck1 = true;
					Employee emp200 = (Employee)Employee.meta.findOrCreate(
							"200", SQY_READ_ONLY);
					threadCheck1a = true;
					
					Department d100 =
						(Department)Department.meta.findOrCreate("100");
					threadCheck2 = true;
					d100.setDouble(d100.BUDGET, 666);
					SConnection.commit();
				} finally {
					SConnection.detachAndClose();
				}
				synchronized (waiter) {
					waiter.notify();
				}
			}
		};
		t2.start();
		
		synchronized (waiter) {
			waiter.wait(); // Force a thread reschedule.
		}
		TestUte.assertTrue(threadCheck1); // Really was a reschedule.
		SLog.slog.message("Read Only is non blocking " + threadCheck1a);
		/** For some wierd reason, PostgreSQL will occasionally and
		 unreproducatbly hang about here, often the very first time the
		 test is run after a reboot!  Needs investigation. */
		if (SConnection.getDriver() instanceof SDriverPostgres)
			TestUte.assertTrue(threadCheck1a); // ReadOnly non blocking
		
		boolean locking = SConnection.getConnection().getDriver().supportsLocking();
		SLog.slog.message("Locking " + locking);
		if (locking) {
			TestUte.assertTrue(!threadCheck2); // There really was a lock, waiting.
			
			TestUte.assertTrue(((Number)SConnection.rawQueryJDBC(
			"SELECT BUDGET FROM XX_DEPARTMENT WHERE DEPT_ID = '100'")).intValue()
			== 2143);
			SLog.slog.message("Asserted 2143");
			SConnection.commit();
			
			t2.join(); // Now the other thread updates the value
			
			SConnection.begin();
			TestUte.assertTrue(((Number)SConnection.rawQueryJDBC(
			"SELECT BUDGET FROM XX_DEPARTMENT WHERE DEPT_ID = '100'")).intValue()
			== 666);
			SLog.slog.message("Asserted 666");
			SConnection.commit();
		} else { // no locking
			t2.join(); // If this hangs there really is locking after all.
			
			d100.setDouble(d100.BUDGET, 13); // NOTE THAT WITHOUT THIS THERE IS NO DETECTION.
			try {
				SConnection.commit();
				throw new SException.Test("Broken Optimistic Lock not detected.");
			} catch (SRecordInstance.BrokenOptimisticLockException be) {}
			
			SConnection.rollback();
		}
	}
	static boolean threadCheck1 = false, threadCheck1a = false, threadCheck2 = false;
	
	
	
	static void whereNullTest() throws Exception {
		SLog.slog.message("################ whereNullTest #################");
		
		// Make a null and non-null field value for Department record
		SConnection.begin();
		SConnection.rawUpdateDB(
		"UPDATE xx_DEPARTMENT SET NAME = null, BUDGET=666 WHERE DEPT_ID = '100'");
		SConnection.commit();
		
		SConnection.begin();
		Department d100a =
			(Department)Department.meta.findOrCreate("100", SQY_OPTIMISTIC);
		d100a.setString(d100a.NAME, "One00");
		d100a.setDouble(d100a.BUDGET, 246); // also test update clause formulation of non-null field
		
		SConnection.commit();
		
		// Check that the changed value is correct
		SConnection.begin();
		Department dept100b =
			(Department)Department.meta.findOrCreate("100");
		TestUte.assertTrue("One00".equals(dept100b.getString(dept100b.NAME)));
		TestUte.assertTrue(dept100b.getDouble(dept100b.BUDGET) == 246);
		SConnection.commit();
		
	}
	
	
}
