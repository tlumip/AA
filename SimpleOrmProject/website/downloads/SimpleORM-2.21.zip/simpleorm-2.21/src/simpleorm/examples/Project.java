package simpleorm.examples;

import simpleorm.core.*;

/** This test class defines the Project table.  It has an Identifying
 relataionship with Department, ie. Department forms part of its
 key. */
public class Project extends SRecordInstance {
	
	public static final SRecordMeta meta = 
		new SRecordMeta(Project.class, "XX_PROJECT");
	
	static final SFieldReference DEPARTMENT = 
		new SFieldReference(meta, Department.meta, (String)null, SCon.SFD_PRIMARY_KEY);
	
	public static final SFieldString PROJECT_ID = 
		new SFieldString(meta, "PROJECT_ID", 10, SCon.SFD_PRIMARY_KEY);
	
	public static final SFieldString NAME  = 
		new SFieldString(meta, "NAME", 40, SCon.SFD_DESCRIPTIVE);
	
	public static final SFieldDouble BUDGET = 
		new SFieldDouble(meta, "BUDGET");
	
	public SRecordMeta getMeta() { return meta; }; // specializes abstract method
}
