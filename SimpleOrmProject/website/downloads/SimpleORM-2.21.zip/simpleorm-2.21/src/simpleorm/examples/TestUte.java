package simpleorm.examples;

import simpleorm.core.*; // .* OK, all classes prefixed with "S".

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.util.Properties;

/** Utilities used by all the test cases.
 */
public class TestUte implements SConstants {
	
	/** Create and attach a SimpleORM connection based on a simple JDBC connection. 
	 * 
	 * @see SDataSource for details.
	 * @see SDataSourceJavaX for details about using a real DataSource object.
	 */
	static public void initializeTest(String testName, boolean deprecated) throws Exception {
		System.setErr(System.out); // Tidy up any stack traces.
		System.err.println("\n==== Test " + testName + " ====");
		//System.err.println("CP " + System.getProperty("java.class.path"));

		String dburl = systemProperties.getProperty("database.url", "jdbc:hsqldb:hsqlTempFiles");
		if (dburl == null)
			throw new SException.Error("database.url property not found");
		dburl = dburl.trim();
		String dbUserName = systemProperties.getProperty("database.username", "sa");
		String dbPassword = systemProperties.getProperty("database.password", "");

		String dbDriver = systemProperties.getProperty("database.driver", "org.hsqldb.jdbcDriver");
		try {
			Class.forName(dbDriver);
		} catch (Exception ex) {
			throw new SException.JDBC("Loading " + dbDriver, ex);
		}

        String traceLevel = systemProperties.getProperty("trace.level");
		if (traceLevel != null && !traceLevel.equals("")) 
			SLog.slog.level = Integer.parseInt(traceLevel);
		
		if (!deprecated) {
			SDataSource ds = new SDataSource(dburl, dbUserName, dbPassword);
			// If connection pooling is used then write
			// DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/TestDB");
			// SDataSource ds = new SDataSourceJavaX(ds);
			SConnection.attach(ds, "TestCon");
		} else {
			Connection con = java.sql.DriverManager.getConnection(dburl, dbUserName, dbPassword);
			SConnection.attach(con, "DeprecTest");
		}
	}
	static public void initializeTest(Class test) throws Exception {
		initializeTest(test.getName(), false);
	}
	
	
	/** These need to be dropped in the correct order to avoid problems
	 with referential integreity constrains. */
	static void dropAllTables() {
		SConnection.dropTableNoError("XX_UGLY_PAY_DTL");
		SConnection.dropTableNoError("XX_PSLIP_DTL");
		SConnection.dropTableNoError("XX_PAY_SLIP");
		SConnection.dropTableNoError("xx_PAY_PERIOD");
		SConnection.dropTableNoError("XX_EMPLOYEE");
		SConnection.dropTableNoError("XX_DEPARTMENT");
		SConnection.dropTableNoError("XX_VALIDATED");
	}
	
	/** Create and populate basic Dept and Emp tables. */
	static void createDeptEmp() throws Exception {
		System.out.println("################ CreateDeptEmp #################");
		int level = SLog.slog.level;
		SLog.slog.level = 20;
		
		SConnection.begin();
		
		dropAllTables();
		
		SConnection.rawUpdateDB(Department.meta.createTableSQL());
		
		SConnection.rawUpdateDB(Employee.meta.createTableSQL());
		
		SConnection.commit();
		SConnection.begin();
		
		// Create some test data
		SDataLoader deptDL = new SDataLoader(Department.meta);
		Department depts[] = (Department [])deptDL.insertRecords(new Object[][]{
				{"100", "D100", "Count Pennies", "10000", "200000"},
				{"200", "D200", "Be Happy", "20000", "300000"},
				{"300", "D300", "Enjoy Life", "30000", "150000"},
				{"400", "D400", "Fill Tables", "40000", "100000"},
				{"500", "D500", "More Data", "40000", "120000"}});
		SDataLoader empDL = new SDataLoader(Employee.meta);
		
		Employee e100 = (Employee)empDL.insertRecord(new Object[]{
				"100", "One00", "123 456 7890", "10000", "3", depts[0], null});
		Employee[] emps1 = (Employee[])empDL.insertRecords(new Object[][]{
				{"200", "Two00",   "123 456 7890", "20000", "0",  depts[1], e100},
				{"300", "Three00", "123 456 7890", "30000", "1",  null, e100}});
		SConnection.commit();
		
		SLog.slog.level = level;
		System.out.println("\n################ CreateDeptEmp END #################\n");
	}
	
	static void assertTrue(boolean cond) {
		if (!cond) 
			throw new SException.Test("Assertion Failed, see stack trace.");
	}  
	static void assertEqual(String s1, String s2) {
		if (s1==null && s2==null) return;
		if (s1==null || !s1.equals(s2))
			throw new SException.Test("Assertion Failed: " + s1 + " != " + s2);
	}  
	
	static SystemProperties systemProperties = new SystemProperties();

	/**
	 * Simple property mechanism, reads from the ~/simpleotm.properties file.
	 * Used by Default configuration to set the database.name etc.
	 */
	static public class SystemProperties {

	/**
	 * Causes the property cache to be emptied so that properties are re-read from the
	 * property file next time a property is required.
	 */
		public void refreshProperties() {
			properties = null;
		}
		protected Properties properties;
	  protected void loadProperties() {
			if (properties == null){
				String propsFile = null;
				try {
					String home = System.getProperty("user.home");
					propsFile = home + "/simpleorm.properties";
					SLog.slog.connections("Loading properties from " + propsFile);
					properties = new Properties(System.getProperties());
					FileInputStream in = new FileInputStream(propsFile);
					properties.load(in);
					in.close();		
				} catch (Exception ex) {
					throw new SException.Error("While obtaining Properties from " + propsFile, ex);
				}
			}
		}
		
		public String getProperty(String property) {
			loadProperties();
			String prop = properties.getProperty(property);
			return prop==null?null:prop.trim();
			// The .trim() is important!  
			// I once spent a long time tacking down a trailing space in a properties file driver name!
		}
		public String getProperty(String property, String defalt) {
			String val = getProperty(property);
			return val==null?defalt:val;
		}
		public void setProperty(String property, String value) {
			loadProperties();
			properties.setProperty(property, value);
		}
	}

}



