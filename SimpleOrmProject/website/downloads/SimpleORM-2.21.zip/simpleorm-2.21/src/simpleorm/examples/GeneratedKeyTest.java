package simpleorm.examples;

import simpleorm.core.*;

/** Demonstrated Generated Keys.
 */

public class GeneratedKeyTest implements SConstants {
	
	/** This test class defines the Invoice table*/
	public static class Invoice extends SRecordInstance {
		
		
		public static final SRecordMeta meta = 
			new SRecordMeta(Invoice.class, "XX_INVOICE");
		
		public static final SFieldInteger INVOICE_NR = 
			new SFieldInteger(meta, "INVOICE_NR", 
					SFD_PRIMARY_KEY, SGENERATED_KEY.pvalue(new SGeneratorSelectMax(meta))); 
		// Add SSEQUENCE_NAME.pval(Boolean.FALSE) to suppress Postgres SEQUENCES
		
		public static final SFieldString NAME  = 
			new SFieldString(meta, "NAME", 40, SFD_DESCRIPTIVE);
		
		public static final SFieldDouble VALUE = 
			new SFieldDouble(meta, "VALUE");
		
		public SRecordMeta getMeta() { return meta; };
		
		boolean validated; // just for unit test.
		public void validateRecord() {
			SLog.slog.fields("Validated.record " + this);
			validated = true;
		}
	}
	
	
	public static void main(String[] argv) throws Exception {
		TestUte.initializeTest(GeneratedKeyTest.class); // Look at this code.
		try {
			/// first using the default Select Max method
			genTest();
			
			/// Now using Sequences
			if (SConnection.getDriver().supportsKeySequences()) {
				Invoice.INVOICE_NR.putProperty(SGENERATED_KEY, new SGeneratorSequence(Invoice.meta));
				SConnection.begin();
				SConnection.dropTableNoError("DUAL");
				SConnection.rawUpdateDB("CREATE TABLE DUAL (COL VARCHAR(10))");
				SConnection.rawUpdateDB("INSERT INTO DUAL VALUES ('DUMMY')");
				SConnection.commit();
				
				genTest();
			}
			
		} finally {
			SConnection.detachAndClose();
		}
	}
	
	/** Basic examples/tests not involving foreign keys. */
	static void genTest() throws Exception {
		
		/// (re)create tables
		SConnection.begin();
		SConnection.dropTableNoError("XX_INVOICE");
		SConnection.rawUpdateDB(Invoice.meta.createTableSQL());
		
		SGenerator gen = Invoice.meta.getSGenerator();
			//(SGenerator)Invoice.INVOICE_NR.getProperty(SGENERATED_KEY);
		try {
			SConnection.rawUpdateDB(gen.dropDDL());
		} catch (SException.JDBC ex){} // Might not exist.
		SConnection.rawUpdateDB(gen.createDDL());
		SConnection.commit();
		
		
		SConnection.begin();
		
		/// Create First
		Invoice inv1 = (Invoice)Invoice.meta.createWithGeneratedKey();
		inv1.validated = false;
		SConnection.flush();
		TestUte.assertTrue(inv1.validated);
		inv1.setString(inv1.NAME, "First");
		inv1.setDouble(inv1.VALUE, 123);
		long key1 = inv1.getLong(inv1.INVOICE_NR);
		inv1.validated = false;
		SConnection.flush();
		TestUte.assertTrue(inv1.validated);
		
		Invoice inv1a = (Invoice)Invoice.meta.findOrCreate(
				new Long(key1));
		TestUte.assertEqual(inv1+"", inv1a+"");
		
		/// Create some Records using the SDataLoader
		SDataLoader invoiceDL = new SDataLoader(Invoice.meta);      
		invoiceDL.insertRecords(new Object[][]{
				{"Second", "234"},
				{"Third", "345"}});
		SConnection.commit();
		
		// Check Result
		SConnection.begin();
		Invoice inv3a = (Invoice)Invoice.meta.findOrCreate(
				new Long(key1+2));
		TestUte.assertEqual(inv3a.getString(inv3a.NAME), "Third");
		
		Object sum = SConnection.rawQueryJDBC(
		"SELECT SUM(VALUE) FROM XX_INVOICE");
		if (((Number)sum).intValue() != (123 + 234 + 345))
			throw new SException.Test("Bad Value sum " + sum);
		SConnection.commit();
		
	}
}
