package simpleorm.examples;

import simpleorm.core.*; // .* OK, all classes prefixed with "S".
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;

/** Tests and demonstrates Identifying Foreign Keys.
 */
public class IdentFKeysTest implements SConstants {
	// ### Provide an E-R diagram of the schema.
	
	public static void main(String[] argv) throws Exception {
		System.setErr(System.out); // Tidy up any stack traces.
		// SLog.level = 20; //Uncomment to reduce trace output.
		TestUte.initializeTest(IdentFKeysTest.class);
		try {
			testInit();
			payrollTest();
			payrollQuery();
			payrollUpdate();
			uglyPaySlipDetail();
			
		} finally {
			SConnection.detachAndClose();
		}
	}
	
	
	/** Prepare for tests, Delete old data. */
	static void testInit() throws Exception {
		System.out.println("################ testInit #################");
		SConnection.begin();
		
		/// Delete any old data from a previous run.
		TestUte.dropAllTables();
		
		int level = SLog.slog.level;
		SLog.slog.level = 20;
		
		/// Dump the internal definitions of the records, mainly for debugging.
		SLog.slog.message("Period Fields " 
				+ Payroll.Period.meta.allFieldsString());
		SLog.slog.message("PaySlip Fields " 
				+ Payroll.PaySlip.meta.allFieldsString());
		SLog.slog.message("SlipDetail Fields " 
				+ Payroll.PaySlipDetail.meta.allFieldsString());
		SLog.slog.message("UglySlipDetail Fields " 
				+ Payroll.UglyPaySlipDetail.meta.allFieldsString());
		
		
		
		SConnection.rawUpdateDB(Department.meta.createTableSQL());
		SConnection.rawUpdateDB(Employee.meta.createTableSQL());
		SConnection.rawUpdateDB(Payroll.Period.meta.createTableSQL());
		SConnection.rawUpdateDB(Payroll.PaySlip.meta.createTableSQL());
		SConnection.rawUpdateDB(Payroll.PaySlipDetail.meta.createTableSQL());
		SConnection.rawUpdateDB(Payroll.UglyPaySlipDetail.meta.createTableSQL());
		
		SLog.slog.level = level;
		
		SConnection.commit();
		
		/// Create some Departments and Employees.
		SConnection.begin();
		
		SDataLoader deptDL = new SDataLoader(Department.meta);
		deptDL.insertRecords(new Object[][]{
				{"100", "One00", "Count Pennies", "10000", "200000"},
				{"200", "Two00", "Be Happy", "20000", "150000"},
				{"300", "Three00", "Enjoy Life", "30000", "300000"}});
		
		SDataLoader empDL = new SDataLoader(Employee.meta);
		Department d100 = (Department)Department.meta.findOrCreate("100");
		Department d200 = (Department)Department.meta.findOrCreate("200");
		/// Create an Employee
		Employee e100 = (Employee)empDL.insertRecord(new Object[]{
				"100", "One00", "123 456 7890", "10000", "3", null, null});
		Employee[] emps1 = (Employee[])empDL.insertRecords(new Object[][]{
				{"200", "Two00",   "123 456 7890", "20000", "0",  d200, e100},
				{"300", "Three00", "123 456 7890", "30000", "1",  null, e100}});
		SConnection.commit();
		
	}
	
	/** Demonstrates more advanced schema involving multi column multi
	 level identifying foreign keys.*/
	static void payrollTest() { 
		System.out.println("################ Payroll Test #################");
		SConnection.begin();
		
		
		/// Create Periods
		SDataLoader prdDL = new SDataLoader(Payroll.Period.meta);
		Payroll.Period[] prds =
			(Payroll.Period[])prdDL.insertRecords(new Object[][]{
					{"2001", "1", "1234"},
					{"2002", "1", "2345"},
					{"2002", "2", "3456"}});
		
		/// Create PaySlips
		Employee e100 = (Employee)Employee.meta.findOrCreate("100");
		Employee e200 = (Employee)Employee.meta.findOrCreate("200");
		
		SDataLoader slipDL = new SDataLoader(Payroll.PaySlip.meta);
		Payroll.PaySlip[] slips =
			(Payroll.PaySlip[])slipDL.insertRecords(new Object[][]{
					{e100, prds[0], "2001, prd1, emp100"},
					{e200, prds[0], "2001, prd1, emp200"},
					{e100, prds[2], "2002, prd2, emp100"},
					{e200, prds[2], "Deleted e200 2"},
					{e200, prds[1], "ps4 Deleted e200 1"} 
			});
		
		/// Create PaySlipDetails
		SDataLoader detailDL = new SDataLoader(Payroll.PaySlipDetail.meta);
		Payroll.PaySlipDetail[] details =
			(Payroll.PaySlipDetail[])detailDL.insertRecords(new Object[][]{
					{slips[0], "11", "123"},
					{slips[0], "12", "234"},
					{slips[1], "11", "345"},
					{slips[2], "13", "456"}, 
					{slips[4], "22", "567"} 
			});
		
		/// Change a Detail.
		details[0].setInt(details[0].VALUE, 567);
		SConnection.flush();
		
		/// Check sums to ensure that the database is updated correctly.
		Object slipSum1 = SConnection.rawQueryJDBC(
				"SELECT SUM(VALUE) FROM XX_PSLIP_DTL " +
		" WHERE INCONSIST_EMP_NR = '100' ");
		if (((Number)slipSum1).intValue() !=567+234+456)
			throw new SException.Test("Bad Payslip Emp sum " + slipSum1);
		
		Object slipSum2 = SConnection.rawQueryJDBC(
				"SELECT SUM(VALUE) FROM XX_PSLIP_DTL " +
		" WHERE YEAR = 2001 ");
		if (((Number)slipSum2).intValue() != 567+234+345)
			throw new SException.Test("Bad Payslip Year sum " + slipSum2);
		
		SConnection.commit();
		SConnection.begin();
		
		/// Explicitly retrieve a value from PaySlipDetail
		Payroll.Period p2002_2 
		= (Payroll.Period)Payroll.Period.meta.findOrCreate(
				new Object[]{"2002", "2"});
		Employee e100a = (Employee)Employee.meta.findOrCreate("100");
		Payroll.PaySlip pe100_2002_2 
		= (Payroll.PaySlip)Payroll.PaySlip.meta.findOrCreate(
				new Object[]{e100a, p2002_2});
		Payroll.PaySlipDetail pe100_2002_2_13
		= (Payroll.PaySlipDetail)Payroll.PaySlipDetail.meta.findOrCreate(
				new Object[]{pe100_2002_2, "13"});    
		int val = pe100_2002_2_13.getInt(pe100_2002_2_13.VALUE);
		if (val != 456)
			throw new SException.Test("Bad PaySlipDetail value " + val);
		
		SConnection.commit();
		
	}
	
	/** Test basic queries on PayslipDetails */
	static void payrollQuery() {
		SConnection.begin();
		
		SResultSet rs0 = Payroll.PaySlip.meta.select(
				"COMMENTS = '2001, prd1, emp100'", null).execute();
		Payroll.PaySlip ps0 = (Payroll.PaySlip)rs0.getOnlyRecord();
		
		SResultSet psdq = Payroll.PaySlipDetail.meta.newQuery()
		.eq(Payroll.PaySlipDetail.PAY_SLIP, ps0).execute();
		double total = 0;
		while (psdq.hasNext()) {
			Payroll.PaySlipDetail psd = (Payroll.PaySlipDetail)psdq.getRecord();
			double val = psd.getDouble(psd.VALUE);
			total += val;
			SLog.slog.debug("PSDtl " + psd + " = " + val + " " + total);
		}
		TestUte.assertTrue(total == 567 + 234);
		
		SConnection.commit();
	}
	
	
	/** More testing on updating Payrolls */
	static void payrollUpdate() {
		SConnection.begin();
		SResultSet rs0 = Payroll.PaySlip.meta.select(
				"COMMENTS = 'Deleted e200 2'", null).execute();
		Payroll.PaySlip ps2 = (Payroll.PaySlip)rs0.getOnlyRecord();
		
		Employee e200a = (Employee)ps2.getReference(ps2.EMPLOYEE);
		TestUte.assertTrue("Two00".equals(e200a.getString(e200a.NAME)));
		
		ps2.deleteRecord();
		
		SConnection.commit();
		SConnection.begin();
		
		
		Employee e200b = (Employee)Employee.meta.findOrCreate("200");
		Payroll.Period prd1 = (Payroll.Period)Payroll.Period.meta.findOrCreate(
				new Object []{"2002", "1"});
		Payroll.PaySlip ps4 = (Payroll.PaySlip)Payroll.PaySlip.meta.findOrCreate(
				new Object []{e200b, prd1});
		ps4.assertNotNewRow();
		TestUte.assertTrue("ps4 Deleted e200 1".equals(ps4.getString(ps4.COMMENTS)));
		
		Payroll.PaySlipDetail psd4 = (Payroll.PaySlipDetail)Payroll.PaySlipDetail.meta.
		findOrCreate(new Object[]{ps4, "22"});
		psd4.assertNotNewRow();
		
		psd4.setDouble(psd4.VALUE, 123);
		
		SConnection.flush();
		
		psd4.deleteRecord();
		
		ps4.deleteRecord(); 
		
		SConnection.commit();
		
	}
	
	
	static void uglyPaySlipDetail() {
		SConnection.begin();
		
		/// Create UglyPaySlipDetails
		SResultSet rs0 = Payroll.PaySlip.meta.select(
				"COMMENTS = '2001, prd1, emp100'", null).execute();
		Payroll.PaySlip ps2 = (Payroll.PaySlip)rs0.getOnlyRecord();
		
		SDataLoader detailDL = new SDataLoader(Payroll.UglyPaySlipDetail.meta);
		Payroll.UglyPaySlipDetail[] details =
			(Payroll.UglyPaySlipDetail[])detailDL.insertRecords(new Object[][]{
					{ps2, SJSharp.newInteger(99), "666"}});
		
		SConnection.flush();
		
		/// Change a Detail.
		details[0].setInt(details[0].VALUE, 567);
		SConnection.commit();
		SConnection.begin();
		
		/// Read it back and check
		Payroll.PaySlip ps2a = (Payroll.PaySlip)Payroll.PaySlip.meta.select(
				"COMMENTS = '2001, prd1, emp100'", null).execute().getOnlyRecord();
		
		Payroll.UglyPaySlipDetail ud99 
		= (Payroll.UglyPaySlipDetail)Payroll.UglyPaySlipDetail.meta.findOrCreate(
				new Object[]{ps2a, SJSharp.newInteger(99)});
		int val = ud99.getInt(ud99.VALUE);
		if (val != 567)
			throw new SException.Test("Bad ugly value " + val);
		SConnection.commit();    
		
	}
	
}



