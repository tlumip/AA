package simpleorm.examples;

import simpleorm.core.*;


/** This test class defines the Department table */
public class Department extends SRecordInstance {
	
	public static final SRecordMeta meta = 
		new SRecordMeta(Department.class, "XX_DEPARTMENT");
	// ie. SRecord objects describe SRecordInstances
	
	public static final SFieldString DEPT_ID = 
		new SFieldString(meta, "DEPT_ID", 10, SCon.SFD_PRIMARY_KEY);
	
	public static final SFieldString NAME  = 
		new SFieldString(meta, "NAME", 40, SCon.SFD_DESCRIPTIVE);
	
	public static final SFieldString MISSION = 
		new SFieldString(meta, "Mission", 40); //  Mixed case column name
	
	public static final SFieldDouble BUDGET = 
		new SFieldDouble(meta, "BUDGET");
	
	public static final SFieldDouble MAX_SALARY = 
		new SFieldDouble(meta, "MAX_SALARY");
	
	public SRecordMeta getMeta() { return meta; }; // specializes abstract method
}
