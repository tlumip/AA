package simpleorm.core;

/**
 * Open source verion of Interbase.
 * @author Augustin
 */
public class SDriverFirebird extends SDriverInterbase {
  protected String driverName() {return "firebirdsql jca/jdbc resource adapter";}

}
