package simpleorm.core;

import simpleorm.properties.*;
import java.sql.ResultSet;

/** Represents Double field meta data. */

public class SFieldDouble extends SFieldScalar {
  public SFieldDouble(SRecordMeta meta, String columnName, 
    SPropertyValue [] pvals) {
    super(meta, columnName, pvals);
  }
  public SFieldDouble(SRecordMeta meta, String columnName) {
    this(meta, columnName, new SPropertyValue[0]);
  }
  public SFieldDouble(SRecordMeta meta, String columnName,
     SPropertyValue pval) {
    this(meta, columnName, new SPropertyValue[]{pval});
  }
  public SFieldDouble(SRecordMeta meta, String columnName,
     SPropertyValue pval1, SPropertyValue pval2) {
    this(meta, columnName, new SPropertyValue[]{pval1, pval2});
  }

  /** Abstract specializer.  Clone this key field to be a foreign key
      to <code>rmeta</code> of the same type.*/
  SFieldMeta makeForeignKey(
    SRecordMeta rmeta, String prefix, SPropertyValue [] pvals) {
    return new SFieldDouble(rmeta, 
      (prefix==null?"":prefix)+getString(SCon.SCOLUMN_NAME), 
      pvals);
  }

  /** Specidalizes abstract method to actually query a column from a
      result set. */
  Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception {
    double res = rs.getDouble(sqlIndex);
    if (rs.wasNull()) // ie. last operation!
      return null;
    else 
      return SJSharp.newDouble(res);
  }
 
  Object convertToField(Object raw)  throws Exception {
    if ( SJSharp.isDouble(raw) ) return raw;
    if (raw == null) return null; // Follows JDBC
    if (raw instanceof Number) 
      return SJSharp.newDouble((Number)raw);
    if (raw instanceof String) {
      return SJSharp.newDouble((String)raw);
    }
    throw new SException.Data("Cannot convert " + raw + " to Double.");
  }

  /** Specializes SFieldMeta. */
  String defaultDataType(){return "DOUBLE PRECISION";}

}
