package simpleorm.core;
import simpleorm.properties.*;
import java.sql.ResultSet;

/** Represents Integer field meta data. */

public class SFieldInteger extends SFieldScalar {
	public SFieldInteger(SRecordMeta meta, String columnName, 
			SPropertyValue [] pvals) {
		super(meta, columnName, pvals);
	}
	public SFieldInteger(SRecordMeta meta, String columnName) {
		this(meta, columnName, new SPropertyValue[0]);
	}
	public SFieldInteger(SRecordMeta meta, String columnName,
			SPropertyValue pval) {
		this(meta, columnName, new SPropertyValue[]{pval});
	}
	public SFieldInteger(SRecordMeta meta, String columnName,
			SPropertyValue pval1, SPropertyValue pval2) {
		this(meta, columnName, new SPropertyValue[]{pval1, pval2});
	}
	
	/** Abstract specializer.  Clone this key field to be a foreign key
	 to <code>rmeta</code> of the same type.*/
	SFieldMeta makeForeignKey(
			SRecordMeta rmeta, String prefix, SPropertyValue [] pvals) {
		return new SFieldInteger(rmeta, 
				(prefix==null?"":prefix)+getString(SCon.SCOLUMN_NAME), 
				pvals);
	}
	
	Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception {
		int res = rs.getInt(sqlIndex);
		if (rs.wasNull()) // ie. last operation!
			return null;
		else 
			return SJSharp.newInteger(res);
	}
	
	Object convertToField(Object raw)  throws Exception {
		if (SJSharp.isInteger(raw)) return raw;
		if (raw == null) return null;
		if (raw instanceof Number) 
			return SJSharp.newInteger((Number)raw);
		if (raw instanceof String) {
			return SJSharp.newInteger((String)raw);
		}
		throw new SException.Data("Cannot convert " + raw + " to Integer.");
	}
	
	/** Specializes SFieldMeta. */
	String defaultDataType(){return "INTEGER";}
	
}
