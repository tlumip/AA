package simpleorm.core;
import simpleorm.properties.*;
import java.sql.ResultSet;

/** Represents Boolean field meta data as "T" and "F" chars. 
 * @author Martin Snyder. */

public class SFieldBooleanCharTF extends SFieldBooleanChar
{
  public SFieldBooleanCharTF(SRecordMeta meta, String columnName, SPropertyValue [] pvals)
  {
    super(meta, columnName, pvals);
    putProperty(SCon.SBYTE_SIZE, new Integer(1)); // for Create Table only.
    TRUE_VALUE = "T";
    FALSE_VALUE = "F";
  }

  public SFieldBooleanCharTF(SRecordMeta meta, String columnName)
  {
    this(meta, columnName, new SPropertyValue[0]);
  }
  public SFieldBooleanCharTF(SRecordMeta meta, String columnName, SPropertyValue pval)
  {
    this(meta, columnName, new SPropertyValue[]{pval});
  }
  public SFieldBooleanCharTF(SRecordMeta meta, String columnName, SPropertyValue pval1, SPropertyValue pval2)
  {
    this(meta, columnName, new SPropertyValue[]{pval1, pval2});
  }

  /** Abstract specializer.  Clone this key field to be a foreign key
      to <code>rmeta</code> of the same type.*/
  SFieldMeta makeForeignKey(SRecordMeta rmeta, String prefix, SPropertyValue [] pvals)
  {
    return new SFieldBooleanCharTF(
		rmeta, (prefix==null?"":prefix)+getString(SCon.SCOLUMN_NAME),	pvals);
  }
}
