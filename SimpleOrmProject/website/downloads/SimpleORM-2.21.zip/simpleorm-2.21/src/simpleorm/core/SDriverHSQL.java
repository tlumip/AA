package simpleorm.core;

/** This contains HSQL specific code.  Note that this toy database
 does not support locking, so is not safe in multi user mode even
 with optimistic locking.  See {@link SDriver#supportsLocking}.*/

public class SDriverHSQL extends SDriver {
	
	// ## Should add some sort of crude JVM based locking hack -- the
	// first transaction to select FOR UPDATE locks entire databse.
	
	protected String driverName() {return "HSQL Database Engine Driver";}
	
	/** HSQL has a major hole but optimisic locking papers over it.*/
	public boolean supportsLocking(){return false;}
	
	protected String columnTypeSQL(SFieldMeta field) {
		if ( ( (String) field.getProperty(SDATA_TYPE)).equals("BYTES"))
			return "BINARY"; // Ie. just a byte array.
		else
			return super.columnTypeSQL(field);
	}
	
	
	protected long generateKeySequence(SRecordMeta rec, SFieldMeta keyFld) {
		Object sequenceName = keyFld.getProperty(SSEQUENCE_NAME);
		
		String qry = "SELECT NEXT VALUE FOR " + (String)sequenceName + " FROM DUAL"; // ### Dual!
		// Thanks elifarley.  Note that HSQL also supports Identity.
		
		Object next = SConnection.rawQueryJDBC(qry);
		return SJSharp.object2Long(next);
	}
	public boolean supportsKeySequences(){return true;}
	protected String createSequenceDDL(String name) {
		return "CREATE SEQUENCE " + name;
	}
	protected String dropSequenceDDL(String name) {
		return"DROP SEQUENCE " + name;
	}
	
}

