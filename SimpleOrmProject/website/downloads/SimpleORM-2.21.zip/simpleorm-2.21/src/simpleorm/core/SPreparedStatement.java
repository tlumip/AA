package simpleorm.core;
import simpleorm.examples.Employee;
import  simpleorm.properties.*;

import java.sql.*;
import java.math.BigDecimal;

/** This class represents a SimpleORM prepared query statement.  It is
    analagous to the JDBC prepared statement.<p>

    The general flow of a query goes as follows:-
<xmp>
    SPreparedStatement stmt = Employee.meta.select("SALARY > ?", "NAME");
      // SELECT <All columns> FROM XX_EMPLOYEE
      //  WHERE SALARY > ? ORDER BY NAME
    stmt.setInt(1, 50000);
    SResultSet res = stmt.execute();
    while (res.hasNext()) {
      Employee emp = res.getRecord();
      emp.getString(Employee.NAME);
    }
</xmp>

To avoid a brittle structure with an ever growing number of parameters
to SPreparedStatement, the objects now created in two steps one to
create the object and set parameters.  To utilize this use the following style instead:-

<xmp>
  	SPreparedStatement limitps = new SPreparedStatement();
		limitps.setOffset(1);
		limitps.setLimit(1);
		SResultSet limitR = Employee.meta.newQuery()
  		.ascending(Employee.EMPEE_ID)
	  	.execute(limitps);
	  	
	  // Employee.meta.Select(limitps,...)
</xmp>

## This uses of the SPreparedStatement seems a little odd.  Maybe newQuery(limitps) would
be better, and also use newSPreparedStatement(Employee.meta...) instead of Select.  Mabye.
But definitely do not want to create a Properties object one per query. 
*/
public class SPreparedStatement {
  SRecordMeta sRecordMeta = null;
  SConnection sConnection = null;
  SFieldMeta[] selectList = null;
  String sqlQuery = null;
  PreparedStatement jdbcPreparedStatement = null;
  boolean readOnly = false;
  boolean unrepeatableRead = false;  
  boolean optimistic = false;

  SRecordMeta[] joinTables = null;
  public SRecordMeta[] getJoinTables(){return joinTables;}
  public void setJoinTables(SRecordMeta[] jts){joinTables = jts;}

  boolean distinct = false;
  /** Select DISTINCT */
  public boolean getDistinct(){return distinct;}
  public void setDistinct(boolean jts){distinct = jts;}

  long  offset = 0;
  /** Offset and Limit reduce the number of rows retrieved.  My be
   * implemented efficiently by the database, or just by skipping
   * ahead during execute.  Semantics are not that well defined
   * between transactions, rows may be missed.  Useful for paging out
   * query results. <p>
   *
   * Note that if offset = 2 and limit = 5, the rows 0 and 1 are
   * skipped, and rows 2..6 are returned.
*/
  public long getOffset(){return offset;}
  public void setOffset(long off){offset = off;}

  long limit = 0;
  /** see limit */
  public long getLimit(){return limit;}
  public void setLimit(long lim){limit = lim;}

  public SPreparedStatement() {
  }

  protected void prepareStatement(
  		SRecordMeta meta, String where, String orderBy, long sqy_bitSet,
    SFieldMeta[] selectList)
  {
    sRecordMeta = meta;
    this.selectList = selectList;

    SConnection scon = SConnection.getBegunConnection();

    readOnly = SUte.inBitSet(sqy_bitSet, SCon.SQY_READ_ONLY, SCon.SQY_);
    unrepeatableRead = SUte.inBitSet(sqy_bitSet, SCon.SQY_UNREPEATABLE_READ, SCon.SQY_);
    optimistic
      = SUte.inBitSet(sqy_bitSet, SCon.SQY_OPTIMISTIC, SCon.SQY_)
      || (!scon.getDriver().supportsLocking() && !readOnly);
    if (readOnly && optimistic)
      throw new SException.Error(
        "Cannot be both Optimistically Locked and ReadOnly " + this);

    /// Create the Query
    sqlQuery = scon.sDriver.selectSQL(
      selectList, sRecordMeta, where, orderBy, 
			!readOnly && !optimistic, unrepeatableRead,
			this);

    if (SLog.slog.enableQueries())
      SLog.slog.queries("select querying '" + sqlQuery + "'...");

    sConnection = SConnection.getBegunConnection();
    try {
      jdbcPreparedStatement
	= sConnection.jdbcConnection.prepareStatement(sqlQuery);
        // Let the JDBC driver cache these.
    } catch (Exception psex) {
      throw new SException.JDBC("Preparing '" + sqlQuery + "'", psex);
    }
  }


  /** <tt>value</tt> replaces the <tt>parameterIndex</tt>th
      "<tt>?</tt>" in the query.  The first "<tt>?</tt>" is 1, not 0.
      Analagous to jdbc PreparedStatement.setString. */
  public void setString(int parameterIndex,  String value) {
    try {
      jdbcPreparedStatement.setString(parameterIndex, value);
    } catch (Exception se) {
      throw new SException.JDBC("Setting " + this
	+ " '?' " + (parameterIndex), se);
    }
  }
  public void setInt(int parameterIndex,  int value){
    try {
      jdbcPreparedStatement.setInt(parameterIndex, value);
    } catch (Exception se) {
      throw new SException.JDBC("Setting " + this
	+ " '?' " + (parameterIndex), se);
    }
  }
  public void setLong(int parameterIndex,  long value){
    try {
      jdbcPreparedStatement.setLong(parameterIndex, value);
    } catch (Exception se) {
      throw new SException.JDBC("Setting " + this
	+ " '?' " + (parameterIndex), se);
    }
  }

  public void setDouble(int parameterIndex,  double value){
    try {
      jdbcPreparedStatement.setDouble(parameterIndex, value);
    } catch (Exception se) {
      throw new SException.JDBC("Setting " + this
	+ " '?' " + (parameterIndex), se);
    }
  }
  public void setObject(int parameterIndex,  Object value){
    try {
      jdbcPreparedStatement.setObject(parameterIndex, value);
    } catch (Exception se) {
      throw new SException.JDBC("Setting " + this
	+ " '?' " + (parameterIndex), se);
    }
  }
  /** See {@link SRecordInstance#setTimestamp} for discussion of Date parameter.*/
  public void setTimestamp(int parameterIndex,  java.util.Date value){
    if (!(value instanceof java.sql.Timestamp))
      value = new java.sql.Timestamp(value.getTime());
    try {
      jdbcPreparedStatement.setTimestamp(parameterIndex, (java.sql.Timestamp)value);
    } catch (Exception se) {
      throw new SException.JDBC("Setting " + this
	+ " '?' " + (parameterIndex), se);
    }
  }
  /** See {@link SRecordInstance#setTimestamp} for discussion of Date parameter.*/
  public void setDate(int parameterIndex,  java.util.Date value){
    if (!(value instanceof java.sql.Date))
      value = new java.sql.Date(value.getTime());
    try {
      jdbcPreparedStatement.setDate(parameterIndex, (java.sql.Date)value);
    } catch (Exception se) {
      throw new SException.JDBC("Setting " + this
	+ " '?' " + (parameterIndex), se);
    }
  }
  /** See {@link SRecordInstance#setTimestamp} for discussion of Date parameter.*/
  public void setTime(int parameterIndex,  java.util.Date value){
    if (!(value instanceof java.sql.Time))
      value = new java.sql.Time(value.getTime());
    try {
      jdbcPreparedStatement.setTime(parameterIndex, (java.sql.Time)value);
    } catch (Exception se) {
      throw new SException.JDBC("Setting " + this
	+ " '?' " + (parameterIndex), se);
    }
  }
  public void setBigDecimal(int parameterIndex,  BigDecimal value){
    try {
      jdbcPreparedStatement.setBigDecimal(parameterIndex, value);
    } catch (Exception se) {
      throw new SException.JDBC("Setting " + this
	+ " '?' " + (parameterIndex), se);
    }
  }

  /** Execute the query having set "<tt>?</tt>" paramenters. */
  public SResultSet execute() {
    ResultSet rs = null;
    try {
      rs = jdbcPreparedStatement.executeQuery();
    } catch (Exception rsex) {
      throw new SException.JDBC("Executing " + sqlQuery, rsex);
    }
    return new SResultSet(rs, this);
  }

  /** Close the underlying JDBC prepared statement.<p>

      @deprecated Due to bugs in some JDBC drivers, {@link SResultSet#close} now
      automatically also closes the prepared statement from Version
      1.05.  This means that there is no reason to ever call this
      method explicilty. */
  public void close() {
    try {
      jdbcPreparedStatement.close();
    } catch (Exception ce) {
      throw new SException.JDBC("Closing " + this, ce);
    }
    sRecordMeta = null;
    sConnection = null;
    selectList = null;
    jdbcPreparedStatement = null;
  }

  public String getSQL(){return sqlQuery;}

  /** Retrieves the underlying JDBC PreparedStatement object.
      Dangerous.  The authors can see no reason why this would ever
      need to be used but it is provided for completeness.
 */
  public PreparedStatement getJDBCPreparedStatement() {
    return jdbcPreparedStatement;
  }

  public String toString() {
    return "[SPreparedStatement " + sqlQuery + "]";
  }
}
