package simpleorm.core;
import simpleorm.properties.*;

/*
 * Copyright (c) 2002 Southern Cross Software Limited (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/** Contains all the constants used by SimpleORM.  Implementing this
interface will automatically import these constants which is
convenient.  All constants are prefixed to avoid conflicts.<p>

Bit fields are longs to alow for growth and to trap type errors if
they are mixed up with other int parameters.  For flags, the low order
short is used to verfiy the parameter -- each flag set has a different
lower short.  Parameters that use them are named *_flags where * is the
prefix, eg. sfd_bitSet.<p>

Wouldn't it be wonderful if Java supported 30 year old constructs such
as enumerations and sets!<p>

Constants and methods suffixed <code>_unimp</code> have not yet been
implemented.  When they are, the suffix will be removed.<p> */

public interface SConstants extends SSimpleORMProperties {

  // static final String SIMPLEORM_VERSION Moved to SUte due to Java bugs.
   
    // ## Should validate.  Also, option for non Create Table not null.
  //static final long SFD_GROUP_1     = ; // user defined groupings.
  //static final long SFD_GROUP_2     = ;

  /** SQY_: SimpleORM QuerY flags.  Controls which fields are queried,
      and how.*/
  static final long SQY_            = 0x00000200;

  /** Causes only the primary key field(s) are queried.  At least the
      primary key field(s) are always queried. */
  static final long SQY_PRIMARY_KEY = 0x00010200;

  /** Only query fields marked <code>SFD_DESCRIPTIVE</code>. */
  static final long SQY_DESCRIPTIVE = 0x00020200;

  /** Include any columns that were marked SFD_UNQUERIED and so are not
      normally retrieved. */
  static final long SQY_UNQUERIED = 0x00040200;

  /* Only query fields marked SFD_GROUP_1 or _2.  Primary keys are
     always queried.  */
  //static final long SQY_GROUP_1     = 0x00100200;
  //static final long SQY_GROUP_2     = 0x00200200;

  /** Do not lock the record in the database.  Must not be updated
      unless subsequently requeired without this flag set.
      See SQY_UNREPEATABLE_READ */
  static final long SQY_READ_ONLY      = 0x00800200;

  /** Use Optimistic locking.  Ie. do not lock the record in the
      database, but do remember the previous state of the row.  If the
      record is updated a check is made that the row has not been
      updated by another session.*/
  static final long SQY_OPTIMISTIC     = 0x01000200;

  /** Retrieve the row from the Read Mostly cache.  Use with caution
      because the returned row might be quite stale.  Must not be
      updated.*/
  static final long SQY_READ_MOSTLY_unimp   = 0X02000200;

  /** Internal for DataLoader.  Do not include Foreign key column
      fields, just the references.*/
  static final long SQY_NO_FOREIGN_KEYS = 0X04000200; 

  /** Internal for queries.  Do not include Reference fields, just
      the fields that correspond to columns. */
  static final long SQY_NO_REFERENCES = 0X08000200; 

  /** Internal for queries.  Do not include any generated keys. */
  static final long SQY_NO_GENERATED_KEYS = 0X10000200;

  /** Optimization parameter to findOrCreate that causes SimpleORM to
      assume that the the record does not already exist in the
      database, and so does not do the initial <code>SELECT</code>.
      Saves about 30%.  If the record does in fact exist you will get a
      duplicate key error when the record is flushed. */
  static final long SQY_ASSUME_CREATE = 0X20000200;

  /**
   * Prevents a query from being issued to lazzily fetch a reference.
   * getObject just returns Boolean.FALSE in this case.  See
   * getReferenceNoQuery.
   */
  static final long SQY_REFERENCE_NO_QUERY = 0x40000200;
  
  /**
   * Read without locking the record with a read lock.
   * Important for MS SQL to prevent lock escalation.
   * For read behind dbs like Oracle/Postgresql this is the same as SQY_Read_Only
   * in that no "FOR UPDATE" is appended, yet the record is still updatable
   * (The read actually will probably be repeatable).<p>
   * 
   * Note that this still enables the record to be updated.
   * This is very dangerous unless you are <b>sure</b> that no other 
   * user could be accessing the records.
   * Eg. Detail records related to a master.<p>
   * 
   * But if you get this wrong you will get unrepeatable data
   * corruption.
   * See SQY_UNREPEATABLE_READ.
   * And consider using optimistic locks if this really is a problem for you.
   */
  static final long SQY_UNREPEATABLE_READ_UNSAFE = 0x80000200;
  /**
   * Read without locking the record with a read lock.  
   * It is also Read_Only.<p>
   * 
   * Note that it is still not really safe if you are using read
   * data to update another record.<p>
   * 
   * Important for MS SQL to prevent lock escalation.
   * Has no effect for read behind dbs like Oracle/Postgresql.
   */
  static final long SQY_UNREPEATABLE_READ = 
  	SQY_UNREPEATABLE_READ_UNSAFE | SQY_READ_ONLY;


  /** Values of SRecordInstance.bitSets -- ie. internal. */
  static final byte INS_VALID   = 0x01; // ie. Has been queried.
  static final byte INS_READ_ONLY = 0x02; // ie. queried for update.
  static final byte INS_DIRTY   = 0x04; 
  // ie. has been set.  But also may be true for primary keys iff they
  // were retrieved via findOrCreate (vs select).

}

