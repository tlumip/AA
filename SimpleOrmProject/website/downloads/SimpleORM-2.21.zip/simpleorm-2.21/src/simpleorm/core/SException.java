package simpleorm.core;

import java.io.PrintWriter;
import java.io.PrintStream;

/** Poor man's exception chaining.  Used to both convert exceptions to
 RuntimeExceptions and to throw real exceptions.  The print routines
 are careful to only print the inner (ie most complete) stack trace.<p>
 
 SimpleORM takes care to trap most error conditions and throw
 meaningful exception messages.  Unlike most other Java code, they
 always include information about which objects were being processed at
 the time, eg. the primary key of the current record.  We strongly
 encourage this practice as it greatly facilitates maintenance and
 debugging.<p>
 
 Subclasses are actually thrown, namely
 <code>SException.Error</code> to indicate probable bugs in the user's
 program, <code>SException.InternalError</code> to indicate bugs in
 SimpleOrm, <code>SException.JDBC</code> for chained JDBC errors,
 <code>SException.Data</code> for errors that probably the result of
 run-time data problems.  <code>SException.Test</code> is used to
 indicate failed test cases.<p>
 
 Other well defined exceptions that a user may want to trap are given
 explicit subclasses
 (eg. <code>SRecordInstance.BrokenOptimisticLockException</code>).<p>
 
 SimpleORM only throws SExceptions which extend RuntimeException and so
 avoid the need to clutter the code with unnecessary try/catch blocks.
 The only reason to use try/catch when using SimpleORM is because you
 <i>really</i> want to catch an error.<p>
 
 (The author stongly disagrees with the way that Java forces one to
 declare and catch exceptions because it encourages mediocre
 programmers to hide exceptions which is a very nasty practice.  (Even Sun
 programmers do this quite regularly in the Java libraries,
 eg. <code>System.out.println()</code>!) It also clutters
 the code for no good reason.  IMHO Java's "checked" exceptions 
 add no value whatsoever in practice.)<P> */

public abstract class SException extends RuntimeException {
	private Throwable nestedException = null;
	
	/** A nested exception.  Stack trace will include both
	 <code>message</code> and as well as any message in
	 <code>nestedException</code>.*/
	public SException (String message, Throwable nestedException) {
		super("???" + message);
		this.nestedException = nestedException;
	}
	
	public SException (String message) {
		super("???" + message);
		this.nestedException = null;
	}
	
	public SException (Throwable nestedException) {
		super("??? Nested ");
		this.nestedException = nestedException;
	}
	
	/** Avoid using this one, include message.*/
	public SException() {
		super("???");
	}
	
	/** Prints all the exception messages and then just prints the inner
	 stack trace which is usually the relevant one.  These are
	 normmaly only called by the System for uncaught errors.*/
	public void printStackTrace(PrintWriter printer) {
		printer.println("SException " + toString());
		if (nestedException == null)
			super.printStackTrace(printer);
		else
			nestedException.printStackTrace(printer);
	}
	public void printStackTrace(PrintStream printer) {
		if (printer == System.err) 
			printer = System.out; // Stops intermingling of output.
		printer.println("SException " + toString());
		if (nestedException == null)
			super.printStackTrace(printer);
		else
			nestedException.printStackTrace(printer);
	}
	public void printStackTrace() {
		printStackTrace(System.err);
	}
	
	/** Contains both the message and the nestedException message. */
	public String toString() {
		return super.toString() 
		+ (nestedException != null ? ": " + nestedException : "");
	}
	
	/** Probable bug in user's program.*/
	public static class Error extends SException {
		public Error (String message, Throwable nestedException) {
			super(message, nestedException);
		}
		public Error(String message) {
			super(message);
		}
		public Error (Throwable nestedException) {
			super(nestedException);
		}
		public Error() {
			super();
		}
	}
	
	/** Probable bug in SimpleORM.*/
	public static class InternalError extends SException {
		public InternalError (String message, Throwable nestedException) {
			super(message, nestedException);
		}
		public InternalError(String message) {
			super(message);
		}
		public InternalError (Throwable nestedException) {
			super(nestedException);
		}
		public InternalError() {
			super();
		}
	}
	
	/** Chained JDBC Exception, could be anything as JDBC does not
	 separate exceptions out and provides minimal information about
	 their underlying causes.*/
	public static class JDBC extends SException {
		public JDBC (String message, Throwable nestedException) {
			super(message, nestedException);
		}
		public JDBC(String message) {
			super(message);
		}
		public JDBC (Throwable nestedException) {
			super(nestedException);
		}
		public JDBC() {
			super();
		}
	}
	
	/** Errors in data or environment at runtime, not necessarily a
	 programming bug. */
	public static class Data extends SException {
		public Data (String message, Throwable nestedException) {
			super(message, nestedException);
		}
		public Data(String message) {
			super(message);
		}
		public Data (Throwable nestedException) {
			super(nestedException);
		}
		public Data() {
			super();
		}
	}
	
	/** Exception thrown due to failed unit test cases.*/
	public static class Test extends SException {
		public Test (String message, Throwable nestedException) {
			super(message, nestedException);
		}
		public Test(String message) {
			super(message);
		}
		public Test (Throwable nestedException) {
			super(nestedException);
		}
		public Test() {
			super();
		}
	}
}

