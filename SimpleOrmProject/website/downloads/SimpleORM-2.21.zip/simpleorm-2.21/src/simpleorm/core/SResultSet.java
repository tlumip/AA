package simpleorm.core;
import  simpleorm.properties.*;
import java.sql.*;

/*
 * Copyright (c) 2002 Southern Cross Software Queensland (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/** This class is analagous to a JDBC result set.  It is returned by
 <code>sPreparedStatement.execute()</code> and is then used to access
 individual rows.<p>
 
 @see SPreparedStatement
 */
public class SResultSet extends SPropertyMap {
	SPreparedStatement sPreparedStatement = null;
	ResultSet jdbcResultSet = null;
	long nrRetrieved = 0; 
	boolean finished = false;
	
	SResultSet(){}
	SResultSet(ResultSet rs, SPreparedStatement ps) {
		jdbcResultSet = rs;
		sPreparedStatement = ps; 
		
		SConnection scon = SConnection.getBegunConnection();
		scon.getDriver().initResultSet(this);
	}
	public ResultSet getDBResultSet(){return jdbcResultSet;}
	public SPreparedStatement getSPreparedStatement(){return sPreparedStatement;}
	
	/** See if there is another record to retrieve.  The loop is the
	 same as JDBC, ie. <code>while (rs.hasNext()) {rec = getRecord();}</code><p>
	 
	 If more than <code>maxRows</code> are retrieved an exception is
	 thrown.  Use this to prevent run away queries.<p>
	 
	 Note that this is different from SPreparedStatement.Offset and
	 Limit, which may change the generated SQL to only retrieve this
	 number of rows.<p>
	 
	 Automatically closes the cursor when the last record is retrieved.<p>
	 */
	public boolean hasNext(int maxRows) {
		if (finished)
			throw new SException.Error(
					"hasNext called twice after last record read " + this);
		if (nrRetrieved >= sPreparedStatement.limit && sPreparedStatement.limit > 0) {
			// This may not be necessary if the driver handles offset/limit OK.
			finished = true;
			close();
			return false;
		}
		boolean next=false;
		try { next = jdbcResultSet.next(); } 
		catch (Exception ne1) {throw new SException.JDBC(ne1);}
		if (next) nrRetrieved++;
		if (nrRetrieved > maxRows) {
			close();
			throw new SException.Data(
					"Nr Rows Retrieved " + nrRetrieved + " > max rows " + maxRows + " for " + this);
		}
		if (!next) {
			finished = true;
			close();
		}
		return next;
	}
	
	public boolean hasNext() {
		return hasNext(Integer.MAX_VALUE);
	}
	
	/** Returns the number of records retrieved so far. 
	 This excludes any rows required to implement Offset. */
	public long getNrRetrieved() {return nrRetrieved;}
	
	/** Retrieves the next record from the result set.
	 <code>hasNext()</code> must have been called and returned
	 true. */
	public SRecordInstance getRecord() {
		
		if (finished)
			throw new SException.Error("Attempt to getRecord after hasNext false.");
		if (sPreparedStatement == null)
			throw new SException.Error("Closed Connection");
		
		/// Double check same thread
		SConnection scon = SConnection.getBegunConnection();
		if (sPreparedStatement.sConnection != scon) 
			throw new SException.Error(
					"Inconsistent Connections " 
					+ sPreparedStatement + sPreparedStatement.sConnection + scon);
		
		/// Create New Instance.  Too early to know if already in transCache.
		SRecordInstance instance = null;
		SRecordMeta sRecordMeta = sPreparedStatement.sRecordMeta;
		try {
			instance = (SRecordInstance)sRecordMeta.userClass.newInstance(); // an SRecordInstance
		} catch (Exception ie) {throw new SException.Data(ie);}
		
		/// Retrieve the row into Record.
		SFieldMeta[] selectList = sPreparedStatement.selectList;
		SRecordFinder.retrieveRecord(instance, selectList, jdbcResultSet, 
				sPreparedStatement.readOnly, sPreparedStatement.optimistic, false);
		
		/// Check to see if it is already in Transaction Cache
		SRecordInstance cache 
		= (SRecordInstance)scon.transactionCache.get(instance);
		//System.out.println("CACHED " + cache);
		if (cache == null) { // New record, add to cache.
			scon.transactionCache.put(instance, instance);
			instance.sConnection = scon;
			if (SLog.slog.enableQueries())
				SLog.slog.queries("getRecord: " + instance + " (from database)");
			return instance;
		} else {
			if (cache.sConnection != scon) 
				throw new SException.Error(
						"Inconsistent Connections " 
						+ cache + cache.sConnection + scon);
			if (SLog.slog.enableQueries())
				SLog.slog.queries("getRecord: " + cache + " (from cache)");
			return cache;
			// ### But does not promote to non-ReadOnly or add extra fields.
		}
	} // getRecord()
	
	
	
	/**
	 Retrieves all rows as an SArrayList.  An exception is thrown if
	 more than maxRows are retrieved to trap unbounded queries, and is
	 mandatory.  Provide a generous value, eg. if you expect about 10
	 rows, specify 1000.<p>
	 
	 Note that there is no point in creating the SArrayList object if
	 you just want to iterate over the rows.  An explicit loop can
	 also give you more control over how a collection is created.*/
	public SArrayList getArrayList(int maxRows) {
		SArrayList al = new SArrayList();
		for (int ax=0; hasNext(); ax++) {
			if (ax >= maxRows) {
				close();
				throw new SException.Error("More than " + maxRows + " rows in " + this);
			}
			al.add(getRecord());
		}
		return al;
	}
	
	/** Convenience routine for retrieving at most one row.  Throws an
	 exception if there are multiple rows.  Returns null if no rows
	 (not a dummy SRecrodInstance -- we may not have a key). */
	public SRecordInstance getOnlyRecord() {
		if (!hasNext()) return null;
		SRecordInstance res = getRecord();
		if (hasNext()) {
			String msg = "More than one record in result set " + this + getRecord();
			close();
			throw new SException.Error(msg);
		}
		return res;
	}
	
	/** Close the underlying JDBC result set, if required.  SimpleORM
	 normally closes the cursor automatically by {@link #hasNext},
	 provided that you retrieve all the records (the common case).
	 Some JDBC dirvers (eg. Oracle) have bugs that require cusrors to
	 always be closed.  Closing a cursor twice is OK.  From 1.05
	 closing the cursor also closes the prepared statement.  */
	public void close() {
		if ( jdbcResultSet != null )
			try {
				jdbcResultSet.close();
			} catch (Exception ce) {
				throw new SException.JDBC("Closing " + this, ce);
			}
			jdbcResultSet = null;
			
			if ( sPreparedStatement != null) {
				sPreparedStatement.close();
				sPreparedStatement = null;
			}
	}
	
	/** Retrieves the underlying JDBC result set.  Dangerous.  But
	 allows arbitrary JDBC calls to be made if really necessary. */
	public ResultSet getJDBCResultSet() {
		return jdbcResultSet;
	}
	
	public String toString() {
		return "[SResultSet " + sPreparedStatement + "]";
	}
}
