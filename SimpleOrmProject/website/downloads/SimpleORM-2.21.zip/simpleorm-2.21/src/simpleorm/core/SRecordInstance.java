package simpleorm.core;

import java.sql.*;
import java.math.BigDecimal;

/*
 * Copyright (c) 2002 Southern Cross Software Queensland (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/** Each SRecordInstance represents an individual record in memory
 that either correspond to a row in the database or are a new
 record that has yet to be inserted.<p>
 
 RecordInstances are created by either {@link
 SRecordMeta#findOrCreate findOrCreate} or {@link SResultSet#getRecord}.  The
 former selects a specific record by primary key, while the latter
 retrieves a record from a general query result set.<p>
 
 The main methods are <code>get*</code> and <code>set*</code> which
 get and set field values of the record.  {@link #deleteRecord}
 deletes a row. <p>
 
 No two RecordInstances can have the same primary key field values
 within the same connection.  Attempts to retrieve the same row
 twice will simple return a pointer to an existing SRecordInstance.
 There is no relationship between RecordInstances in different
 connections -- all locking is done by the underlying database.<p>
 
 SRecordsInstances may also be {@link #detach}ed from a connection
 and then subsequently {@link #attach}ed to another connection.
 Optimistic locking is used.<p>
 
 ### Serializable, but only naively.  Should throw exception if one
 attempts to serialize an attached record, or references to purged
 records.  When deserializing, should match meta data with current
 SRecordMeta.  The following of links to referenced records should
 be manual and should be part of the serialization process and not
 the detachment process.<p> 
 */

public abstract class SRecordInstance implements SSerializable
//,java.io.Serializable // J# problems
{
	
	/** This must be defined in every user record's definition to access
	 the SRecord which provides the meta data for this instance.  It
	 is normally defined as:-<p>
	 <pre>  SRecord getMeta() { return meta; }; </pre> <p>
	 
	 The actual <code>meta</code> variable is thus not Serialized,
	 but it would not be anyway as it is usually static. */
	public abstract SRecordMeta getMeta();
	
	/** The one connection to which this Instance is glued. Instances
	 may never be shared across connections.*/
	transient SConnection sConnection = null;
	
	/** The actual field values for this record instance.  Null if
	 destroyed.  Elements null if retrieved data SQL Null. */
	protected Object fieldValues[] = new Object[getMeta().sFieldMetas.size()];
	
	/** INstance BitSet, one per field instance in fieldValues, in
	 particular INS_DIRTY which indicates that the field has been
	 modified.  Values are INS_* */
	byte bitSets[] = new
	byte[getMeta().sFieldMetas.size()];
	
	/** The copy of the fieldValues used for optimistic locking.  null
	 means not optimistically locked.*/
	Object [] optimisticFieldValues = null;
	
	/** True if queried read only.  Ie. either selected FOR UPDATE,
	 optimistically locked, or new and not read only.  */
	boolean readOnly = true;
	
	/** -1: not in sConnection.updateList either because 1. not dirty or
	 2. not attached.*/
	int updateListIndex = -1; // (Transient means set to 0, not -1!)
	
	/** Is dirty and needs to be flushed.  But may not be in
	 sConnection.updateList because the instance is detached. */
	boolean dirty = false;
	
	
	/** Need to delete at commit. */
	boolean deleted = false;
	
	/** Set after <code>findOrInsert()</code> that does not find the row
	 already in the database. */
	boolean newRow = false;
	
	/** @see #wasInCache()
	*/
	boolean wasInCache = false;
	
	/** Should only be called by SimpleORM, but difficult to protect. */
	public SRecordInstance(){}
	
	/**
	 Determines whehter two SRecordInstances are for the same
	 SRecordMeta and have the same primary key fields.<p>
	 
	 This is purely for the purpose of putting
	 <code>SRecordInstances</code> in the
	 <code>SConnection.transactionCache</code>.  This is done as
	 <code>tc.put(SRecordInstance, SRecordInstance)</code>, ie the
	 instance is used for both the key and the body.  This avoids
	 having to create a separate primary key object for each record
	 instance.<p>
	 
	 It only foreign keys, not referenced SRecordInstances which may
	 be null if the parent record has not been retrieved.  */
	public boolean equals(Object key2) {
		if (this == key2) return true;
		if ( !(key2 instanceof SRecordInstance) )	return false;

		SRecordInstance pkey2 = (SRecordInstance)key2;
		SRecordMeta meta = getMeta();
		if (meta != pkey2.getMeta()) return false;
		for (int kx=0; kx<meta.keySFieldMetas.size(); kx++) {
			SFieldMeta fmeta = (SFieldMeta)meta.keySFieldMetas.get(kx);
			if (!(fmeta instanceof SFieldReference)) {
				int keyx = fmeta.fieldIndex;
				Object k1 = this.fieldValues[keyx];
				Object k2 = pkey2.fieldValues[keyx];
				if (!k1.equals(k2)) return false; // Can never be null
			}
		}
		return true;
	}
	/** See <code>equals()</code>.*/
	public int hashCode() {
		// ## Could cache this calculation.
		//SLog.slog.debug("hashCode " + allFields());
		SRecordMeta meta = getMeta();
		int code = meta.getString(SCon.STABLE_NAME).hashCode();
		for (int kx=0; kx<meta.keySFieldMetas.size(); kx++) {
			SFieldMeta fmeta = (SFieldMeta)meta.keySFieldMetas.get(kx);
			if (!(fmeta instanceof SFieldReference)) {
				int keyx = fmeta.fieldIndex;
				Object k1 = this.fieldValues[keyx];
				code += k1.hashCode() * ((kx+1) * 13); // Can never be null
			}
		}
		return code;
	}
		
	/**
	 Returns the field's value as a Java Object.  Methods such as
	 <code>getString()</code> dispach to this method but are
	 generally more convenient because the cast the result to the
	 correct type.  This method in turn just dispaches to
	 <code>field.getFieldValue()</code>, ie. it is the declaredtype
	 of the SField that determines how the value is retrieved.<p> */
	public Object getObject(SFieldMeta field) {
		Object cacheValue = field.getFieldValue(this, 0);
		return cacheValue;
	}
	/** For references only. */
	public Object getObject(SFieldReference field, long sqy_flags) {
		Object cacheValue = field.getFieldValue(this, sqy_flags);
		return cacheValue;
	}
	
	/**
	 Generic routine to set a fields value.  Just dispaches to
	 <code>field.setFieldValue()</code><p>
	 */
	public void setObject(SFieldMeta field, Object value) {
		//SLog.slog.debug("setObject " + field + " = " + value + ": " + value.getClass());
		field.setFieldValue(this, value);
	}
	
	public boolean isNull(SFieldMeta field){
		return getObject(field) == null; }
	public void setNull(SFieldMeta field){
		setObject(field, null); }
	
	/** True if field is the empty value.  Currently just tests
	 <code>getObject() == null</code>.  But other options will be added
	 later to allow "" to be treated as null.
	 @see #SMANDATORY
	 */
	public boolean isEmpty(SFieldMeta field){
		return getObject(field) == null; }
	/** Sets field to be empty, ie. currently <code>setObject(,
	 null)</code>. But other options will be added later.
	 @see #SMANDATORY */
	public void setEmpty(SFieldMeta field){
		setObject(field, null); }
	
	/** Gets the value of field cast to a String, trimed of trailing
	 spaces.  This is equivalent to
	 <code>getObject().toString().trimTrailingSpaces()</code>.  So
	 the field type itself need not be <code>SFieldString</code>, but
	 just something that can be cast to a String.  Trailing spaces
	 can be a problem with some databases and fileds declared
	 <code>CHAR</code>.<p>
	 
	 Note that if you do not want trailing spaces trimmed, then
	 just call getObject().toString() manually.
	 (For CHAR fields, most dbs/jdbc drivers seem to trim, but this is
	 highly inconsistent.)<p>
	 
	 ## Trimming is an issue with CHAR style fields that pad with spaces.
	 Currently we always read from database into the fields without trimming.
	 The idea being to let the SimpleORM user get at the raw query result using 
	 getObject, whatever that raw result is.<p>
	 
	 Most DBs seem to trim for us.  But some may not, and some may require the
	 trailing spaces on queries.  Certainly trailing spaces in the objects will
	 upset the record cache, and there is some dubious code in SRecordFinder.retrieveRecord()
	 to handle this.<p>
	 
	 I think that for CHAR fields we need to always trim at database read, and pad where
	 needed.  This should also be dispatched to DB handler.  I think that Oracle gives grief.
	 (Note that trim means trailing spaces, leading should be left alone.)<p>
	 
	 I have not done this because it would require testing on many datbases.<p> 
	 */
	public String getString(SFieldMeta field) {
		Object val = getObject(field);
		if (val == null) return null;
		String str = val.toString();
		int end = str.length() - 1;
		int sx=end;
		for (; sx>-1 && str.charAt(sx) == ' ' ; sx--);
		if (sx != end)
			return str.substring(0, sx+1);
		else
			return str;
	}
	public void setString(SFieldMeta field, String value) {
		setObject(field, value);
	}
	
	/** Casts getObject() to int iff a Number, see getString().
	 Returns 0 if null, following JDBC. */
	public int getInt(SFieldMeta field) {
		Object val = getObject(field);
		return SJSharp.object2Int(val);
	}
	public void setInt(SFieldMeta field, int value) {
		setObject(field, SJSharp.newInteger(value));
	}
	
	/** Casts getObject() to long iff a Number, see getString().
	 Returns 0 if null, following JDBC.  Note that longs may not be
	 accurately supported by the database -- see SFieldLong.*/
	public long getLong(SFieldMeta field) {
		Object val = getObject(field);
		return SJSharp.object2Long(val);
	}
	public void setLong(SFieldMeta field, long value) {
		setObject(field, SJSharp.newLong(value));
	}
	
	/** Casts getObject() to double iff a Number, see getString().
	 Returns 0 if null, following JDBC. */
	public double getDouble(SFieldMeta field) {
		Object val = getObject(field);
		return SJSharp.object2Double(val);
	}
	public void setDouble(SFieldMeta field, double value) {
		setObject(field, SJSharp.newDouble(value));
	}
	
	/** Casts getObject() to double iff a Number, see getString().
	 Returns false if null. */
	public boolean getBoolean(SFieldMeta field) {
		Object val = getObject(field);
		return val == Boolean.TRUE;
	}
	public void setBoolean(SFieldMeta field, boolean value) {
		setObject(field, value?Boolean.TRUE:Boolean.FALSE);
	}
	
	/** etc. for Timestamp. */
	public java.sql.Timestamp getTimestamp(SFieldMeta field) {
		java.sql.Timestamp val =
			((java.sql.Timestamp)getObject(field));
		return val;
	}
	
	/** Note that value should normally be a java.sql.Timestamp (a
	 subclass of java.util.Date).  However, if it is a java.util.Date
	 instead, then it will replaced by a new java.sql.Timestamp
	 object before being set.  This is convenient for people using
	 java.util.Date as their main date type.  */
	public void setTimestamp(SFieldMeta field,  java.util.Date value) {
		setObject(field, value);
	}
	/** etc. for Date. */
	public java.sql.Date getDate(SFieldMeta field) {
		java.sql.Date val =
			((java.sql.Date)getObject(field));
		return val;
	}
	/** See {@link #setTimestamp} for discussion of Date parameter.*/
	public void setDate(SFieldMeta field, java.util.Date value) {
		setObject(field, value);
	}
	
	/** etc. for Time. */
	public java.sql.Time getTime(SFieldMeta field) {
		java.sql.Time val =
			((java.sql.Time)getObject(field));
		return val;
	}
	/** See {@link #setTimestamp} for discussion of Date parameter.*/
	public void setTime(SFieldMeta field, java.util.Date value) {
		setObject(field, value);
	}
	
	/** etc. for BigDecimal. */
	public BigDecimal getBigDecimal(SFieldMeta field) {
		BigDecimal val = ((BigDecimal)getObject(field));
		return val;
	}
	public void setBigDecimal(SFieldMeta field, BigDecimal value) {
		setObject(field, value);
	}
	
	/** Casts getObject() to byte[]. */
	public byte[] getBytes(SFieldMeta field) {
		Object val = getObject(field);
		return (byte[])val;
	}
	public void setBytes(SFieldMeta field, byte[] value) {
		setObject(field, value);
	}
	
	/** Gets a record referenced by <code>this.field</code>.  does a
	 lazy lookup if necessary. */
	public SRecordInstance getReference(SFieldReference field, long sqy_flags){
		// sqy_bitSet etc. needs to be passed through.
		return (SRecordInstance)getObject(field, sqy_flags);
	}
	public SRecordInstance getReference(SFieldReference field) {
		return getReference(field, 0);
	}
	public void setReference(SFieldReference field, SRecordInstance value){
		setObject(field, value);
	}
	/**
	 Same as getReference, except that if the referenced record is not
	 already in the cache then it will simply return Boolean.FALSE.
	 Particularily useful for detached records where it is not possible
	 to do such a query.<p>
	 
	 If the underlying scalar key values are null, then this always
	 null because there is no record to retrieve.  It is only for a
	 non-null, non-retrieved references that this returns FALSE.
	 */
	public Object getReferenceNoQuery(SFieldReference field) {
		return getObject(field, SCon.SQY_REFERENCE_NO_QUERY);
	}
	
	/** Sets this record to be dirty so that it will be updated in the
	 database. Normally done implicitly by setting a specific column.
	 But may occasionally be useful after a findOrInsert() to add a
	 record that contains nothing appart from its primary key. */
	public void setDirty() {
		if (readOnly)
			throw new SException.Error(
					"Record retrieved read only " + this);
		dirty = true;
		if (sConnection != null && updateListIndex == -1) {
			updateListIndex = sConnection.updateList.size();
			sConnection.updateList.add(this);
		}
	}
	
	/** True iff this record is dirty but not yet flushed to the
	 database.  May be both dirty and unattached.<p>
	 
	 A record is not dirty if a record has been flushed to the
	 database but the transaction not committed.<p>
	 
	 ## Should add <tt>wasEverDirty</tt> method for both record and
	 fields for validation tests. */
	public boolean isDirty() { return dirty; }
	
	
	/** Tests whether just field is dirty. */
	public boolean isDirty(SFieldMeta field) {
		boolean dirty = (bitSets[field.fieldIndex] & SCon.INS_DIRTY) != 0;
		return dirty;
	}
	
	/** Was in the cache before the most recent findOrCreate.  
	 * (Will always been in the cache after a findOrCreate.)
	 * Used to prevent two create()s for the same key.
	 * Also for unit tests.
	*/
  public boolean wasInCache() {
  	return wasInCache;
  }
  
	/** Sets a flag to delete this record when the transaction is
	 commited.  The record is not removed from the
	 transaction cache.  Any future <code>findOrCreate</code> will
	 thus return the deleted record but its fields may not be
	 referenced.  (<code>isDeleted</code> can be used to determine
	 that the record has been deleted.)<p>
	 
	 The record is only deleted from the database when the
	 transaction is committed or is flushed.  Thus a transaction that
	 nulls out references to a parent record and then deletes the
	 parent record will not cause a referential integrity violation
	 because the update order is preserved so that the updates will
	 (normally) be performed before the deletes.<p>
	 
	 Note that for Optimistic locks only those fields that were
	 retrieved are checked for locks.  */
	public void deleteRecord() {
		if (fieldValues == null || deleted)
			throw new SException.Error("Cannot delete destroyed record " + this);
		setDirty();
		deleted = true;
	}
	
	public boolean isDeleted() { return deleted; }
	
	/** Often called after {SRecordMeta#findOrCreate} to determine
	 whether a row was retrieved from the database (not a new row) or
	 whether this record represents a new row that will be inserted
	 when it is flushed.*/
	public boolean isNewRow(){return newRow;}
	/** Throws an excpetion if !{@link #isNewRow}.  Handy, use often in
	 your code to trap nasty errors. */
	public void assertNewRow(){
		if (!isNewRow()) throw new SException.Error("Not a new row " + this);
	}
	/** @see #assertNewRow */
	public void assertNotNewRow(){
		if (isNewRow()) throw new SException.Error("Is a new row " + this);
	}
	
	/** True if the record has valid data, ie. it has not been
	 destroyed.  (This has nothing to do with validateRecord.)*/
	public boolean isValid() {
		return fieldValues != null;
	}
	
	/** True if the field has been queried as part of the current
	 transaction and so a get is valid.  Use this to guard
	 validations if partial column queries are performed.  See
	 isDirty.*/
	public boolean isValid(SFieldMeta field) {
		return (bitSets[field.fieldIndex] & SCon.INS_VALID) != 0;
	}
	
	/*
	 * Fuzzy Semantics for Nulls.
	 * @deprecated use getReferenceNoQuery
	 
	 public boolean isReferenceAvailable( SFieldReference reference )
	 {
	 SRecordInstance result
	 = (SRecordInstance)fieldValues[reference.fieldIndex];
	 
	 return result != null && result.isValid();
	 }
	 */
	
	/** Flush this instance to the database.  Normally called by
	 <code>SConnection.flush()</code> in reponse to
	 <code>commit</code> but can also be called expicitly if the
	 update order needs to be modified.  This method does nothing
	 unless the record is dirty.<p>
	 
	 ## This should really utilize the new batching techniques if the
	 JDBC driver supports them.  This would substantially minimize
	 the nr of round trips to the server.<p>
	 
	 @see SConnection#flush
	 */
	public void flush() { 
		SRecordUpdater.flush(this);
	}
	
	/** Returns the list of fields that are used as part of the
	 optimistic locking.  Includes Primary key fields, any valid
	 fields that are dirty, but not references.*/
	SArrayList keyFieldMetas(boolean optimistic, Object[] keyMetaValues) {
		SRecordMeta meta = getMeta();
		SArrayList res = new SArrayList(meta.sFieldMetas.size());
		for (int fx=0, addCounter=0; fx < meta.sFieldMetas.size(); fx++) {
			SFieldMeta fld = (SFieldMeta)meta.sFieldMetas.get(fx);
			if (optimistic) {
				if ((bitSets[fld.fieldIndex] & SCon.INS_VALID) != 0
						&& ( (bitSets[fld.fieldIndex] & SCon.INS_DIRTY) != 0
								|| fld.isPrimaryKey || deleted)
								&& !(fld instanceof SFieldReference) )
					if (!fld.getBoolean(SCon.SOPTIMISTIC_UNCHECKED))
					{
						res.add(fld);
						keyMetaValues[addCounter++] = optimisticFieldValues[fld.fieldIndex];
					}
			} else { // pesimistic
				if ( fld.isPrimaryKey && !(fld instanceof SFieldReference) )
				{
					res.add(fld);
					keyMetaValues[addCounter++] = fieldValues[fld.fieldIndex];
				}
			}
		}
		return res;
	}
	
	/** Destroys this instance so that it can no longer be used.  Also
	 nulls out variables so to reduce risk of memory leaks.  Note
	 that it does not remove the record from the transaction cache
	 and update list -- it cannot be called on its
	 own.*/
	void incompleteDestroy(){
		//SLog.slog.temp("Destroying " + ri);
		fieldValues = null;
		bitSets = null;
		updateListIndex = -2;
		sConnection = null;
	}
	
	/** Flushes this record instance to the database, removes it from
	 the transaction cache, and then destroys the record so that it
	 can no longer be used.  Any future <code>findOrCreate</code>
	 will requery the data base and produce a new record.<p>
	 
	 This is useful if one wants to do raw JDBC updates on the
	 record, and be guaranteed not to have an inconsistent cache.
	 (Where bulk updates can be used they are several times faster
	 than updates made via the JVM -- see the benchmarks section in
	 the white paper.)<p>
	 
	 Problems with the update order can generally be avoided by first
	 flushing the entire connection.<p>
	 
	 @see SRecordMeta#flushAndPurge
	 @see SConnection#flushAndPurge
	 @see SConnection#flush
	 */
	public void flushAndPurge(){
		flush();
		dirtyPurge();
	}
	
	
	/**
	 Removes this record from the cache but without flushing it.  Any
	 changes to it will be lost.  This might be useful if the record is
	 being manually updated/deleted and you want to deliberately ignore
	 any direct changes.<p>
	 
	 Dangerous, use with care.<p>
	 
	 @see #flushAndPurge
	 */
	public void dirtyPurge(){
		SConnection scon = SConnection.getBegunConnection();
		scon.transactionCache.remove(this);
		incompleteDestroy();
	}
	
	/** True if this instance is attached to the current begun
	 transaction.  Exception if is attached but not to the current
	 transaction or the current transaction has not begun. */
	public boolean isAttached(){
		if (sConnection == null) return false;
		SConnection scon = SConnection.getBegunConnection();
		if (sConnection != scon) throw new SException.Error(
				"Instance " + toStringDefault() + " attached to " + sConnection
				+ " but current connection is " + scon);
		return true;
	}
	
	/** Set this record to be locked Optimistically.  Assert that it is
	 not dirty and copy the current value of all relevant fields.
	 These can be compared with values stored in the database at
	 flush time.<p>
	 
	 The copy is cheap because it is only copying pointers.  However,
	 if the optimisitic lock fails then an exception will be thrown.
	 Mainly used for long lived transactions. <p>
	 */
	void setOptimistic(boolean redo) {
		if (readOnly) return;
		if (optimisticFieldValues == null) {
			// Already done, maybe findOrCreating the same record twice
			if (isDirty())
				throw new SException.Error(
						"Cannot make dirty record optimisitic " + this);
			optimisticFieldValues = new Object[fieldValues.length];
			redo = true;
		}
		if (redo)
			for (int ox=0; ox < fieldValues.length; ox++) {
				if ((bitSets[ox] & SCon.INS_VALID) != 0)
					optimisticFieldValues[ox] = fieldValues[ox];
			}
	}
	
	/** Detach this instance from the current transactions.  Sets
	 optimistic locking if the record was updatable. ,p>
	 
	 If a future query in the same transaction retrieves a record
	 with the same key then it will be a different instance.
	 Ie. this really does detach the record from the transaction.<p>
	 
	 Nulls any references to records that have not already been
	 detached so that they will not be serialized.  The keys are kept
	 so that the references can be reconstructed later.  (This does
	 NOT recursively detach any referenced records -- you have to
	 explicitly detach all the records that you need.)<p>
	 
	 Set <code>nullRefs<code> to false to break instance indirect circular
	 references, eg. if an Employee e  manages someone that manages e.  Very
	 rarely needed.  It is OK to detach a record twice.*/
	public void detach(boolean nullRefs){
		setOptimistic(false);
		if (isDirty()) throw new SException.InternalError(
				"Dirty but not updatable." + this);
		if (isAttached())
			sConnection.transactionCache.remove(this);
		sConnection = null;
		
		// Null any non detached references.
		if (nullRefs) {
			SArrayList fields = getMeta().sFieldMetas;
			for (int fx=0; fx<fields.size(); fx++) {
				SFieldMeta field = (SFieldMeta)fields.get(fx);
				if (field != null && field instanceof SFieldReference) {
					SRecordInstance refed =
						(SRecordInstance)fieldValues[field.fieldIndex];
					if (refed != null && refed.isAttached())
						fieldValues[field.fieldIndex] = null;
				}
			}
		}
	}
	/** detach(true) */
	public void detach(){detach(true);}
	
	/** Attach a detached record to the current transaction.  A record
	 with the same key must not already exist in this transaction,
	 although this restriction may be relaxed later.  Recursively
	 attaches any referenced records.  <p>
	 
	 Currently, the returned value is just <tt>this</tt>.  However, a
	 future version may allow the unattached record to be merged with
	 an existing record, so one should always assume that the record
	 may change identity during attachment.<p>
	 
	 Attaching the same record twice is OK.<p>
	 
	 If the record has a generated primary key then the key is generated 
	 as part of the attachement processing.<p>
	 
	 */
	public SRecordInstance attach(){
		/// Check not already attached
		if (isAttached()) return this;
		
		SConnection scon = SConnection.getBegunConnection();
		
		// If this record has a generated key which has not yet been set, it must have
		// been creatd with SRecordMeta.createDetached(). We must generate a key for
		// it here
		SRecordMeta meta = getMeta();
		SFieldMeta keyField = (SFieldMeta)meta.keySFieldMetas.get( 0 );
		SGenerator gen = (SGenerator)keyField.getProperty( SCon.SGENERATED_KEY );
		if ( gen != null &&     // has generated key
				(!isValid( keyField ) || getObject( keyField ) == null ) )    // it hasn't been set
		{
			gen.updateWithGeneratedKey(this, keyField);
			
			//long generatedId = scon.sDriver.generateKey(meta, keyField);
			//setLong( keyField, generatedId );
		}
		else    // Key has been (or should have been) set
		{
			// Ensure that all primary key fields have been set
			for (int kx=0; kx<meta.keySFieldMetas.size(); kx++)
			{
				keyField = (SFieldMeta)meta.keySFieldMetas.get(kx);
				if ( !(keyField instanceof SFieldReference) )
				{
					if ( !isValid( keyField ) || getObject( keyField ) == null )
					{
						throw new SException.Error( "Attempting to attach a record with null key field " + keyField
								+ ". This is most likely because you created a record using "
								+ "createDeatched(), and forgot to set one of its primary keys, "
								+ "or have set it to null." );
					}
				}
			}
			
			/// Check no other record in transaction with the same key
			SRecordInstance existing
			= (SRecordInstance) scon.transactionCache.get(this);
			if (existing != null && existing != this)
				throw new SException.Error(
						"Cannot attach " + this
						+" because there is already a record " + existing);
		}
		
		/// Attach this record
		sConnection = scon;
		scon.transactionCache.put(this, this);
		if (isDirty())
			setDirty(); // ie. add to sConnection.updateList.
		
		
		/// Recursively attach any referenced records.
		SArrayList fields = meta.sFieldMetas;
		for (int fx=0; fx<fields.size(); fx++) {
			SFieldMeta field = (SFieldMeta)fields.get(fx);
			if (field instanceof SFieldReference) {
				SRecordInstance refed =
					(SRecordInstance)fieldValues[field.fieldIndex];
				if (refed != null && refed.isValid())
					// ## isValid test only because we incorrectly serialize them.
					refed.attach();
			}
		}
		
		return this; // May change later.
	}
	
	/** toString just shows the Key field(s).  It is meant to be
	 consise, often used as part of longer messages.*/
	public String toString() {
		return toStringDefault();
	}
	
	/**
	 * Default behavior of toString(). This was split out from the toString() method
	 * to avoid infinite recursion if a subclass of SRecordInstance overrode toString()
	 * to use any of the get...() methods.
	 */
	String toStringDefault()
	{
		StringBuffer ret = new StringBuffer(
				"[" + SUte.cleanClass(getClass()) + " ");
		if (fieldValues == null)
			ret.append("[Destroyed SRecordInstance]");
		else {
			boolean first = true;
			for (int kx=0; kx<getMeta().keySFieldMetas.size(); kx++) {
				SFieldMeta fld = (SFieldMeta)getMeta().keySFieldMetas.get(kx);
				if (!(fld instanceof SFieldReference)) {
					//.sFieldReference == null) { // Not foreign key.
					if (!first) ret.append(", ");
					first = false;
					int pkx = fld.fieldIndex;
					//ret.append(fld);
					ret.append(fieldValues[pkx]);
				}
			}
		}
		if (newRow) ret.append(" NewRecord");
		if (deleted) ret.append(" Deleted");
		ret.append("]");
		return ret.toString();
	}
	
	/** For debugging like toString(), but shows all the fields. */
	public String allFields() {
		StringBuffer ret = new StringBuffer(
				"[" + SUte.cleanClass(getClass()) + " ");
		if (fieldValues == null)
			ret.append("[Destroyed SRecordInstance]");
		else {
			SArrayList fields = getMeta().sFieldMetas;
			for (int px=0; px<fields.size(); px++) {
				if (px > 0) ret.append("| ");
				int idx = ((SFieldMeta)fields.get(px)).fieldIndex;
				ret.append(fieldValues[idx]);
			}
		}
		if (newRow) ret.append(" NewRecord");
		if (deleted) ret.append(" Deleted");
		ret.append("]");
		return ret.toString();
	}
	
	/** The main field validation method, this is specialized for
	 records that need to perform field level validation.  
	 It is called each time a field is set a value, (now) including keys.<p>
	 
	 Throw an SValidationException if not OK.  The value is not assigned, and
	 the transaction can continue.<p>
	 
	 This is called after the value has been converted to its proper
	 type, eg. from a String to a Double.  (Which is why it is not a
	 good place to also do conversions.)<p>
	 
	 This is called for key values as well. 
	 This is only for newly created records but is during the findOrCreate 
	 -- ie it is called even if the record is never made dirty and thus saved.   

	 See ADemo and ValidationTest for examples.  */
	public void validateField(SFieldMeta field, Object newValue) {
	}
	
	/** The main record validation method,
	 this is specialized for records that need to perform validation.
	 Throw an SValidationException if not OK.<p>
	 
	 This is called just before a record would be flushed.  Only
	 dirty records are validated.  If the validation fails then the
	 record is not flushed.  (It may also be called directly by the
	 application to validate the record before it is flushed.)<p>
	 
	 Use this routine when a record may be in a temporarily invalid
	 state, but which must be corrected before flushing.  This is
	 common when there is a more complex relationship between
	 different fields that cannot be validated until all the fields
	 have been assigned values.<p>
	 
	 If an exception is thrown then the condition will need to be
	 corrected or the transaction will need to be rolled back.<p>
	 
	 See ADemo for an example.  */
	public void validateRecord() {
	}
	
	
	/**
	 * This method is called if the record is detached, and a request is made for
	 * a reference that has not also been detached. This method gives you one last
	 * chance to return the referenced record before an exception is thrown.
	 * <p>
	 * By default, this method just returns null to indicate that no last-ditch effort
	 * is made to fetch missing references, so you must override it to do
	 * something more useful (i.e. fetch the reference from the database)
	 * <p>
	 * Warning: Note that because this record and the fetched reference are obtained
	 * in separate transactions, any consistency constraints between the two objects
	 * might not hold.
	 *
	 * @param reference The reference that is being followed
	 * @param keys Object[] keys for the reference, just as you would pass them
	 *  to THE REFERENCED record's findOrCreate()
	 * @return SRecordInstance Return the fetched record, or null, if no attempt was
	 *  made. NOTE: currently, this does not cover the awkward case where an attempt IS
	 *  made, but the value returned is NULL, anyway.
	 */
	protected SRecordInstance getReferenceWhileDetached( SFieldReference reference, Object[] keys )
	{
		return null;
	}
	
	/**
	 * Null direct references from this record instance to other
	 * instances.  Leaves the actual scalar referencing key fields
	 * alone.  May only be called on a detached object.  This method was
	 * created for two reasons:
	 *
	 * <ol>
	 * <li>Reduce communication burden when sending detached records from a client back
	 *  to the server for processing
	 * <li>Avoid problems when recursively attaching referenced records that we really did not want.
	 *  attach() currently does not allow multiple attach'es of same record. Even though this
	 *  reason may evenutually go away, the first reason will remain.
	 * </ol>
	 *
	 * @deprecated Detach has always nulled refferences, and attach allows a record to be attached multiple times.
	 */
	public void nullReferences()
	{
		SArrayList fields = getMeta().sFieldMetas;
		for (int fx=0; fx<fields.size(); fx++) {
			SFieldMeta field = (SFieldMeta)fields.get(fx);
			if (field instanceof SFieldReference) {
				fieldValues[field.fieldIndex] = null;
				if ( optimisticFieldValues != null )
				{
					optimisticFieldValues[field.fieldIndex] = null;
				}
			}
		}
	}
	
	/**
	 * Override Object.clone() to make copies of the internal fieldValues array.
	 * <p>This method may only be used while the object is detached.
	 * 
	 * @deprecated Probably not useful any more, and a little dangerous.
	 */
	public Object clone()
	{
		if ( isAttached() )
			throw new SException.Error( "Can't clone " + this + " while attached" );
		
		try
		{
			SRecordInstance clone = ( SRecordInstance ) super.clone();
			if ( fieldValues != null )
			{
				clone.fieldValues = new Object[fieldValues.length];
				System.arraycopy( fieldValues, 0, clone.fieldValues, 0, fieldValues.length );
			}
			return clone;
		}
		catch ( CloneNotSupportedException ex )
		{
			throw new SException.InternalError( "Should never happen, since this class implements Cloneable" );
		}
	}
	
	
	/** Exception thrown due to broken optimistic locks.  This one may
	 be worth trapping by the application so gets its own class. */
	public static class BrokenOptimisticLockException extends SException {
		SRecordInstance instance;
		public BrokenOptimisticLockException(SRecordInstance instance) {
			super("Broken Optimistic Lock " + instance, null);
			this.instance = instance;
		}
		/** The record that had the broken optimistic lock. */
		public SRecordInstance getRecordInstance(){return instance;}
	}
}
