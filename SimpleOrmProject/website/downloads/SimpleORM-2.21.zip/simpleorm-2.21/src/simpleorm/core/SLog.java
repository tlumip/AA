package simpleorm.core;

import java.io.PrintStream;

/** Very simple logging system. <p>

Logging calls are all made <code>SLog.log.</code>method so overriding
this class with a subclass of SLog provides full control of the logging if
really necessary.*/

public class SLog {
  public int level = 100;
  public static SLog slog=new SLog(); // ## should probably be in SConfiguration.

  public void error(String msg) { // Rarely used, normally throw instead.
    log("#### -ERROR " + SConnection.shortToString() + "_" + msg);
  }
  public void warn(String msg) {
    log("## -WARN " + SConnection.shortToString() + "_" + msg);
  }
  // Open, begin, commit etc.
  public void connections(String msg) {
    if (level >= 10) log("  -" + msg);
  }
  // During flushing
  public boolean enableUpdates(){return level >= 20;}
  public void updates(String msg) {
    if (enableUpdates()) log("    -" + msg);
  }
  // select() or findOrCreate()
  public boolean enableQueries(){return level >= 30;}
  public void queries(String msg) {
    if (enableQueries()) log("      -" + msg);
  }
  /**
   set/get per field.  enableFields enables the trace line to be
   surounded by an if test which is important as fields are an inner
   loop trace and the StringBuffer concatenation can be very
   expensive!
  */
  public boolean enableFields(){return level >= 40;}
  public void fields(String msg) {
    if (enableFields()) log("        -" + msg);
  }
  /** For detailed temporary traces during development only. */
  public boolean enableDebug(){return level >= 30;}
  public void debug(String msg) {
    if (enableDebug()) log("          -" + "(" + msg + ")");
  }
  /** For messages that are the ouput, eg. of unit test
      programs. Never disabled.*/
  public void message(String msg) {
    log(" ---" +  msg);
  }
  protected void log(String msg) {
    // Specialize this method.
    getStream().println(SConnection.shortToString() + msg);
      // err is better than out because that is where stack traces go, and it avoids buffer problems.
      // also, as out might be redirected, err is simply correct.
  }
  public PrintStream getStream() {return System.err;}

  public static String arrayToString(Object[] array) {
    if (array == null) return "NULL";
    StringBuffer res = new StringBuffer("[Array ");
    for (int ax=0; ax<array.length; ax++) {
      if (ax > 0) res.append("|");
      res.append(array[ax]);
    }
    res.append("]");
    return res.toString();
  }

}

