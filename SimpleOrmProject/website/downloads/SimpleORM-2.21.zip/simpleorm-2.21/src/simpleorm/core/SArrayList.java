package simpleorm.core;

/**
 * JAVA implementation of SArrayList.
 */

public class SArrayList extends java.util.ArrayList {
	public SArrayList() {
		super();
	}
	public SArrayList(int aSize) {
		super(aSize);
	}
	public SArrayList(java.util.ArrayList anArrayList) {
		super(anArrayList);
	}
}

/**
 * J# implementation of SArrayList.
 */
/*
 
 import System.Collections.ArrayList;
 
 public class SArrayList extends java.util.AbstractList {
 
 private ArrayList m_ArrayList = null;
 
 public SArrayList() {
 this(0);
 }
 public SArrayList(int aSize) {
 this.m_ArrayList = new ArrayList(aSize);
 }
 public SArrayList(System.Collections.ArrayList anArrayList) {
 this.m_ArrayList = anArrayList;
 }
 public Object get(int anIndex) {
 return this.m_ArrayList.get_Item(anIndex);
 }
 public void clear() {
 this.m_ArrayList.Clear();
 }
 public boolean add(Object anObject) {
 return this.m_ArrayList.Add(anObject) >= 0;
 }
 public Object set(int anIndex,Object aValue) {
 this.m_ArrayList.set_Item(anIndex, aValue);
 return aValue;
 }
 public int size() {
 return this.m_ArrayList.get_Count();
 }
 public java.util.Iterator iterator() {
 return new SIterator(((System.Collections.ArrayList)this.m_ArrayList.Clone()).GetEnumerator());
 }
 public Object clone() {
 return new SArrayList((ArrayList) this.m_ArrayList.Clone());
 }
 public class SIterator implements java.util.Iterator {
 private System.Collections.IEnumerator m_IEnumerator= null;
 public SIterator(System.Collections.IEnumerator anEnumerator) {
 this.m_IEnumerator = anEnumerator;
 }
 public boolean hasNext() {
 return this.m_IEnumerator.MoveNext();
 
 }
 public Object next() {
 return this.m_IEnumerator.get_Current();
 }
 public void remove() {
 System.Console.WriteLine("WArrayList.WIterator.remove not implemented yet.");
 }
 }
 }
 */
