package simpleorm.core;
import simpleorm.properties.*;
import java.sql.ResultSet;

/** Represents String field meta data. */

public class SFieldString extends SFieldScalar {
	
	/** <code>maxSize</code> is the maximum size in bytes (not
	 characters) of the column.  This fairly meaningless number is
	 required for all database DDL  except PostgreSQL, for which it is
	 ignored. */
	public SFieldString(SRecordMeta meta, 
			String columnName, int maxSize, SPropertyValue [] pvals) {
		super(meta, columnName, pvals);
		putProperty(SCon.SBYTE_SIZE, SJSharp.newInteger(maxSize)); // for Create Table only.
	}
	public SFieldString(SRecordMeta meta, String columnName, int maxSize) {
		this(meta, columnName, maxSize, new SPropertyValue[0]);
	}
	public SFieldString(SRecordMeta meta, String columnName, int maxSize, 
			SPropertyValue pval) {
		this(meta, columnName, maxSize, new SPropertyValue[]{pval});
	}
	public SFieldString(SRecordMeta meta, String columnName, int maxSize, 
			SPropertyValue pval1, SPropertyValue pval2) {
		this(meta, columnName, maxSize, new SPropertyValue[]{pval1, pval2});
	}
	
	/** Abstract specializer.  Clone this key field to be a foreign key
	 to <code>rmeta</code> of the same type.*/
	SFieldMeta makeForeignKey(
			SRecordMeta rmeta, String prefix, SPropertyValue [] pvals) {
		return new SFieldString(rmeta, 
				(prefix==null?"":prefix)+getString(SCon.SCOLUMN_NAME), 
				SJSharp.object2Int(getProperty(SCon.SBYTE_SIZE)),
				pvals);
	}
	
	Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception {
		return rs.getString(sqlIndex);
	}
	
	Object convertToField(Object raw) {
		return raw==null?null:raw.toString();
	}
	
	/** Specializes SFieldMeta. */
	String defaultDataType(){
		return getBoolean(SCon.SSTRING_CHAR)?"CHAR":"VARCHAR";}
	
	// OK public SFieldString tester() {return this;}
}
