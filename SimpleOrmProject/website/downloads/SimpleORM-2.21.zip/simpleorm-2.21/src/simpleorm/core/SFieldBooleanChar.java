package simpleorm.core;

import java.sql.ResultSet;

import simpleorm.properties.SPropertyValue;

/** Boolieans which are represented by a string.  
 * Subclasses determine whether "T", "Y", "Yes" etc. 
 * */

public abstract class SFieldBooleanChar extends SFieldBoolean {
	
	/** Represents Boolean field meta data as "T" and "F" chars. 
	 * @author Martin Snyder. */
	
	String TRUE_VALUE;
	String FALSE_VALUE;
	
	public SFieldBooleanChar(SRecordMeta meta, String columnName, SPropertyValue [] pvals)
	{
		super(meta, columnName, pvals);
		putProperty(SCon.SBYTE_SIZE, new Integer(1)); // for Create Table only.
	}
	/*
	 public SFieldBooleanChar(SRecordMeta meta, String columnName)
	 {
	 this(meta, columnName, new SPropertyValue[0]);
	 }
	 public SFieldBooleanChar(SRecordMeta meta, String columnName, SPropertyValue pval)
	 {
	 this(meta, columnName, new SPropertyValue[]{pval});
	 }
	 public SFieldBooleanChar(SRecordMeta meta, String columnName, SPropertyValue pval1, SPropertyValue pval2)
	 {
	 this(meta, columnName, new SPropertyValue[]{pval1, pval2});
	 }
	 */
	
	/**
	 * Converts from database representation to internal representation
	 */
	Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception
	{
		return convertDatabaseToBoolean(rs, sqlIndex);
	}
	
	//Object convertToField(Object raw) // In SFieldBoolean
	
	Object writeFieldValue(Object value) {
		if (((Boolean)value).booleanValue())
			return TRUE_VALUE;
		else
			return FALSE_VALUE;
	}
	
	/** Specializes SFieldMeta. */
	String defaultDataType()
	{
		return "CHAR";
	}
}
