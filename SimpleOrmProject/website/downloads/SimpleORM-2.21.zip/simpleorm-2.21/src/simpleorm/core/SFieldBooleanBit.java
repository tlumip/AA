/*
 * Created on Jan 18, 2005
 * Author dhristodorescu
 * Borderfree
 */
package simpleorm.core;

import java.sql.ResultSet;

import simpleorm.properties.SPropertyValue;

/**
 * @author dhristodorescu
 * Borderfree 
 */
public class SFieldBooleanBit extends SFieldBoolean
{           
    
    public SFieldBooleanBit(SRecordMeta meta, String columnName, SPropertyValue [] pvals)
    {
        super(meta, columnName, pvals);
    }
    
    public SFieldBooleanBit(SRecordMeta meta, String columnName)
    {
      this(meta, columnName, new SPropertyValue[0]);
    }
    public SFieldBooleanBit(SRecordMeta meta, String columnName, SPropertyValue pval)
    {
      this(meta, columnName, new SPropertyValue[]{pval});
    }
    public SFieldBooleanBit(SRecordMeta meta, String columnName, SPropertyValue pval1, SPropertyValue pval2)
    {
      this(meta, columnName, new SPropertyValue[]{pval1, pval2});
    }
        
    /** Abstract specializer.  Clone this key field to be a foreign key
     to <code>rmeta</code> of the same type.*/
    SFieldMeta makeForeignKey(SRecordMeta rmeta, String prefix, SPropertyValue [] pvals)
    {
        return new SFieldBooleanBit(
                rmeta, (prefix==null?"":prefix)+getString(SCon.SCOLUMN_NAME),   pvals);
    }
    
  	/**
  	 * Converts from database representation to internal representation
  	 */
  	Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception
  	{
  		return rs.getBoolean(sqlIndex) ? Boolean.TRUE : Boolean.FALSE;
  	}

    
    /** Specializes SFieldMeta. */
    String defaultDataType()
    {
        return "BIT"; // For MS SQL.
    }
}
