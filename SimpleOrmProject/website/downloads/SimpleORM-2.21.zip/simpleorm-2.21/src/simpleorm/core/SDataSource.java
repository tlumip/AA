package simpleorm.core;
import java.sql.Connection;
import java.util.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintStream;


/**
 * Provides a source of JDBC connections.  It has been introduced 
 * because some key generation 
 * algorithms require the creation of separate connections to create the
 * actual key value.  So just passing a single jdbc connection object into 
 * SConnection.attach is not sufficient.<p>
 *
 * If no connection pooling is used then just do:-
 * <pre> 
 * Class.forName(dbDriver);
 * SDataSource ds = new SDataSource(dburl, dbUserName, dbPassword);
 * // ds.setSDriverName("..."); to use a non-default driver
 * SConnection.attach(ds, "TestCon");
 * </pre>
 * 
 * attach calls openDBConnection which simply calls
 * <code>java.sql.DriverManager.getConnection(url, jdbcProperties)</code><p>
 * 
 * It is intended that this class can be subclassed, especially to enable
 * connection pooling.  It does not directly implement javax.sql.DataSource 
 * to avoid dependencies on Java 1.4 and EJBs.<p> 
 * 
 * @see SDataSourceJavaX is normally used for connection pooling.
 * 
 */
public class SDataSource {
	
	String url;
	Properties jdbcProperties;
			
	/**
	 * Constructor used to provide connections expicitly.
	 * Normally SConfiguration.Default is used instead.
	 * secondary is only required for certain key generation algorithms.
	 * driverName normally null, in which case a default will be inferred from the Connection.
	 * Note that this means that a new configuration is needed each time ###.
	 */
	public SDataSource(String url, Properties props) {
		this.url = url;
		jdbcProperties = props;
	}
	public SDataSource(String url) {
		this.url = url;
	}
	public SDataSource(String url, String username, String password) {
		this.url = url;
		setUsername(username);
		setPassword(password);
	}
	public SDataSource(){}
	
	public Properties getJdbcProperties() {return jdbcProperties;}
	public void setJdbcProperties(Properties jdbcProperties) {this.jdbcProperties = jdbcProperties;}
	public String getUrl() {return url;}
	public void setUrl(String url) {this.url = url;}
	/** Sets "user" property.  Creates new Properties if ncessary.*/
	public void setUsername(String username) {
		if (jdbcProperties == null) jdbcProperties = new Properties();
		jdbcProperties.put("user", username);
	}
	/** Sets "password" property. Creates new Properties if ncessary.*/
	public void setPassword(String password) {
		if (jdbcProperties == null) jdbcProperties = new Properties();
		jdbcProperties.put("password", password);
	}
	/**
	 * The main connection used by SimpleORM.
	 * (Some applications might just provide an explicit connection to SConnection.attach
	 * in which case this is never called.)
	 */
	protected Connection openPrimaryDBConnection() {
		return openDBConnection();
	}
	/**
	 * Secondary connection(s) are mainly used for generating primary keys
	 * using some table based algorithms.  
	 */
	protected Connection openSecondaryDBConnection() {
		return openDBConnection();
	}
	/**
	 * Called by obtainPrimary|SecondaryJDBCConnection
	 */
	protected Connection openDBConnection() {
		Connection con;
		try {
			con = java.sql.DriverManager.getConnection(url, jdbcProperties);
		} catch (Exception ex) {
			throw new SException.JDBC("Opening " + url, ex);
		}
		return con;

	}
	
	String sDriverName;
	/**
	 * An override for the name of the SDriver.  Normally this just
	 * returns null and SDriver.getSDriver picks the 
	 * SDriver based on the URL.
	 */
	public String getSDriverName(){return sDriverName;}
	public void setSDriverName(String driver){sDriverName = driver;}

}
