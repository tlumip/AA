package simpleorm.core;

/**
 * Generate keys using rows in a separate sequence table.
 * This should be done in a separate transaction to avoid locking problems.
 */

public abstract class SGenerator {
	protected SRecordMeta record;
	
	public SGenerator(SRecordMeta record) {this.record = record;}
	
	/**
	 * Create a new record with a generated key.
	 */
	public SRecordInstance createWithGeneratedKey(SRecordMeta meta, SFieldMeta keyField) {
		
		if (meta != record)
			throw new SException.Error("Inconsistent record metas " + record + " !=" + meta);
		/// Generate the key.
		long gened = generateKey(meta, keyField);
		
		/// Create the new record.
		SRecordInstance newRec = meta.create(SJSharp.newLong(gened));
		
		if (SLog.slog.enableQueries())
			SLog.slog.queries("createWithGeneratedKey: " + newRec);
		
		return newRec;
	}

	/**
	 * Update instance with a newly generated key.
	 * For example, when reattaching a record.
	 * ### needs to be unified with createWithGeneratedKey!
	 * The hard one is the Insert Identity.
	 */
	void updateWithGeneratedKey(SRecordInstance instance, SFieldMeta keyField) {
		
		SRecordMeta meta = instance.getMeta();
		if (meta != record)
			throw new SException.Error("Inconsistent record metas " + record + " !=" + meta);

		/// Generate the key.
		long gened = generateKey(meta, keyField);
		
		instance.setLong(keyField, gened);
		
		if (SLog.slog.enableQueries())
			SLog.slog.queries("updateWithGeneratedKey: " + instance);
	}
	
	protected abstract long generateKey(SRecordMeta meta, SFieldMeta keyField);
	
	/** returns DDL required to support number generation,
	 * Eg. "CREATE SEQUENCE FOO..."
	 * Returns a string rather than just doing it so that 
	 * the caller can create a DDL file if they want to.
	 */
	public String createDDL(){return null;}
	public String dropDDL(){return null;}
}
