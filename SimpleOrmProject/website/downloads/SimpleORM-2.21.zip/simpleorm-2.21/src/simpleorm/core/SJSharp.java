package simpleorm.core;

/**
 * This class contains a few required utilities to enable SimpleORM to run
 * under j# (.net)! 
 * The only other classes that need overriding are 
 * SArraylist, SThreadLocal, and SSerializable.
 * If you are not interested in J#/.Net this will not affect you.
 */

public class  SJSharp {
  /**
     Java Class is .net System.Type
  */
  static public Class castToClass(Object clas) {return (Class)clas;}
  static public String jvmVersion() {
    return Package.getPackage("java.lang").getImplementationVersion();
  }

  static public int object2Int(Object obj) {
    if (obj == null) return 0;
    if (obj instanceof Number)
      return ((Number)obj).intValue();
    else 
      return Integer.parseInt(obj.toString());
  }
  static public long object2Long(Object obj) {
    if (obj == null) return 0;
    if (obj instanceof Number)
      return ((Number)obj).longValue();
    else 
      return Long.parseLong(obj.toString());
  }
  static public double object2Double(Object obj) {
    if (obj == null) return 0;
    if (obj instanceof Number)
      return ((Number)obj).doubleValue();
    else 
      return Double.parseDouble(obj.toString());
  }
  static public boolean object2Boolean(Object obj) {
    if (obj == null) return false;
    if (obj instanceof Boolean)
      return ((Boolean)obj).booleanValue();
    else 
      return Boolean.valueOf(obj.toString()).booleanValue();
  }

  /**
   * These classes allow the java.lang.int etc. classes to be replaced
   * by native .Net classes.
   */
  
  static public Object newInteger(int i) {
    return new Integer(i);
  }
  
  static public Object newInteger(String s) {
    return new Integer(Integer.parseInt(s));
  }
  static public Object newInteger(Number n) {
    return newInteger(n.intValue());
  }
  static public Object newLong(long i) {
    return new Long(i);
  }
  static public Object newLong(Number n) {
    return newLong(n.intValue());
  }
  static public Object newLong(String s) {
    return newLong(Long.parseLong(s));
  }
  static public Object newDouble(double i) {
    return new Double(i);
  }
  static public Object newDouble(Number n) {
    return newDouble(n.intValue());
  }
  static public Object newDouble(String s) {
    return newDouble(Double.parseDouble(s));
  }

  static public boolean isInteger(Object obj) {
    return obj instanceof Integer;
  }
  static public boolean isLong(Object obj) {
    return obj instanceof Long;
  }
  static public boolean isDouble(Object obj) {
    return obj instanceof Double;
  }
  
}


/*
public class  SJSharp {
  static public Class castToClass(object clas) {
    if (clas instanceof Class)
      return (Class)clas;
    else
      return Class.FromType((System.Type)clas);
  }
  static public String jvmVersion() {
    return System.Environment.get_Version().ToString();
  }

  static public int object2Int(object obj) {
    if (obj == null) return 0;
    return Integer.parseInt(obj.toString());
  }
  static public long object2Long(object obj) {
    if (obj == null) return 0;
    return Long.parseLong(obj.toString());
  }
  static public double object2Double(object obj) {
    if (obj == null) return 0;
    return Double.parseDouble(obj.toString());
  }
}
*/
