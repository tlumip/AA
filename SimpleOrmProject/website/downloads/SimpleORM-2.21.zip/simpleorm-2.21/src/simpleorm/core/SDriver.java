package simpleorm.core;

import simpleorm.properties.*;
import java.sql.*;

/*
 * Copyright (c) 2002 Southern Cross Software Queensland (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/** This is the generic database driver that contains minimal
 database dependent code.  Specific SimpleORM drivers extend this
 class and specialize its methods as required.  The driver type is
 infered from the jdbc connection's meta data.<p>
 
 ## Profiling suggests that memoising these generaters could produce a
 5-10% improvement in bulk updates.<p>
 
 There is now one driver instance per connection so one can say
 SConnection.getDriver().setMyFavouriteParam(...)<p>
 
 SQL 92 standard data types, I think:-
 boolean, Character(n), character varying(n), date, float(p), real, double precission, smallint, int | integer, 
 decimal(p,s), numeric(p,s), time, interval, timestamp with timezone, 
 */
public class SDriver implements SConstants {
	
	
	/** Note that these are only prototypes.  
	 * New SDriver instances are created for each connection.
     * See static below.*/
	static SArrayList drivers = new SArrayList();
	
	static {
		SDriver [] ds = new SDriver[] {
				new SDriverHSQL(), new SDriverPostgres(), new SDriverMySQL(), new SDriverOracle(),
                new SDriverDaffodil(),
                new SDriverMSSQL(), new SDriverDB2_400(), new SDriverInformix(), new SDriverInterbase(),
				new SDriverFirebird(), new SDriverSapDB(), new SDriverSybase(), new SDriverDerby()};
		for (int dx=0; dx<ds.length; dx++)
			((SDriver)ds[dx]).registerDriver();
	}
	
	/**
	 Add driver to the list of possible drivers that can be found by
	 SConnection.attach.  The key is returned by driverName.
	 */
	public void registerDriver() {
		drivers.add(this);
	}
	
	/** The driver name to be compared to getMetaData().getDriverName() */
	protected String driverName() {return "Generic Driver";}
	
	/** The maximum size for table names and foreign key constraint names. */
	public int maxIdentNameLength(){return 30;}
	
	/** Wraps identifiers in "s to avoid reserved word issues. 
	 * (Override this for dbs that use different chars, eg [xxx] for MS-SQL.
	 * We do quote these days to avoid the endless problems with reserved words.
	 */
	public String quoteIdentifier(String ident) {
		if (ident.length() > maxIdentNameLength())
			throw new SException.Error(
					"Identifier '" + ident + "' is longer than " + maxIdentNameLength() +
					" chars as permitted by " + driverName());
		return "\"" + ident + "\"";
	}
	public String quoteColumn(String ident) { return quoteIdentifier(ident); }
	public String quoteTable(String ident) { return quoteIdentifier(ident); }
	public String quoteConstraint(String ident) { return quoteIdentifier(ident); }
	
	/** True if exclusive locks are properly supported.  Otherwise
	 optimistic locks are always used. <p>
	 */
	public boolean supportsLocking(){return true;}
	
	/** Chooses default driver based on the connection's meta data.<p>
	 
	 Note that if you have trouble with the driver defaulting mechanism, then
	 specify the driver explicitly as the third parameter to SConnection.attach.<p>
	 
	 Note also that a new driver instance is created each time.
	 */
	static SDriver newSDriver(java.sql.Connection con, String driverName) {
		String databaseName = null;
		try {
			driverName   = driverName != null ? driverName : con.getMetaData().getDriverName();
			databaseName = con.getMetaData().getDatabaseProductName();
		} catch (Exception ex) { throw new SException.JDBC(ex);}
		for (int dx=0; dx<drivers.size(); dx++) {
			SDriver driver = (SDriver)drivers.get(dx);
			if (driver.driverName().equals(driverName))
				try {
					return (SDriver)driver.getClass().newInstance();
				} catch (Exception ex) {throw new SException.Error(ex);}
		}
		
		SLog.slog.warn(
				"Unknown Database '" + databaseName + "' driver '" + driverName + "'. Using generic SDriver.");
		return new SDriver();
	}
	
	/** These alow you to create a new SFieldMeta object at runtime
	 and then update the table to include it.  Eg. for end user
	 customizations.
	 
	 ## Ideally this could be further automated so that the SRecordMeta
	 and JDBC meta data for a table could be compared and the table
	 automatically altered.
	 */
	public String alterTableAddColumnSQL( SFieldMeta field )
	{
		StringBuffer sql = new StringBuffer();
		
		sql.append( "\nALTER TABLE " );
		sql.append( quoteTable(field.sRecordMeta.getString(STABLE_NAME)));
		sql.append( " ADD COLUMN " );
		sql.append(quoteColumn(wholeColumnSQL( field )) );
		sql.append(clauseSeparator("    "));
		
		return sql.toString();
	}
	
	public String alterTableDropColumnSQL( SFieldMeta field )
	{
		StringBuffer sql = new StringBuffer();
		
		sql.append( "\nALTER TABLE " );
		sql.append(quoteTable(field.sRecordMeta.getString(STABLE_NAME)) );
		sql.append( " DROP COLUMN " );
		sql.append(quoteColumn(field.getString(SCOLUMN_NAME)));
		sql.append(clauseSeparator("    "));
		
		return sql.toString();
	}
	
	/** Returns a <code>CREATE TABLE</code> for this table.  Delegated
	 from SRecord. This is split up into many sub-methods so that
	 they can be selectively specialized by other drivers.*/
	public String createTableSQL(SRecordMeta meta) {
		StringBuffer sql = new StringBuffer(1000);
		String tname = meta.getString(STABLE_NAME);
		sql.append("\nCREATE TABLE " +  quoteTable(tname) + "(");
		for (int fx=0; fx<meta.sFieldMetas.size(); fx++) {
			//SLog.temp("SFld " + meta.fields.get(fx));
			SFieldMeta fld = (SFieldMeta)meta.sFieldMetas.get(fx);
			Object cq = fld.getProperty(SCOLUMN_QUERY);
			if (!(fld instanceof SFieldReference) && cq == null) {
				sql.append(clauseSeparator("    "));
				sql.append(wholeColumnSQL(fld));
				sql.append(", "); // Assume always a Primary Key clause
			}
		}
		sql.append(clauseSeparator("    "));
		sql.append(primaryKeySQL(meta));
		sql.append(indexKeySQL(meta));
		sql.append(foreignKeysSQL(meta));
		sql.append(postTablePreParenSQL(meta));
		String xTable = (String)meta.getProperty(SEXTRA_TABLE_DDL);
		if (xTable != null) sql.append(xTable);
		sql.append(")");
		sql.append(postTablePostParenSQL(meta));
		sql.append(clauseSeparator("    "));
		return sql.toString();
	}
	
	/** Normally newline and indent to separate clauses of large SQL
	 statement */
	protected String clauseSeparator(String indent) {
		return "\n" + indent;
	}
	
	/** Returns <code>MY_COL VARCHAR(13) NOT NULL</code>.
	 @see #SMANDATORY
	 */
	protected String wholeColumnSQL(SFieldMeta fld) {
		StringBuffer sql = new StringBuffer(60);
		String columnName = fld.getString(SCOLUMN_NAME);
		int len=columnName.length();
		sql.append(quoteColumn(columnName)
				+ "            ".substring(len>10?10:len-1) +
				columnTypeSQL(fld));
		addNull(sql, fld);
		sql.append(postColumnSQL(fld));
		String xCols = (String)fld.getProperty(SEXTRA_COLUMN_DDL);
		if (xCols != null) sql.append(xCols);
		return sql.toString();
	}
	
	protected void addNull(StringBuffer sql, SFieldMeta fld) {
		if (fld.isPrimaryKey || fld.getBoolean(SMANDATORY))
			sql.append(" NOT NULL");
		else
			sql.append(" NULL"); // ### NULL is redundant and troublesome, remove.
		// ### Sybase anywhere and ALLOW_NULLS_BY_DEFAULT option.  This
		// is a hack, need to distinguish NULL from empty.  See SMANDATORY.
	}
	
	protected String columnTypeSQL(SFieldMeta field) {
		String res = (String)field.getProperty(SDATA_TYPE);
		if ( res.equals("VARCHAR") || res.equals("CHAR") )
			res = res + "(" + field.getProperty(SBYTE_SIZE) + ")";
		return res;
	}
	
	/** After NOT NULL but before the ",", ie column specific annotations. */
	protected String postColumnSQL(SFieldMeta field) {
		return "";
	}
	
	/** Return <code>PRIMARY KEY(KCOL, KCOL)</code> appended to end. */
	protected String primaryKeySQL(SRecordMeta meta) {
		StringBuffer pkey = new StringBuffer("PRIMARY KEY (");
		boolean firstpk = true;
		for (int fx=0; fx<meta.sFieldMetas.size(); fx++) {
			SFieldMeta fld = (SFieldMeta)meta.sFieldMetas.get(fx);
			if (!(fld instanceof SFieldReference)) {
				if (fld.isPrimaryKey) {
					if (!firstpk) pkey.append(", ");
					firstpk = false;
					pkey.append(quoteColumn(fld.getString(SCOLUMN_NAME)));
				}
			}
		}
		pkey.append(")");
		return pkey.toString();
	}
	
	/** Needed for MySQL to create indexes on foreign keys */
	protected String indexKeySQL(SRecordMeta meta) {
		return "";
	}
	
	/** Returns <code>FOREIGN KEY (FKCOL, FKCOL) REFERENCES FTABLE (KCOL,
	 KCOL)</code> appended to end. */
	protected String foreignKeysSQL(SRecordMeta meta) {
		return mapForeignKeys(meta, true);
	}
	protected String mapForeignKeys(SRecordMeta meta, boolean foreignKey) {
		StringBuffer fkey = new StringBuffer("");
		for (int fx=0; fx<meta.sFieldMetas.size(); fx++) {
			SFieldMeta fld = (SFieldMeta)meta.sFieldMetas.get(fx);
			//SLog.slog.debug("fld " + fld);
			if (fld instanceof SFieldReference) {
				
				SFieldReference fldRef = (SFieldReference)fld;
				//SLog.slog.debug("  fldRef " + fldRef);
				
				if (!fldRef.getBoolean(SNO_FOREIGN_KEY)
						&& (fld.sFieldReference == null
								|| fld.getBoolean(SINNER_FOREIGN_KEY) )) {
					
					// Obtain foreign and referenced fields.
					StringBuffer sbFkey = new StringBuffer(40);
					StringBuffer sbRefed = new StringBuffer(40);
					
					// Recur through identifying foreign keys
					aReferenceSQL(fldRef, fldRef, sbFkey, sbRefed);

					if (foreignKey)
						makeForeignKeySQL(meta, fx, fldRef, sbFkey, sbRefed, fkey);
					else 
						makeForeignKeyIndexSQL(meta, fx, fldRef, sbFkey, sbRefed, fkey);
				}
			}
		}
		return fkey.toString();
	}

	private void makeForeignKeySQL(SRecordMeta meta, int fx, SFieldReference fldRef, StringBuffer sbFkey, StringBuffer sbRefed, StringBuffer fkey) {
		/// The FOREIGN KEY clause and constraint name
		fkey.append(",\n    CONSTRAINT ");
		String tname = meta.getString(STABLE_NAME);
		String fxStr = fx + "";
		if (tname.length() > maxIdentNameLength()-fxStr.length())
			throw new SException.Error(
					"Table name '" + tname + "' is longer than " + maxIdentNameLength() +
					" - " + (fxStr.length()+1) + " chars as permitted by " + driverName() +
			" to allow for _nn constraint name.");
		
		String fkeyName = tname + "_" + fxStr; // Ensure unique
		String fname = fldRef.getString(SFIELD_NAME);
		int spare = maxIdentNameLength() - tname.length() - (fxStr.length()+1);
		if (spare > 1) fkeyName += "_"; // >1 so no trailing _
		if (spare > fname.length())
			fkeyName += fname;
		else if (spare > 0)
			fkeyName += fname.substring(0, spare-1);
		fkey.append(quoteConstraint(fkeyName));
		
		fkey.append( "\n      FOREIGN KEY (");
		
		
		fkey.append(sbFkey.toString()); // toString required for 1.3.1
		fkey.append(")\n      REFERENCES ");
		
		fkey.append( quoteTable( fldRef.referencedRecord.getString(STABLE_NAME)));
		fkey.append(" (");
		fkey.append(sbRefed.toString());
		fkey.append(")");
		
		String xddl = fldRef.getString(SEXTRA_FKEY_DDL);
		if (xddl != null)
			fkey.append(xddl);
	}
	/*
	 * For MySQL.  Index needs to be created as part of Create Index statement.
	 */
	protected void makeForeignKeyIndexSQL(SRecordMeta meta, int fx, SFieldReference fldRef, StringBuffer sbFkey, StringBuffer sbRefed, StringBuffer fkey) {
	}

	protected void aReferenceSQL(
			SFieldReference topRef, SFieldReference fldRef,
			StringBuffer sbFkey, StringBuffer sbRefed) {
		for (int ff=0; ff<fldRef.foreignKeyFields.length; ff++) {
			SFieldMeta ref = fldRef.foreignKeyFields[ff];
			//SLog.slog.debug("    top ref " + topRef + " fldRef " + fldRef + " ref " +  ref);
			if (!(ref instanceof SFieldReference)) {
				if (sbFkey.length() > 0) {
					sbFkey.append(", ");
					sbRefed.append(", ");
				}
				sbFkey.append(quoteColumn(ref.getString(SCOLUMN_NAME)));
				
				SFieldMeta refed = findRecordRefedField(topRef.referencedRecord,  ref);
				//SLog.slog.debug("Refed(" + fldRef + fldRef.referencedRecord + ref + "): " + refed);
				sbRefed.append( quoteColumn( refed.getString(SCOLUMN_NAME)));
			} else {
				aReferenceSQL(topRef, (SFieldReference)ref, sbFkey, sbRefed);
			}
		}
		
	}

	private SFieldMeta findRecordRefedField(
			SRecordMeta rec, SFieldMeta ref) {
		for (;;) {
			SFieldMeta ref2 = ref.referencedKeyField;
			// ## May be a funny case with deep recursive keys.
			if (ref2 == null)
				throw new SException.InternalError(
						"Record " + ref + " has null referencedKeyField.");
			ref = ref2;
			if (ref.sRecordMeta == rec)
				return ref;
		}
	}
	
	/** Any other text to be added before the final ")"*/
	protected String postTablePreParenSQL(SRecordMeta meta) {
		return "";
	}
	
	/** Any other text to be added after the final ")".  No ";". */
	protected String postTablePostParenSQL(SRecordMeta meta) {
		return "";
	}
	
	/** Returns the SQL statement for a SELECT in a structured way.
	 Used by findOrInsert.  <code>select</code> and
	 <code>where</code> are arrays of <code>SFieldMeta</code>s.  Returns
	 SQL statement as a string.<p>
	 
	 This now quotes table and column names so that they become
	 case independent.<p>
	 
	 sps is links to the SPreparedStatement object.  It can have arbitrary properties set to
	 provide fine control over the query.  Examples include limits.
	 */
	protected String selectSQL(
			SFieldMeta[] select, SRecordMeta from, SFieldMeta[] where,
			String orderBy, boolean forUpdate, boolean unrepeatableRead, SPreparedStatement sps) {
		
		StringBuffer ret = new StringBuffer(100);
		for (int wx=0; wx<where.length; wx++) {
			if (wx > 0) ret.append(" AND ");
			SFieldMeta wfld = (SFieldMeta)where[wx];
			ret.append(quoteColumn(wfld.getString(SCOLUMN_NAME)) + " = ? ");
		}
		return selectSQL(select, from, ret.toString(), orderBy, 
				forUpdate, unrepeatableRead, sps);
	}
	
	protected String selectSQL(
			SFieldMeta[] select, SRecordMeta from, String where,
			String orderBy, boolean forUpdate, boolean unrepeatableRead, SPreparedStatement sps) {
		
		SRecordMeta[] joinTables = sps==null?null:sps.getJoinTables();
		boolean distinct = sps==null?false:sps.getDistinct();
		
		StringBuffer ret = new StringBuffer( 200 );
		ret.append("SELECT ");
		
		// If joining, query may return multiple rows for same record. These need to
		// be weeded out.
		// ### AJB I do not see how this can happen.  I think this is noise and should
		// be removed.
		if ( distinct )
		{
			ret.append( "DISTINCT " );
		}
		
		String tableName = from.getString(STABLE_NAME);
		boolean doJoin = joinTables != null && joinTables.length > 0;
		
		for (int sx=0; sx<select.length; sx++) {
			//System.out.println("selectSQL " + from + select[sx]);
			if (sx > 0) ret.append(", ");
			SFieldMeta sfld = (SFieldMeta)select[sx];
			String colName = sfld.getString(SCOLUMN_QUERY);
			if (colName == null)
			{
				colName = sfld.getString(SCOLUMN_NAME);
				if (colName == null)
					throw new SException.InternalError("Null Column Name " + sfld);
				colName = quoteColumn(colName);
			}
			if ( doJoin ) {
				ret.append( quoteTable(tableName) );
				ret.append( '.' );
			}
			
			ret.append(colName);
		}
		
		ret.append(fromSQL(from, joinTables));
		ret.append(postFromSQL(forUpdate, unrepeatableRead));
		
		if (where != null)   ret.append(" WHERE " + where);
		if (orderBy != null) ret.append(" ORDER BY " + orderBy);
		ret.append(forUpdateSQL(forUpdate));
		return ret.toString();
	}
	
	/** Returns update clause, may not be valid in certain lock modes etc. 
	 Right at the end of the query. <p>
	 
	 Oracle, Postgresql, and new in MS SQL 2005 support data versioning
	 or snapshots.  This means that repeatable read is achieved by
	 caching the previous value read instead of using read locks.  This
	 approach makes it critical to add FOR UPDATE where appropriate or
	 there is effectively no locking. <p>
	 
	 Indeed, in Oracle, you are guaranteed that several SELECTS will
	 return the same value, but a subsequent SELECT FOR UPDATE in the
	 same transaction may return a different value.<p>
	 
	 */
	protected String forUpdateSQL(boolean forUpdate) {
		if (supportsLocking() && forUpdate)
			return" FOR UPDATE";
		else
			return "";
	}
	
	/** Returns the FROM Table, Table... clause */
	protected String fromSQL(SRecordMeta from, SRecordMeta[] joinTables) {
		String tableName = from.getString(STABLE_NAME);
		String res =" FROM " + quoteTable(tableName) + " ";
		// Do not add + tableName.charAt(0) + " ";
		// Breaks Oracle(!) -- which then insists that ONLY the alias be used.
		
		if ( joinTables != null ) {
			for ( int ii = 0; ii < joinTables.length; ii++ )
				res = res + ", " +  quoteTable(joinTables[ii].getString(STABLE_NAME));
		}
		return res;
	}
	/** For MSSQL. Just after all the tables in the From clause.*/
	protected String postFromSQL(boolean forUpdate, boolean unrepeatableRead){
		return "";
	}
	
	/** Returns the SQL statement for an UPDATE in a structured way.
	 Used by flush().  <code>updates</code> and
	 <code>where</code> are SArrayLists of SFieldMetas.  Returns SQL
	 statement as a string. */
	protected String updateSQL(
			SArrayList updates, SRecordMeta from,
			SArrayList where, SRecordInstance instance, Object[] keyMetaValues) {
		StringBuffer ret = new StringBuffer(200);
		ret.append("UPDATE ");
		ret.append(quoteTable(from.getString(STABLE_NAME)) + " SET ");
		for (int sx=0; sx<updates.size(); sx++) {
			if (sx > 0) ret.append(", ");
			SFieldMeta sfld = (SFieldMeta)updates.get(sx);
			ret.append(quoteTable(sfld.getString(SCOLUMN_NAME)) + " = ?");
		}
		whereSQL(ret, where, instance, keyMetaValues);
		return ret.toString();
	}
	
	/** Returns the SQL statement for an INSERT in a structured way.
	 Used by flush().  <code>updates</code> and
	 <code>where</code> are SArrayLists of SFieldMetas.  Returns SQL
	 statement as a string. */
	protected String insertSQL(SArrayList updates, SRecordMeta from) {
		StringBuffer ret = new StringBuffer(200);
		ret.append("INSERT INTO ");
		ret.append(quoteTable(from.getString(STABLE_NAME)) + " (");
		for (int sx=0; sx<updates.size(); sx++) {
			if (sx > 0) ret.append(", ");
			SFieldMeta sfld = (SFieldMeta)updates.get(sx);
			ret.append(quoteColumn(sfld.getString(SCOLUMN_NAME)));
		}
		ret.append(") VALUES (");
		for (int sx=0; sx<updates.size(); sx++) {
			if (sx > 0) ret.append(", ");
			ret.append("?");
		}
		ret.append(")");
		return ret.toString();
	}
	
	/** Returns the SQL statement for an DELETE in a structured way.
	 Used by flush(). <code>where</code> are SArrayLists of
	 SFieldMetas.  Returns SQL statement as a string. */
	protected String deleteSQL(
			SRecordMeta from, SArrayList where, SRecordInstance instance, Object[] keyMetaValues) {
		StringBuffer ret = new StringBuffer(200);
		ret.append("DELETE FROM ");
		ret.append(quoteTable(from.getString(STABLE_NAME)));
		whereSQL(ret, where, instance, keyMetaValues);
		return ret.toString();
	}
	
	/** Produces the WHERE clause of UPDATE and DELETE statements.
	 Needs to know the instance values so that it can use the IS NULL
	 test (for optimisitic locking).*/
	protected void whereSQL(
			StringBuffer ret, SArrayList where, SRecordInstance instance, Object[] keyMetaValues) {
		ret.append(" WHERE ");
		for (int wx=0; wx<where.size(); wx++) {
			if (wx > 0) ret.append(" AND ");
			SFieldMeta wfld = (SFieldMeta)where.get(wx);
			Object value = keyMetaValues[wx];
			// not instance.fieldValues[wfld.fieldIndex]; for optimistic locking
			if (value != null)
				ret.append(quoteColumn(wfld.getString(SCOLUMN_NAME)) + " = ? ");
			else
				ret.append(quoteColumn(wfld.getString(SCOLUMN_NAME)) + " IS NULL ");
		}
	}
	
	/** Called just after executeQuery to Skip over records until offset
	 * has been reached.  Drivers may optimize this in various ways,
	 * eg. LIMIT keywords where supported by the database, or by using
	 * the JDBC  */
	protected void initResultSet(SResultSet srs) {
		ResultSet rs = srs.getDBResultSet();
		SPreparedStatement sps = srs.getSPreparedStatement();
		try {
			//if (sps.getLimit() > 0) 
			//rs.setMaxRows((int)sps.getLimit()); only on statement.
			
			if (canResultSetAbsolute() && sps.getOffset() != 0) {
				rs.setFetchDirection(ResultSet.FETCH_UNKNOWN);
				rs.absolute((int)sps.getOffset()); // 1 is first row, 0 is before first row.
			} else {
				while (srs.getNrRetrieved() < sps.getOffset() && srs.hasNext())
					srs.getRecord();
				srs.nrRetrieved = 0;
			}
		} catch (SQLException ex) {
			throw new SException.JDBC(ex);
		}
	}
	/** true if resultset.absolure(nn) works properly to implement limit/offset. */
	protected boolean canResultSetAbsolute(){return false;}
	
	/** Generates a new key using SELECT MAX+1.  This will (hopefully)
	 be specialized for each database driver to be correct. Note that
	 there is a global counter kept so it will actually work OK if
	 all the updates are from one JVM.  Amazing that there is still
	 no standard way to do this in SQL.<p>
	 
	 ## (There is scope to optimize this at some point so that one JDBC
	 call can both generate the sequence number and insert a new
	 record.  But that means that the new record's key is not
	 available until insert time which causes problems for foreign
	 keys.  Alternatively one can get batches of 10 (say) sequences
	 at a time and then use an internal counter, but this will leave
	 big holes in the sequence.  Defer this to version 1.)
	 */
	protected long generateKeySelectMax(SRecordMeta rec, SFieldMeta keyFld) {
		String columnName = keyFld.getString(SCOLUMN_NAME);
		String tableName = rec.getString(STABLE_NAME);
		String qry = "SELECT MAX(" + quoteColumn(columnName) + ") FROM " + quoteColumn(tableName);
		
		Object next = SConnection.rawQueryJDBC(qry);
		
		long db = next == null ? 1 : SJSharp.object2Long(next) + 1;
		return keyFld.nextGeneratedValue(db);
	}
	
	protected long generateKeySequence(SRecordMeta rec, SFieldMeta keyFld) {
		throw new SException.Error("Database does not support SEQUENCES");
	}
	public boolean supportsKeySequences(){return false;}
	protected String createSequenceDDL(String name) {
		throw new SException.Error("Sequences not supported");
	}
	protected String dropSequenceDDL(String name) {
		throw new SException.Error("Sequences not supported");
	}
	
	/** Utility routine for dropping tables called by SConnection.
	 Driver specific versions should only hide table non existant
	 errors (and not warn about them).*/
	public void dropTableNoError(String table) {
		Connection con = SConnection.getBegunDBConnection();
		try {
			PreparedStatement ps = con.prepareStatement("DROP TABLE " + table);
			ps.executeUpdate();
		} catch (SQLException ex) {
			SLog.slog.warn("DROPPING " + table + ": " + ex);
		}
	}
	
	
}

