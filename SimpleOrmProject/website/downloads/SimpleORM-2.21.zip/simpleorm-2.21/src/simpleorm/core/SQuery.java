package simpleorm.core;

import simpleorm.properties.*;
import java.util.StringTokenizer;

/*
 * Copyright (c) 2002 Southern Cross Software Queensland (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/** Provides the non-SQL query interface.  This is still a thin layer
 on SQL, but provides more run time type checking at the price of
 slightly longer queries.  There is also a very small performance overhead.<p>
 
 For example:-
 
 <xmp>
 SResultSet res = Employee.meta.newQuery()
 .gt(Employee.NAME, "'J'")
 //.and() // AND is implied.
  .eq(Employee.DEPARTMENT, myDept)
  .decending(Employee.NAME) // ie. Order By
  .execute();
  while (res.hasNext()) {...
  </xmp>
  
  is equivalent to
  
  <xmp>
  SPreparedStatement stmt = Employee.meta.select(
  "NAME > 'j' AND DEPT_ID = ?", "NAME DESC");
  stmt.setInt(1, myDept.getInt(DEPT_ID));
  SResultSet res = stmt.execute();
  while (res.hasNext()) {...
  </xmp>
  
  This API is a little unusual in that there is only one SQuery instance
  created, and each of the methods update its state and then return
  <code>this</code>.<p>
  
  The raw* methods can be used to poke any string into the SQL Where or
  Order By clauses in the order they appear.  But more commonly the raw
  methods are called by higher level methods such as <code>eq</code> and
  <code>and</code>.<p>

 todo Some of this logic should be moved to sdriver, and integrated with its selectSQL etc.<p>
  
  */

public class SQuery implements SConstants {
	SRecordMeta record = null;
	
	SArrayList joinTables = new SArrayList(2);
	StringBuffer where = new StringBuffer(100);
	SArrayList  queryParameters = new SArrayList(2);
	StringBuffer orderBy = new StringBuffer(40);
	boolean needsConjunction = false;
	boolean reverseJoin = false;
	boolean orderByJoinedColumn = false;
	
	long sqy_bitSet;
	SFieldMeta [] selectList = null;

    SDriver driver = SConnection.getDriver();

    /** SQueries are created by SRecordMeta.newQuery(). */
	protected SQuery(SRecordMeta record, long sqy_bitSet, SFieldMeta[] selectList) {
		this.record = record;
		this.sqy_bitSet = sqy_bitSet;
		this.selectList = selectList;
	}
	
	public SRecordMeta getSRecordMeta() {
		return record;
	}
	
	/**
	 * Return true if this query will use 'SELECT DISTINCT'. This is automatically
	 * added if the following two conditions are true:
	 * <ol>
	 * <li>This query uses a join on a reference FROM another table. For example,
	 * a query on department that has a join to employee (note that without the
	 * 'DISTINCT' keyword, multiple rows would typically be returned for each department)
	 * <li>There are no order-by columns on fields other than the query table. SQL
	 * syntax forces all order-by columns to also be in the select list, if DISTINCT
	 * is used.
	 * </ol>
	 */
	public boolean isDistinct()
	{
		return reverseJoin && !orderByJoinedColumn;
	}
	
	/** Execute the query, set the previously specified query values,
	 and return the result set.*/
	public SResultSet execute(){
		return execute(new SPreparedStatement());
	}
	public SResultSet execute(SPreparedStatement stmt){     
		stmt.setJoinTables((SRecordMeta[])joinTables.toArray( new SRecordMeta[0]));
		stmt.setDistinct(isDistinct());
		record.select(
				where.length()==0?null:where.toString(),
						orderBy.length()==0?null:orderBy.toString(),
								sqy_bitSet, selectList, stmt);
		
		for (int px=0; px<queryParameters.size(); px++) {
			stmt.setObject(px+1, queryParameters.get(px)); // ## may cause problems some JDBC
		}
		return stmt.execute();
	}
	
	
	/** Add term to the where clase, eg. "BUDGET > ?".  Not normally called directly. */
	public SQuery rawClause(String term) {
		if ( term.trim().equals( "(" ) )
		{
			if ( needsConjunction )
				and();
		}
		
		where.append(term);
		where.append(" ");
		return this;
	}
	
	/** Add a clause to the OrderBy statement, eg. "NAME DESC".  Commas
	 are added automatically.*/
	public SQuery rawOrderBy(String orderBy) {
		if (this.orderBy.length() > 0) this.orderBy.append(", ");
		this.orderBy.append(orderBy);
		return this;
	}
	
	/** Add a clause to the OrderBy statement. Commas
	 are added automatically.*/
	public SQuery rawOrderBy(SFieldMeta field, boolean ascending)
	{
		verifyFieldOkToUse( field );
		
		if ( field instanceof SFieldReference ) {
			SFieldMeta[] fields = ((SFieldReference)field).foreignKeyFields;
			for ( int ii = 0; ii < fields.length; ii++ ) {
				rawOrderBy( fields[ii], ascending );
			}
		}
		else
		{
			StringBuffer orderByElement = new StringBuffer();
			
			orderByElement.append(field.sRecordMeta.getProperty(STABLE_NAME));
			orderByElement.append(".");
            String col = driver.quoteColumn(field.getString(SCOLUMN_NAME));
            orderByElement.append(col);
			
			if (!ascending) {
				orderByElement.append(" DESC");
			}
			
			rawOrderBy(orderByElement.toString());
			
			if ( field.sRecordMeta != record ) {
				orderByJoinedColumn = true;
			}
		}
		
		return this;
	}
	
	/**
	 * Throws exception if field is not from this table, or any of the joined tables
	 */
	private void verifyFieldOkToUse( SFieldMeta field )
	{
		if (field.sRecordMeta != record &&
				!joinTables.contains( field.sRecordMeta ) )
		{
			throw new SException.Error( "Field " + field + " is not from record " + field.sRecordMeta);
		}
	}
	
	/** Add a parameter value to the internal array.  These will be
	 <code>setObject</code> later after the prepared statement is
	 created but before it is executed.*/
	public SQuery rawParameter(Object parameter) {
		queryParameters.add(parameter);
		return this;
	}
	
	
	/** Adds the field's columnName. */
	public SQuery rawField(SFieldMeta field)
	{
		verifyFieldOkToUse( field );
		
		where.append( field.sRecordMeta.getProperty( STABLE_NAME ) );
		where.append( "." );
        String quoted = driver.quoteColumn(field.getString(SCOLUMN_NAME));
        where.append( quoted );
		where.append( " " );
		
		return this;
	}
	
	/** Generates <code>field relop ?</code> and then subsequently sets the
	 parameter value.  Eg. <p>
	 
	 <code>fieldRelopParameter(Employee.Name, "=", myName)</code><p>
	 */
	public SQuery fieldRelopParameter(SFieldMeta field, String relop, Object value) {
		
		// If object passed in is really an SFieldMeta, use the method that is appropriate
		if ( value instanceof SFieldMeta )
			return this.fieldRelopParameter( field, relop, (SFieldMeta)value );
		
		if (field instanceof SFieldReference)
			throw new SException.Error("Attempt to query reference field " + field);
		
		if ( needsConjunction )
			and();
		
		rawField(field);
		rawClause(relop);
		rawClause("?");
		rawParameter(value);
		
		needsConjunction = true;
		
		return this;
	}
	
	/** Generates <code>field1 relop field2</code>
	 
	 E.g.
	 <code>fieldRelopParameter(Order.QuantityRequired, "=", Order.QuantityReceived)</code><p>
	 Mainly useful for Joins.
	 */
	public SQuery fieldRelopParameter(SFieldMeta field1, String relop, SFieldMeta field2) {
		
		if (field1 instanceof SFieldReference)
			throw new SException.Error("Attempt to query reference field " + field1);
		if (field2 instanceof SFieldReference)
			throw new SException.Error("Attempt to query reference field " + field2);
		
		if ( needsConjunction )
			and();
		
		rawField(field1);
		rawClause(relop);
		rawField(field2);
		
		needsConjunction = true;
		
		return this;
	}
	
	/** Generates <code>field clause</code>, ie the clause string is poked
	 literally into the query.  Eg. <p>
	 <code>fieldQuery(Employee.Name, "= 'Fred'")</code><p>
	 
	 Use fieldRelopParameter instead for
	 parameters determined at run time as blindly concatenating
	 strings is dangerous.
	 */
	public SQuery fieldQuery(SFieldMeta field, String clause) {
		if (field instanceof SFieldReference)
			throw new SException.Error("Attempt to query reference field " + field);
		
		if ( needsConjunction )
			and();
		
		rawField(field);
		rawClause(clause);
		
		needsConjunction = true;
		
		return this;
	}
	
	/**
	 * Join to another table, based on the specified reference. <p>
	 *
	 * The INNER join works in both directions.  So either reference may
	 * be from a table that is already in the query to a new table, or
	 * from a new table to a table that is already in the query.<p>
	 *
	 * This method updates both the from and where claues.  After a call
	 * to this method is made, you can simply refer to fields from the
	 * joined table in subsequent calls to the relative operators such
	 * as eq().<p>
	 * 
	 * This provides an alternative to just using subselects.  The effect is 
	 * almost the same except for inner join issues.<p>
	 * 
	 * You can call join() multiple times to join several tables together. This will
	 * work as long as each subsequent join() call makes a connection from the
	 * existing set of tables to a new table.<p>
	 * 
	 * A single table may not be joined multiple times, so there can be
	 * no ambiguity as to which join path to use to access a field.<p>
	 * 
	 * There is an example in BasicTests.queryTest().<p>
	 */
	public SQuery join( SFieldReference reference )
	{
		SRecordMeta joinTable = null;
		if ( joinTables.contains( reference.sRecordMeta ) ||   // Reference is TO new table
				reference.sRecordMeta == record )
		{
			joinTable = reference.referencedRecord;
		}
		else if ( joinTables.contains( reference.referencedRecord ) ||    // Reference is FROM new table
				reference.referencedRecord == record )
		{
			joinTable = reference.sRecordMeta;
			
			// If a join is made on a reference FROM another table to THIS table, this
			// opens up the possibility of multiple rows being returned (e.g. if querying
			// dept, and a join to employee is done, multiple rows would be returned for
			// each department). To avoid this, we will use 'SELECT DISTINCT'
			reverseJoin = true;
		}
		else
		{
			throw new SException.Error( "The following joing reference is not connected " +
					"to current set of joined tables by either end of the reference: " +
					reference );
		}
		
		if (joinTables.contains(joinTable) ||
				joinTable.equals(record))
		{
			// Don't join back to self, or to a table already in join list
			throw new SException.Error("Table " + joinTable + " Cannot be joined twice.");
		}
		else
		{
			joinTables.add(joinTable);
			
			// append joining statements to where clause
			rawClause("(");
			eqJoinReference( (SFieldReference) reference);
			rawClause(")");
		}
		
		return this;
	}
	
	
	/**
	 * Generate the conjunction of equalities for the foreign key columns recursively.
	 * Used for joins
	 */
	private void eqJoinReference( SFieldReference ref )
	{
		for ( int ii = 0; ii < ref.foreignKeyFields.length; ii++ )
		{
			SFieldMeta fkey = ref.foreignKeyFields[ii];
			if ( fkey instanceof SFieldReference )
				eqJoinReference( ( SFieldReference ) fkey );
			else
				fieldRelopParameter( fkey, "=", fkey.referencedKeyField );
		}
	}
	
	/** Compares ref with value, recurively.  operator is normally "=", but can be "NOT NULL" etc.*/
	private void opReference(SFieldReference ref, SRecordInstance value,
			String operator, boolean disjoin, boolean diadic) {
		for (int rx=0; rx<ref.foreignKeyFields.length; rx++) {
			SFieldMeta fkey = ref.foreignKeyFields[rx];
			if (fkey instanceof SFieldReference) {
				opReference((SFieldReference)fkey, value, operator, disjoin, diadic);
			} else {
				SFieldMeta refed = fkey.referencedKeyField;
				if (disjoin && needsConjunction) or(); 
				if (diadic) {
					//Object val = value.fieldValues[refed.fieldIndex];
					Object val = value.getObject(refed);
					fieldRelopParameter(fkey, operator, val);
				} else
					fieldQuery(fkey, operator);
			}
		}
	}
	
	
	SQuery eqNeAux(SFieldMeta field, Object value, boolean isEq) {  
		if (value == null)
			throw new SException.Error("Use isNull to test for nulls " + field);
		String op = isEq?"=":"<>";
		if (!(field instanceof SFieldReference)) {
			return fieldRelopParameter(field, op, value);
		} else {
			if (!(value instanceof SRecordInstance))
				throw new SException.Error(
						"value " + value + " must be an SRecordInstance for reference "
						+ field + " building " + this);
			SFieldReference refFld = (SFieldReference)field;
			SRecordMeta refedRec = refFld.referencedRecord;
			if (((SRecordInstance)value).getMeta() != refedRec)
				throw new SException.Error(
						"Value " + value + " must be a " + refedRec + " building " + this);
			rawClause("(");
			opReference((SFieldReference)field, (SRecordInstance)value, 
					op, !isEq, true);
			rawClause(")");
			return this;
		}
	}
	
	SQuery nullAux(SFieldMeta field, boolean isNull) {
		String op = isNull?"IS NULL":"IS NOT NULL";
		if (!(field instanceof SFieldReference)) {
			return fieldQuery(field, op);
		} else {
			SFieldReference refFld = (SFieldReference)field;
			rawClause("(");
			opReference((SFieldReference)field, null, op, isNull, false);
			rawClause(")");
			return this;
		}
	}
	
	/** Normally just adds <code>fieldRelopParameter(field, "=",
	 value)</code>.<p>
	 
	 If field is a reference it recursively expands the foreign
	 keys, and value must be an instance of the same record type.<p>
	 
	 value must not be null, you need the special case IS NULL test.
	 (It would be possible to optimize this here, but what about
	 field == field where one of them is null -- that would be
	 inconsistent.)<p>
	 */
	public SQuery eq(SFieldMeta field, Object value) {
		return eqNeAux(field, value, true);
	}
	
	public SQuery eq(SFieldMeta field, int value) {
		return eq(field, SJSharp.newInteger(value));
		// Need to create the object to store in the array.
		// Later could add arrays of int etc.
		// If only Java had fixnums!
	}
	public SQuery eq(SFieldMeta field, long value) {
		return eq(field, SJSharp.newLong(value));
	}
	public SQuery eq(SFieldMeta field, double value) {
		return eq(field, SJSharp.newDouble(value));
	}
	public SQuery eq(SFieldMeta field1, SFieldMeta field2) {
		return fieldRelopParameter(field1, "=", field2);
	}
	/**
	 * True if boolean field == writeFieldValue(value).
	 * Ie. value is converted from bool to "Y"/"N" etc.
	 */
	public SQuery equivalent(SFieldBoolean field, boolean value) {
		return eq(field, field.writeFieldValue(value?Boolean.TRUE:Boolean.FALSE));
	}
	/**
	 * shortcut for equivalent(field, true);
	 */
	public SQuery isTrue(SFieldBoolean field) {
		return equivalent(field, true);
	}
	public SQuery isFalse(SFieldBoolean field) {
		return equivalent(field, false);
	}
	
	
	public SQuery ne(SFieldMeta field, int value) {
		return ne(field, SJSharp.newInteger(value));
	}
	
	/** Just adds <code>fieldRelopParameter(field, "<>", value)</code>.<p>
	 
	 Note that there are few methods <code>ne(SfieldMeta, int)</code>
	 etc.  This is because 5 relops * 5 data types would require 25
	 methods!  Java 1.5 boxing will (finally) make this unnecessary anyway. */
	public SQuery ne(SFieldMeta field, Object value) {
		return eqNeAux(field, value, false);
	}
	public SQuery ne(SFieldMeta field, long value) {
		return ne(field, SJSharp.newLong(value));
	}
	public SQuery ne(SFieldMeta field, double value) {
		return ne(field, SJSharp.newDouble(value));
	}
	public SQuery ne(SFieldMeta field1, SFieldMeta field2) {
		return fieldRelopParameter(field1, "<>", field2);
	}
	
	/** Just adds <code>fieldQuery(field, "IS NULL")</code>*/
	public SQuery isNull(SFieldMeta field) {
		return nullAux(field, true);
	}
	/** Just adds <code>fieldQuery(field, "IS NULL")</code>*/
	public SQuery isNotNull(SFieldMeta field) {
		return nullAux(field, false);
	}
	
	/** Just adds <code>fieldRelopParameter(field, "&gt;", value)</code>*/
	public SQuery gt(SFieldMeta field, Object value) {
		return fieldRelopParameter(field, ">", value);
	}
	public SQuery gt(SFieldMeta field, int value) {
		return gt(field, SJSharp.newInteger(value));
	}
	public SQuery gt(SFieldMeta field, long value) {
		return gt(field, SJSharp.newLong(value));
	}
	public SQuery gt(SFieldMeta field, double value) {
		return gt(field, SJSharp.newDouble(value));
	}
	public SQuery gt(SFieldMeta field1, SFieldMeta field2) {
		return fieldRelopParameter(field1, ">", field2);
	}
	
	/** Just adds <code>fieldRelopParameter(field, "&lt;", value)</code>*/
	public SQuery lt(SFieldMeta field, Object value) {
		return fieldRelopParameter(field, "<", value);
	}
	public SQuery lt(SFieldMeta field, int value) {
		return lt(field, SJSharp.newInteger(value));
	}
	public SQuery lt(SFieldMeta field, long value) {
		return lt(field, SJSharp.newLong(value));
	}
	public SQuery lt(SFieldMeta field, double value) {
		return lt(field, SJSharp.newDouble(value));
	}
	public SQuery lt(SFieldMeta field1, SFieldMeta field2) {
		return fieldRelopParameter(field1, "<", field2);
	}
	
	/** Just adds <code>fieldRelopParameter(field, "&lt;=", value)</code>*/
	public SQuery le(SFieldMeta field, Object value) {
		return fieldRelopParameter(field, "<=", value);
	}
	public SQuery le(SFieldMeta field, int value) {
		return le(field, SJSharp.newInteger(value));
	}
	public SQuery le(SFieldMeta field, long value) {
		return le(field, SJSharp.newLong(value));
	}
	public SQuery le(SFieldMeta field, double value) {
		return le(field, SJSharp.newDouble(value));
	}
	public SQuery le(SFieldMeta field1, SFieldMeta field2) {
		return fieldRelopParameter(field1, "<=", field2);
	}
	
	/** Just adds <code>fieldRelopParameter(field, "&gt;=", value)</code>*/
	public SQuery ge(SFieldMeta field, Object value) {
		return fieldRelopParameter(field, ">=", value);
	}
	public SQuery ge(SFieldMeta field, int value) {
		return ge(field, SJSharp.newInteger(value));
	}
	public SQuery ge(SFieldMeta field, long value) {
		return ge(field, SJSharp.newLong(value));
	}
	public SQuery ge(SFieldMeta field, double value) {
		return ge(field, SJSharp.newDouble(value));
	}
	public SQuery ge(SFieldMeta field1, SFieldMeta field2) {
		return fieldRelopParameter(field1, ">=", field2);
	}
	
	/** Use or clause to simulate the in clause */
	public SQuery in(SFieldMeta field, Object[] values) {
		preIn(field);
		for ( int i = 0; i < values.length; i++ ) {
			oneIn(i, field, values[i]);
		}
		rawClause( ")" );
		return this;
	}
	/** Use or clause to simulate the in clause */
	public SQuery in(SFieldMeta field, int[] values) {
		preIn(field);
		for ( int i = 0; i < values.length; i++ ) {
			oneIn(i, field, SJSharp.newInteger(values[i]));
		}
		rawClause( ")" );
		needsConjunction = true;
		return this;
	}
	
	/** value is tokenized into a list of values. 
	 */
	public SQuery in(SFieldMeta field, String value) {
		preIn(field);
		StringTokenizer tokens = new StringTokenizer(value);
		for ( int i = 0; tokens.hasMoreTokens(); i++ ) {
			oneIn(i, field,tokens.nextToken()); 
		}
		rawClause( ")" );
		needsConjunction = true;
		return this;
	}
	
	private void preIn(SFieldMeta field) {
		if ( needsConjunction )
			and();
		rawField(field);
		rawClause(" IN (");
	}
	private void oneIn(int idx, SFieldMeta field, Object value) {
		if ( idx > 0 )
			rawClause(", ");
		rawClause("?");
		rawParameter(value);
	}
	
	/** Just adds <code>fieldRelopParameter(field, "like", value)</code>*/
	public SQuery like(SFieldMeta field, Object value) {
		return fieldRelopParameter(field, "like", value);
	}
	
	
	/**
	 * @deprecated Use the method with only a single argument
	 */
	public SQuery isNull(SFieldMeta field, Object value) {
		return isNull(field);
	}
	/**
	 * @deprecated Use the method with only a single argument
	 */
	public SQuery isNotNull(SFieldMeta field, Object value) {
		return isNotNull(field);
	}
	
	/**
	 * Adds <code>rawClause("AND");
	 * <p> This method is optional. If you call neither and() nor or() between statements
	 * (e.g. eq()), then a call to and() is assumed, and is done for you.
	 * */
	public SQuery and() {
		needsConjunction = false;
		return rawClause("AND");
	}
	/** Adds <code>rawClause("OR"); */
	public SQuery or() {
		needsConjunction = false;
		return rawClause("OR");
	}
	/** Adds <code>rawClause("NOT"); */
	public SQuery not() {
		return rawClause("NOT");
	}
	
	/**
	 * Inserts "(" into the query
	 * @author Pierre Awaragi
	 */
	public SQuery combineBegin()
	{
		return rawClause("(");
	}
	
	/**
	 * Inserts ")" into the query.
	 * @author Pierre Awaragi
	 */
	public SQuery combineEnd()
	{
		return rawClause(")");
	}
	
	/** <code>rawOrderBy(field.columnName)</code> */
	public SQuery ascending(SFieldMeta field) {
		return rawOrderBy( field, true );
	}
	
	/** <code>rawOrderBy(field.columnName) DESC</code> */
	public SQuery descending(SFieldMeta field) {
		return rawOrderBy( field, false );
	}
	
	public String toString(){
		return "[SQuery " + record + " " + where + " BY " + orderBy + "]";
	}
	
	/**
	 * Substitute '?' in the sql query with the values in the parameters array.
	 * Used to create meaningful SQL strings for logging purposes ONLY.
	 */
	static String substitute( String qry, SArrayList parameters )
	{
		StringBuffer buffer = new StringBuffer();
		int fromIndex = 0;
		for ( int ii = 0; ii < parameters.size(); ii++ )
		{
			int index = qry.indexOf( '?', fromIndex );
			buffer.append( qry.substring( fromIndex, index ) );
			buffer.append( quote( parameters.get( ii ) ) );
			fromIndex = index + 1;
		}
		
		buffer.append( qry.substring( fromIndex ) );
		
		return buffer.toString();
	}
	
	private static String quote( Object parameter )
	{
		if ( parameter == null )
		{
			return "NULL";
		}
		
		if ( parameter instanceof Number )
		{
			return parameter.toString();
		}
		
		return "'" + parameter + "'";
	}
}


