package simpleorm.core;
import simpleorm.properties.*;
import java.sql.ResultSet;

/** Represents Bytes field meta data.  Ie. Just a byte array.
 * Note that thisis just for relatively short strings, see Blob. */

public class SFieldBytes extends SFieldScalar {
  public SFieldBytes(SRecordMeta meta, String columnName, int maxSize, 
    SPropertyValue [] pvals) {
    super(meta, columnName, pvals);
    putProperty(SCon.SBYTE_SIZE, SJSharp.newInteger(maxSize)); // for Create Table only.
  }
  public SFieldBytes(SRecordMeta meta, String columnName, int maxSize) {
    this(meta, columnName, maxSize, new SPropertyValue[0]);
  }
  public SFieldBytes(SRecordMeta meta, String columnName, int maxSize, 
     SPropertyValue pval) {
    this(meta, columnName, maxSize, new SPropertyValue[]{pval});
  }
  public SFieldBytes(SRecordMeta meta, String columnName, int maxSize, 
     SPropertyValue pval1, SPropertyValue pval2) {
    this(meta, columnName, maxSize, new SPropertyValue[]{pval1, pval2});
  }

  /** Abstract specializer.  Clone this key field to be a foreign key
      to <code>rmeta</code> of the same type.*/
  SFieldMeta makeForeignKey(
    SRecordMeta rmeta, String prefix, SPropertyValue [] pvals) {
    return new SFieldBytes(rmeta, 
      (prefix==null?"":prefix)+getString(SCon.SCOLUMN_NAME), 
      SJSharp.object2Int(getProperty(SCon.SBYTE_SIZE)),
      pvals);
  }

  Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception {
    Object res = rs.getBytes(sqlIndex);
    return res;
  }

  Object convertToField(Object raw) {
    return raw;
  }

  /** Specializes SFieldMeta. */
  String defaultDataType(){return "BYTES";}

}
