package simpleorm.core;

/**
 * Generator using Identity columns which have values added by the database when
 * rows are inserted.  Only supported by some dbs, notably MSSQL.
*/
public class SGeneratorInsertIdentity extends SGenerator {

	public SGeneratorInsertIdentity(SRecordMeta record) {super(record);}

	protected long generateKey(SRecordMeta meta, SFieldMeta keyField) {
		throw new SException.Error("Not implemented yet.");
	}

}