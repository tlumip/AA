package simpleorm.core;

import simpleorm.properties.*;
import java.sql.ResultSet;

/** Represents columns that are not objects known to SimpleORM.  No
 conversions are done, so this provides a direct gateway to
 <code>java.sql.RecordSet.getObject</code>.  Useful for database
 specific data types such as PostgreSQL's GIS types, and also for
 the new SQL array and object types. <p>
 
 ## Should add the JDBC object mapping property, but normally the
 default map is OK.*/

public class SFieldObject extends SFieldScalar {
	public SFieldObject(SRecordMeta meta, String columnName,
			SPropertyValue [] pvals) {
		super(meta, columnName, pvals);
	}
	public SFieldObject(SRecordMeta meta, String columnName) {
		this(meta, columnName, new SPropertyValue[0]);
	}
	public SFieldObject(SRecordMeta meta, String columnName,
			SPropertyValue pval) {
		this(meta, columnName, new SPropertyValue[]{pval});
	}
	public SFieldObject(SRecordMeta meta, String columnName,
			SPropertyValue pval1, SPropertyValue pval2) {
		this(meta, columnName, new SPropertyValue[]{pval1, pval2});
	}
	
	/** Abstract specializer.  Clone this key field to be a foreign key
	 to <code>rmeta</code> of the same type.*/
	SFieldMeta makeForeignKey(
			SRecordMeta rmeta, String prefix, SPropertyValue [] pvals) {
		return new SFieldObject(rmeta,
				(prefix==null?"":prefix)+getString(SCon.SCOLUMN_NAME),
				pvals);
	}
	
	/** Specidalizes abstract method to actually query a column from a
	 result set. */
	Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception {
		Object res = rs.getObject(sqlIndex);
		if (rs.wasNull()) // ie. last operation!
			return null;
		else
			return res;
	}
	
	Object convertToField(Object raw)  throws Exception {
		return raw;  // No Conversions.
	}
	
	String defaultDataType(){
		return "OBJECT";
	}
}
