package simpleorm.core;

/**
 * Wrapper required for J# compatibility.
 */

public interface SSerializable extends java.io.Serializable {}

// j# public interface SSerializable {}
