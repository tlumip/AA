package simpleorm.core;
import simpleorm.properties.*;

import java.util.HashMap;
import java.sql.*;
import java.io.*;
/*
 * Copyright (c) 2002 Southern Cross Software Queensland (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/** Defines the meta data for a {@link SRecordInstance} such as
 the table name.  Details about each field are stored in
 {@link SFieldMeta} refered to from this object.<p>
 
 Thus Instance Variables of this class only describe the
 definition of a Record, not instances or connections.<p>
 
 This class also contains routines to create new {@link SRecordInstance}es
 such as {@link #findOrCreate} and {@link #select}.
 (This packaging makes the calls shorter than using a static
 method on SRecordInstance.)<p>
 
 */

public class SRecordMeta extends SPropertyMap implements Serializable {
	/** instances_ is a hash map of SRecordMetas.  key is userClassName,
	 * and value is SRecordMeta. Static map of all SRecordMeta
	 * instances.  used for de-serialization
	 */
	private static HashMap instances_ = new HashMap();
	
	/** Name of underlying java class. Used for de-serialization */
	private String userClassName;
	
	/** The underlying java class for this object. */
	transient protected Class userClass;
	
	/** The SFieldMetas within this record. <p> This contains both the
	 foreign keys and then the sFieldReference, ie. it is totally
	 flattened.*/
	transient SArrayList sFieldMetas = new SArrayList(20);  // of SFieldMeta.
	
	/** The names of fields store redundantly.  
	 Only to be used within the debugger.
	 */
	transient public SArrayList sFieldNames = new SArrayList(20);  // of String
	/** All the field names.  use getField to look up the actual field. 
	 See also SFIELD_MAP property etc.*/
	public SArrayList getFieldNames() {return sFieldNames;}
	
	/** Exactly the same elements as SFieldMetas, but keyed by field
	 names which default to column names or reference table names or
	 prefixes. */
	transient HashMap fieldMap = new HashMap(20);
	
	/** The Primary Key fields. <p> Contains both foreign keys
	 (recursively) and sFieldReference.*/
	transient SArrayList keySFieldMetas = new SArrayList(2); // primary keys
	

	/** Create a new table/record definition.<p>
	 
	 @param userClass When a (@link #SRecordInstant} is created by
	 {@link #findOrCreate}, it is cast to this class which must extend
	 SRecordInstant.  It is normally unique for each SRecordMeta, but
	 that is not strictly required.
	 
	 @param tableName The name of the SQL table that will be
	 associated with this record.
	 
	 @param pvalues Arbitrary properties that can be associated with
	 this record.  Rarely used.
	 */
	public SRecordMeta(Object userClass, String tableName,
			SPropertyValue [] pvalues) {
		Class clas = SJSharp.castToClass(userClass);
		if (!SRecordInstance.class.isAssignableFrom(clas))
			throw new SException.Error(
					"Class must be an SRecordInstance " + clas);
		this.userClass = clas;
		putProperty(SCon.STABLE_NAME, tableName);
		
		if (pvalues != null) setPropertyValues(pvalues);
		
		userClassName = clas.getName();
		instances_.put( userClassName, this );
	}
	public SRecordMeta(Object userClass, String tableName){
		this(userClass, tableName, null);
	}
	
	/** Returns the field by SFIELD_NAME, or null if not found. */
	public SFieldMeta getField(String fieldName) {
		return (SFieldMeta)fieldMap.get(fieldName);
	}
	
	
	/** Returns a <code>CREATE TABLE...</code> for this table.  Delegates
	 to the database driver.*/
	public String createTableSQL() {
		return SConnection.getDriver().createTableSQL(this);
	}
	
	/** Searches first the cache and then the database for a record with
	 the primary key == <code>keys</code>.  If one is found returns
	 it, otherwise creates a new SRecordInstance prepopulated with
	 the primary key.<p>
	 
	 For multi valued concurrency databases such as Oracle and
	 PostgreSQL, the row is usually selected <code>FOR UPDATE</code> unless
	 {@link #SQY_READ_ONLY}.<p>
	 
	 In either case {@link #findOrCreate} never schedules the
	 record to be updated or inserted.  That happens when one makes
	 it dirty by setting a field value or perhaps
	 SRecordInstance.setDirty().<P>
	 
	 The selectList is usually defaulted based on the sqy_bitSet.<p>
	 
	 If the record has identifying foreign keys the <code>keys</code>
	 must contain referenced records, not the actual foreign keys.<p>
	 
	 The APIs have been carefully designed so that SQL queries can be
	 made lazily.  Ie. just schedule the query to be performed the
	 first time a field value is referenced.  This enables efficient
	 batching techniques.  However, this implementation performs the
	 queries eagerly, ie. the SQL query is issued by this method.<p>
	 
	 This always finds or creates a record within the context of a
	 connection.  {@link #createDetached} can be used to create a new
	 record while not attached.
	 
	 See also the SQY_* constants.<p>
	 
	 @see #find
	 @see #create
	 */
	public SRecordInstance findOrCreate(
			Object keys, long sqy_bitSet, SFieldMeta[] selectList) {
		
		return SRecordFinder.findOrCreate(this, keys, sqy_bitSet, selectList);
	} // findOrCreate
	
	public SRecordInstance findOrCreate(Object keys) {
		return findOrCreate(keys, 0);
	}
	public SRecordInstance findOrCreate(Object keys, long sqy_bitSet) {
		return findOrCreate(keys, sqy_bitSet,
				fieldList(sqy_bitSet | SCon.SQY_NO_REFERENCES));
		// Could also suppress Primary Keys from select list as we already
		// have them.  But keys are normally small so retrieving them is
		// cheap and we get a good consistency check that they agree with
		// the query.
	}

	/**
	 * Same as findOrCreate(key) but returns null if not found
	 * instead of createing a new record.
	 * @see #mustFind(Object)
	 * @see #findOrCreate(Object)
	 */
	public SRecordInstance find(Object keys) {
		SRecordInstance found =  findOrCreate(keys);
		if (found.isNewRow()) found = null;
		return found;
	}
	/**
	 * Same as find(key) but throws an exception if the record is not found.
	 * @see #find
	 */
	public SRecordInstance mustFind(Object keys) {
		SRecordInstance found = findOrCreate(keys);
		if (found.isNewRow()) 
			throw new SException.Data("Record not found " + found);
		return found;
	}
	/**
	 * Same as findOrCreate(key) but asserts must be a new row.
	 * Also sets the row Dirty so that it will actually be inserted even if no 
	 * other non-key fields are set.<p>
	 * 
	 * It is assumed that the record is not in the database, you will
	 * get an SQL exception if it already exists.  This saves a SELECT statement.
	 * But if there is any doubt use findOrCreate instead and then check .isNewRow.<p>
	 * 
	 * A check is also made that the row is not already in the cache, ie. two calls to 
	 * create with the same key will produce an exception.<p>
	 * 
	 * @see #findOrCreate(Object, long, SFieldMeta[])
	 */
	public SRecordInstance create(Object keys) {
		SRecordInstance found =  findOrCreate(keys, SCon.SQY_ASSUME_CREATE);
		found.assertNewRow(); // always true as 
		if (found.wasInCache())
			throw new SException.Error(
					"Attempt to create row that was already in the cache " + found);
		found.setDirty();
		return found;
	}
	
	/** Returns SFieldMetas to select given bitSet.
	 ### This needs a careful review. */
	SFieldMeta[] fieldList(long sqy_bitSet) {
		// ## This is a little expensive, results could be cached,
		// along with the queries that are actually generated.
		SFieldMeta[] result = null;
		int resultSize = 0;
		// Two passes, first to work out result size, second to build it up.
		// This will be faster than another SArrayList.
		for (int pass=0; pass<2; pass++) {
			for (int fx=0; fx<sFieldMetas.size(); fx++) {
				SFieldMeta field = (SFieldMeta)sFieldMetas.get(fx);
				//System.out.println("selectList " + pass + field + sqy_bitSet +
				//  SUte.inBitSet(sqy_bitSet, SQY_NO_FOREIGN_KEYS, SQY_) +
				//  SUte.inBitSet(sqy_bitSet, SQY_NO_REFERENCES, SQY_) );
				
				if (SUte.inBitSet(sqy_bitSet, SCon.SQY_PRIMARY_KEY, SCon.SQY_)
						&& !field.isPrimaryKey) continue; // ie.ONLY primary keys.
				//  ## Change to run down keySFieldMetas if primary.  Or maybe
				//  just get rid of keySFieldMetas.
				
				// ## Problems if SDESCRIPTIVE etc. is a Reference
				if (SUte.inBitSet(sqy_bitSet, SCon.SQY_DESCRIPTIVE, SCon.SQY_)
						&& !field.getBoolean(SCon.SDESCRIPTIVE)
						&& !field.isPrimaryKey)
					continue;
				if (!SUte.inBitSet(sqy_bitSet, SCon.SQY_UNQUERIED, SCon.SQY_)
						&& field.getBoolean(SCon.SUNQUERIED))
					continue;
				if (SUte.inBitSet(sqy_bitSet, SCon.SQY_NO_FOREIGN_KEYS, SCon.SQY_)
						&& field.sFieldReference != null) // DataLoader
					continue;
				if (SUte.inBitSet(sqy_bitSet, SCon.SQY_NO_REFERENCES, SCon.SQY_)
						&& field instanceof SFieldReference)
					continue;
				
				if (SUte.inBitSet(sqy_bitSet, SCon.SQY_NO_GENERATED_KEYS, SCon.SQY_)
						&& field.getProperty(SCon.SGENERATED_KEY) != null)
					continue;
				
				// Not rejected so include this field.
				if (pass == 1) result[resultSize] = field;
				resultSize++;
			}
			if (pass == 0) result = new SFieldMeta[resultSize];
			resultSize = 0;
		}
		return result;
	}
	
	
	/** Given a list of fields, add primary key fields and then replace
	 any reference fields with their foreign keys.  Normally one
	 works with references, but when queries are generated one needs
	 the ground columns. */
	SFieldMeta[] expandSelectList(SFieldMeta[] fields) {
		SArrayList xfields = new SArrayList(fields.length * 2);
		
		// Add primary keys if missing
		mpxl: for (int mpx=0; mpx<keySFieldMetas.size(); mpx++) {
			SFieldMeta mp = (SFieldMeta)keySFieldMetas.get(mpx);
			if (!(mp instanceof SFieldReference)) {
				for (int qpx=0; qpx<xfields.size(); qpx++)
					if (xfields.get(qpx) == mp) continue mpxl;
					// Key not in query, add it.  (Should be rare) Where are Java's array functions?
				if (!xfields.contains(mp)) xfields.add(mp);
			}
		}
		
		// Expand References.
		expandSelectListRecur(xfields, fields);
		return (SFieldMeta[])xfields.toArray(new SFieldMeta[0]);
	}
	private void expandSelectListRecur(SArrayList xfields, SFieldMeta[] fields) {
		for (int fx=0; fx<fields.length; fx++) {
			SFieldMeta field = fields[fx];
			if (field instanceof SFieldReference)
				expandSelectListRecur(xfields,
						((SFieldReference)field).foreignKeyFields);
			else
				if (!xfields.contains(field)) xfields.add(field);
		}
	}
	
	/** Produce an SQL Query, prepare it, and return an
	 {@link SPreparedStatement}.  See that class for an example of its use.
	 <code>where</code> and <code>orderBy</code> are SFieldMetas that
	 arecopied literally into the query.  The SQY_* BitSets are defined
	 in SConstants.<p>
	 
	 (This delegates the actual query creation to the Driver class.)  */
	public SPreparedStatement select(
			String where, String orderBy, long sqy_bitSet, SFieldMeta[] selectList) {
		return select(where, orderBy, sqy_bitSet, selectList,
				new SPreparedStatement());
	} 
	/** Use this variant to add extra parameters between ps creation and
	 * sql generation.  Also use it to subclass ps*/
	public SPreparedStatement select(
			String where, String orderBy, long sqy_bitSet, SFieldMeta[] selectList,
			SPreparedStatement ps)
	{
		ps.prepareStatement(this,
				where, orderBy, sqy_bitSet,
				selectList == null ? fieldList(sqy_bitSet | SCon.SQY_NO_REFERENCES)
						: expandSelectList(selectList));
		return ps;
	}
	
	public SPreparedStatement select(
			String where, String orderBy, long sqy_bitSet) {
		return select(where, orderBy, sqy_bitSet, null);
	}
	public SPreparedStatement select(String where, String orderBy) {
		return select(where, orderBy, 0);
	}
	
	
	/** Start a query using the query builder instead of raw SQL.
	 @see SQuery
	 @see #select
	 */
	public SQuery newQuery(long sqy_bitSet, SFieldMeta[] selectList) {
		return new SQuery(this, sqy_bitSet, selectList);
	}
	public SQuery newQuery(long sqy_bitSet) {
		return newQuery(sqy_bitSet, null);
	}
	public SQuery newQuery() {
		return newQuery(0);
	}
	
	
	public String toString() {
		return "[SRecordMeta " + SUte.cleanClass(userClass) + "]";
	}
	
	/** Returns a list of all the fields for debugging. */
	public String allFieldsString() {
		StringBuffer res = new StringBuffer(this + ":-\n");
		for (int fx=0; fx<sFieldMetas.size(); fx++) {
			res.append(
					"    " + ((SFieldMeta)sFieldMetas.get(fx)).toLongerString() + "\n");
		}
		return res.toString();
	}
	
	/**
	 * Returns the (one) generator for the one key of this SRecord.
	 */
	public SGenerator getSGenerator() {
		/// Get and check primary key details
		if (keySFieldMetas.size() != 1)
			throw new SException.Error("Must only have one key field if generated " + this);
		SFieldMeta keyfld = (SFieldMeta)keySFieldMetas.get(0);
		SGenerator gkey = (SGenerator)keyfld.getProperty(SCon.SGENERATED_KEY);
		if (gkey == null)
			throw new SException.Error(keyfld + " is not SGENERATED_KEY");
		
		return gkey;
	}
	
	/** Creates a new object with a newly generated key.  Note that the
	 SELECT MAX method is used unless a database dependent
	 alternative is available (currently only for PostgreSQL). {@link
	 SGENERATED_KEY}.
	 
	 Always creates a new empty record. 
	 
	 ## This code is partially copied into SRecordInstance.attach() for
	 records created while detached.
	 */
	public SRecordInstance createWithGeneratedKey() {
		SFieldMeta keyfld = (SFieldMeta)keySFieldMetas.get(0);  	
		SRecordInstance newRec = getSGenerator().createWithGeneratedKey(this, keyfld);
		return newRec;
	}
	
	/** Flushes and Purges all record instances for this table.
	 <code>SConnection.flushAndPurge()</code> may be more useful in
	 practice.
	 
	 @see SRecordInstance#flushAndPurge
	 @see SConnection#flushAndPurge
	 */
	public void flushAndPurge() {
		SConnection scon = SConnection.getBegunConnection();
		java.util.Iterator ci = scon.transactionCache.values().iterator();
		while (ci.hasNext()) {
			SRecordInstance ri = (SRecordInstance)ci.next();
			if (ri.getMeta() == this) {
				ri.flush();
				ci.remove(); // #### Is this correct?  Deleting cursor?
				ri.incompleteDestroy();
			}
		}
	}
	
	/**
	 * Create an SRecordInstance that will be initially detached. All
	 * key fields must be populated before attaching unless they are
	 * generated keys. Objects created this way
	 * <i>must not</i> not have existed in the database previously, or a unique
	 * key violation exception is thrown by JDBC at flush() time.
	 * <p>
	 * A typical use of this method is by a thick-client application that
	 * creates a record, and then passes it to the application server which, in turn,
	 * will insert it into the database.<p>
	 *
	 * The primary key can be set either using the key parameter,
	 * explicitly after this method using set*, just before it
	 * is reattached and the database is thus available, or if it is
	 * generated then it can be automatically created by the attach()
	 * method.
	 *
	 * @return SRecordInstance A newly created 'blank' record
	 * @see simpleorm.core.SRecordInstance#attach
	 */
	public SRecordInstance createDetached()
	{
		try
		{
			SRecordInstance instance = ( SRecordInstance ) userClass.newInstance();
			instance.readOnly = false;
			instance.newRow = true;
			
			// Set all nullable fields as if they contained valid data. Without this, objects
			// created this way become hyper-sensitive, in that even when the data
			// could legitimately be null, they throw exceptions when you try
			// to access those fields
			for ( int ii = 0; ii < sFieldMetas.size(); ii++ )
			{
				//if ( !((SFieldMeta)sFieldMetas.get( ii )).getBoolean( SMANDATORY ) )
				{
					instance.bitSets[ii] = SCon.INS_VALID;
				}
			}
			
			return instance;
		}
		catch ( Exception ie )
		{
			throw new SException.Data( ie );
		}
	}
	
	
	/**
	 createDetached() and then sets the key field(s).
	 */
	public SRecordInstance createDetached(Object key) {
		
		SRecordInstance inst = createDetached();
				
		SRecordFinder.setPrimaryKeys(inst, key);
		
		return inst;
	}
	
	/**
	 * SRecordMeta is like a singleton, in that only one instance of SRecordMeta must
	 * exist in the VM for a specific table. This is a special method used during
	 * de-serialization to determine if the object de-serialized should be substituted.
	 * This method is implemented to return the SRecordMeta object for the appropriate
	 * user Class that already exists.
	 */
	protected Object readResolve()
	throws ObjectStreamException
	{
		try
		{
			Class.forName(userClassName);    // This forces class to load and, thus, its SRecordMeta to be instantiated
			
			Object substituted = instances_.get(userClassName);
			if (substituted == null)
			{
				throw new NullPointerException();
			}
			return substituted;
		}
		catch ( Exception e )
		{
			throw new SException.InternalError( "Error de-serializing SRecordMeta for " + userClassName);
		}
	}
	
}

