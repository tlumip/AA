package simpleorm.core;

public class SEnum //extends SFieldMeta {
{
  /*
  public String createColumnSQL(){}
  public SEnum(String value){}
  public static boolean isValid(Locale locale, String value){}
  */
}
