package simpleorm.core;
import simpleorm.properties.*;
import java.sql.ResultSet;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;


/** Represents a BLOB, Binary large object.  See SFieldBytes for short binary strings.
 * Supports returning the entire blob as a byte array, but that is not normal practice.
 * ### Untested. */

public class SFieldBlob extends SFieldScalar {
  public SFieldBlob(SRecordMeta meta, String columnName, int maxSize, 
    SPropertyValue [] pvals) {
    super(meta, columnName, pvals);
    putProperty(SCon.SBYTE_SIZE, SJSharp.newInteger(maxSize)); // for Create Table only.
  }
  public SFieldBlob(SRecordMeta meta, String columnName, int maxSize) {
    this(meta, columnName, maxSize, new SPropertyValue[0]);
  }
  public SFieldBlob(SRecordMeta meta, String columnName, int maxSize, 
     SPropertyValue pval) {
    this(meta, columnName, maxSize, new SPropertyValue[]{pval});
  }
  public SFieldBlob(SRecordMeta meta, String columnName, int maxSize, 
     SPropertyValue pval1, SPropertyValue pval2) {
    this(meta, columnName, maxSize, new SPropertyValue[]{pval1, pval2});
  }

  /** Abstract specializer.  Clone this key field to be a foreign key
      to <code>rmeta</code> of the same type.*/
  SFieldMeta makeForeignKey(
    SRecordMeta rmeta, String prefix, SPropertyValue [] pvals) {
    return new SFieldBlob(rmeta, 
      (prefix==null?"":prefix)+getString(SCon.SCOLUMN_NAME), 
      SJSharp.object2Int(getProperty(SCon.SBYTE_SIZE)),
      pvals);
  }

  Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception {
  	//  From Marcius.  just getBytes should actually work though, but maybe not in Oracle
    //Object res = rs.getBytes(sqlIndex);  
    //return res;

  	// Get the binary content from the result set as a stream 
		InputStream is = rs.getBinaryStream(sqlIndex);
		// Create a byte array output stream so we can convert the content to a byte[]
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		// A small buffer to reduce the number of reads 
		byte[] buf = new byte[1024];
		// Read bytes from the input stream and place them in the baos
    int bytesRead = is.read(buf);
		while (bytesRead > 0) {
		  baos.write(buf, 0, bytesRead);
		  bytesRead = is.read(buf);
		}
		return baos.toByteArray();  	
  }

  Object convertToField(Object raw) {
    return raw;
  }

  /** Specializes SFieldMeta. */
  String defaultDataType(){return "BLOB";}

}
