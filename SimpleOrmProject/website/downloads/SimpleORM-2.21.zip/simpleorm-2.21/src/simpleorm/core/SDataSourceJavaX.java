package simpleorm.core;
import java.sql.Connection;
import java.util.Properties;
import javax.sql.DataSource;


/**
 * SDataSource for using javax.sql.DataSource.
 * 
 * If you are using Java 1.3 or earlier just remove this class from the distribution,
 * it is not needed.<p>
 * <pre>
 * Context ctx = new InitialContext();
 * DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/TestDB");
 * SDataSource sds = new SDataSourceJavaX(ds);
 * SConnection.attach(sds, "MyCon");
 * </pre>
 */
public class SDataSourceJavaX extends SDataSource {

	DataSource dataSource;
	
	public DataSource getDataSource() {
		return dataSource;
	}
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public SDataSourceJavaX(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	protected Connection openDBConnection() {
		Connection con;
		try {
			con = dataSource.getConnection();
		} catch (Exception ex) {
			throw new SException.JDBC("Opening " + dataSource, ex);
		}
		return con;

	}
}
