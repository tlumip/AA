package simpleorm.core;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import simpleorm.core.SException.InternalError;
import simpleorm.core.SException.JDBC;
import simpleorm.properties.SPropertyValue;

/**
 * Overflow of SRecordMeta code to retrieve records
 */
class SRecordFinder {

	/**
	 * Implementation of SRecordMeta.findOrCreate
	 */
	static SRecordInstance findOrCreate(SRecordMeta meta, Object key, long sqy_bitSet, SFieldMeta[] selectList) {
		SConnection scon = SConnection.getBegunConnection();
				
		boolean readOnly = SUte.inBitSet(sqy_bitSet, SCon.SQY_READ_ONLY, SCon.SQY_);
		boolean unrepeatableRead = SUte.inBitSet(sqy_bitSet, SCon.SQY_UNREPEATABLE_READ, SCon.SQY_);
		boolean optimistic
		= SUte.inBitSet(sqy_bitSet, SCon.SQY_OPTIMISTIC, SCon.SQY_)
		|| (!scon.getDriver().supportsLocking() && !readOnly);
		
		selectList = meta.expandSelectList(selectList);
		
		if (SLog.slog.enableFields())
			SLog.slog.fields("findOrCreate " + meta + " "
					+ SUte.arrayToString(key) + (readOnly?" ReadOnly":"")
					+ (optimistic?" Optimistic":""));
		if (readOnly && optimistic)
			throw new SException.Error(
					"Cannot be both Optimistically Locked and ReadOnly " + meta);
		
		/// Create key object.  Discarded if found in cache.
		SRecordInstance keyInstance = null;
		try {
			keyInstance = (SRecordInstance)meta.userClass.newInstance();
		} catch (Exception ie) {throw new SException.Data(ie);}
		setPrimaryKeys(keyInstance, key);
		
		/// See if the record has already been retrieved in this transaction.
		SRecordInstance instance
			= (SRecordInstance)scon.transactionCache.get(keyInstance);
		
		boolean requery = false;
		
		/// If previously retrieved then see if we need to requery.
		if (instance != null) {
			instance.wasInCache = true;
			/// See if we need to requery because there are extra fields.
			// ### Need to recur if foreign keys.
			requery = !readOnly && instance.readOnly;
			for (int sx=0; sx<selectList.length && !requery; sx++) {
				SFieldMeta selF = selectList[sx];
				byte selFSet = instance.bitSets[selF.fieldIndex];
				requery = requery || ((selFSet & SCon.INS_VALID) == 0);
				if (!readOnly)
					requery = requery || ((selFSet & SCon.INS_READ_ONLY) != 0);
			}
			
			if (SLog.slog.enableQueries())
				SLog.slog.queries("findOrCreated: " + instance + " (from cache)"
						+  (instance.newRow?" New Row":" Existing Row")
						+  (requery?" Requerying...":""));
			if (instance.sConnection != scon)
				throw new SException.Error(
						"Inconsistent Connections "
						+ instance + instance.sConnection + scon);
		} else
			keyInstance.wasInCache = false;
		
		/// (re)Query the database
		if (instance == null || requery) {
			instance = findInDatabase(
					meta,
					instance!=null?instance:keyInstance, // If requery
							sqy_bitSet, selectList,
							scon, readOnly, optimistic, unrepeatableRead, 
							null); // ### Need to bring out this props parameter.
			if (SLog.slog.enableQueries())
				SLog.slog.queries("findOrCreate: " + instance
						+ " (from database)" +  (instance.newRow?" New Row":" Existing Row"));

			if (instance.newRow)
				validatePrimaryKeys(instance);  // Could throw SValidationException

			scon.transactionCache.put(instance, instance);
			// equals() is defined below
			instance.sConnection = scon;
		}
		if (instance.getMeta() != meta)
			throw new SException.InternalError(
					"Found " + instance + " instead of " + meta);
		return instance;
	}

	/** Sets just the primary key fields, used to lookup
	 transactionCache.  See equals(). <p>
	 
	 For foreign keys, <code>pkeys</code> only contains the reference
	 object, not the foreign keys themselves.<p>
	 
	 Primary keys are not set dirty.
	 */
	static void setPrimaryKeys(SRecordInstance inst, Object pkey) {
		/// If keys is a single key then make it an singleton array.
		Object [] npkeys = null;
		int keylen=1;
		if (pkey instanceof Object[]) {
			npkeys = (Object [])pkey;
		  keylen = npkeys.length;
		}
		SRecordMeta meta = inst.getMeta();
		int kx=-1;
		for (int mx=0; mx<meta.keySFieldMetas.size(); mx++) {
			SFieldMeta keyf = (SFieldMeta)meta.keySFieldMetas.get(mx);
			if (keyf.sFieldReference == null) { // Top level only
				kx++;
				
				if (keylen < kx+1)
					throw new SException.Data(
							"Too few key params " + SUte.arrayToString(pkey));

				Object rawValue = npkeys != null ? npkeys[kx] : pkey;
				if (rawValue == null)
					throw new SException.Data("Null Primary key " + keyf + " " + kx);
				
				/// Convert rawValue if necessary.
				Object convValue = null;
				try {
					convValue = keyf.convertToField(rawValue);
				} catch (Exception ex) {
					throw new SException.Data(
							"Converting " + rawValue + " for " + inst + "." + keyf, ex);
				}
				
				// For references this will also copy the foreign key values.
				//SLog.slog.debug("setPrimaryKey " + keyf + this + convValue);
				keyf.rawSetFieldValue(inst, convValue);
			}
		}
		if (kx+1 != keylen)
			throw new SException.Error("Too many key params "
					+ (kx+1) + " < " + SUte.arrayToString(pkey) + ".length");
	}

	/** Look up the database for a record with keys that are now in
	 <code>instance</code> and populate <code>instance</code>
	 appropriately.*/
	static private SRecordInstance findInDatabase(
			SRecordMeta meta,
			SRecordInstance instance,
			long sqy_bitSet, SFieldMeta[] selectList,
			SConnection scon, boolean readOnly, boolean optimistic, boolean unrepeatableRead,
			SPropertyValue [] props) {
		
		//System.out.println("findInDatabase " + meta + SLog.arrayToString(selectList));
		boolean existing = false;
		if (SUte.inBitSet(sqy_bitSet, SCon.SQY_ASSUME_CREATE, SCon.SQY_)) {
			existing = false;
		} else {
			/// Determine the SQL Query
			String qry = scon.sDriver.selectSQL(
					selectList, meta,
					meta.fieldList(SCon.SQY_PRIMARY_KEY | SCon.SQY_NO_REFERENCES), // for WHERE
					null, !readOnly && !optimistic, unrepeatableRead, null);
			
			if (SLog.slog.enableQueries())
				SLog.slog.queries("findOrCreate querying '" + qry + "'...");
			
			/// Prepare the statement
			Connection con = scon.jdbcConnection;
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				try {
					ps = con.prepareStatement(qry); // Let the JDBC driver cache these.
				} catch (Exception psex) {
					throw new SException.JDBC("Preparing '" + qry + "'", psex);
				}
				/// Set the primary key
				int qkx=0;
				for (int kx=0; kx<meta.keySFieldMetas.size(); kx++) {
					SFieldMeta key = (SFieldMeta)meta.keySFieldMetas.get(kx);
					if (!(key instanceof SFieldReference)) {
						qkx++;
						Object value = instance.fieldValues[key.fieldIndex];
						try {
							ps.setObject(qkx, value);
						} catch (Exception se) {
							throw new SException.JDBC(
									"Setting preQuery " + instance + "'" + qry
									+ "' Field " + qkx + " to " + value, se);
						}
					}
				}
				/// Execute the Query
				try {
					rs = ps.executeQuery();
				} catch (Exception rsex) {
					throw new SException.JDBC(
							"Executing '" + qry + "' for " + instance, rsex);
				}
				
				/// Retrieve the result.
				try { existing = rs.next(); }
				catch (Exception ne1) {
					throw new SException.JDBC("Nexting " + instance, ne1);
				}
				if (existing) {
					SRecordFinder.retrieveRecord(
							instance, selectList, rs, readOnly, optimistic, true);
					boolean next=false;
					try { next = rs.next(); }
					catch (Exception ne2) {throw new SException.JDBC(ne2);}
					if (next)
						throw new SException.JDBC("Primary key not unique " + instance);
				}
			} finally {
				try { if (rs!=null) rs.close(); }
				catch (Exception cl1) {
					throw new SException.JDBC("Closing rs " + instance, cl1);
				}
				try { if (ps!=null) ps.close(); }
				catch (Exception clp) {
					throw new SException.JDBC("Closing ps " + instance, clp);
				}
			}
		}
		
		if (!existing) { // not in database
			instance.newRow = true;
			instance.readOnly = readOnly;
			/// Make all fields settable.
			// (Need to do this so still setable after a flush())
			// New rows have a hard gettable default of null.
			for (int ifx=0; ifx<meta.sFieldMetas.size(); ifx++) {
				SFieldMeta iff = (SFieldMeta)meta.sFieldMetas.get(ifx);
				//if ( !iff.getBoolean( SMANDATORY ) )
				instance.bitSets[iff.fieldIndex] |= SCon.INS_VALID;
			}
		}
		
		// Null the primary-key references, since they may be detached
		// references, which does not make sense in an attached instance.
		// (A subsequent getReference would do a findOrCreate.)
		//
		// ##Bartek. I think this is now redundant given getRawFieldValue suppresses
		// references to detached records.
		for (int ifx=0; ifx<meta.sFieldMetas.size(); ifx++) {
			if ( meta.sFieldMetas.get( ifx ) instanceof SFieldReference ) {
				SRecordInstance keyr = (SRecordInstance)instance.fieldValues[ifx];
				if ( keyr != null && (!keyr.isValid() || !keyr.isAttached()) )
					instance.fieldValues[ifx] = null;
			}
		}
		
		return instance;
	} // findInDatabase

	/**
	 * Map SRecordInstance.validateField for all primary keys.
	 * This is only called for newly created records, not for each find,
	 * which is why it needs to be done in a different pass.
	 */
	static void validatePrimaryKeys(SRecordInstance inst) {
		/// If keys is a single key then make it an singleton array.
		SRecordMeta meta = inst.getMeta();
		for (int mx=0; mx<meta.keySFieldMetas.size(); mx++) {
			SFieldMeta keyf = (SFieldMeta)meta.keySFieldMetas.get(mx);
			if (keyf.sFieldReference == null) { // Top level only
				Object valu = keyf.getFieldValue(inst, 0); 
				inst.validateField(keyf, valu);
			}
		}
	}

	/** Called from SRecordMeta and SResultSet to acutally retrieve the
	 record.  <code>selectList</code> includes primary key fields.
	 Calls <code>SField*.queryVieldValue</code> to actually
	 retrieve the values.*/
	static void retrieveRecord(
			SRecordInstance instance, 
			SFieldMeta[] selectList, ResultSet rs, 
			boolean readOnly, boolean optimistic, boolean checkPrimaryKey) {
		/// Retrieve each fieldValue[]
		for (int fx=0; fx<selectList.length; fx++) {
			SFieldMeta fMeta  = selectList[fx];
			int ffx = fMeta.fieldIndex;
			Object qvalue = null;
			try {
				qvalue = fMeta.queryFieldValue(rs, fx+1);
			} catch (Exception ge) {
				throw new SException.JDBC(
						"Getting Field " + (fx+1) + " from " + instance, ge);
			}
			if (checkPrimaryKey && fMeta.isPrimaryKey)
				if (qvalue == null || !trimStringEquals(qvalue,instance.fieldValues[ffx]))
					throw new SException.InternalError(
							"Bad PKey " + qvalue.getClass() + " '" + qvalue 
							+ "' !equal() '" 
							+ instance.fieldValues[ffx].getClass() + "' " 
							+ instance.fieldValues[ffx]);
				// ## This is dubious.  What if they are the same except for trailing spaces?
				// This test will pass, but in general the records will not be considered the same
				// as we do not generally trim spaces.
				// See SRecordInstance.getString.
			instance.fieldValues[ffx] = qvalue;
			instance.readOnly = readOnly;
			if (readOnly && (instance.bitSets[ffx] & SCon.INS_VALID) == 0)
				// If it has previously been retrieved for update do not set ReadOnly now.
				instance.bitSets[ffx]  |= SCon.INS_READ_ONLY;
			else if (!readOnly)
				instance.bitSets[ffx]  &= ~SCon.INS_READ_ONLY;
			instance.bitSets[ffx]  |= SCon.INS_VALID;
		}
		
		/// Update instance flags
		instance.readOnly = readOnly;
		if (optimistic) instance.setOptimistic(false);
	}

	/** returns first.rightTrim.equals.rightTrim(second) */
	static private boolean trimStringEquals(Object firstObj, Object secondObj) {
		if (!(firstObj instanceof String))
			return firstObj.equals(secondObj);
		String first = (String)firstObj, second = (String)secondObj;
		if (second == null) return false;
		int fx = first.length()-1, sx = second.length()-1;
		boolean trimed=false;
		for (;fx>-1 && first.charAt(fx) == ' '; fx--) trimed=true;
		for (;sx>-1 && second.charAt(sx) == ' '; sx--) trimed=true;
		if (fx != sx) return false;
		if (!trimed) return first.equals(second); // Optimization
		for (; fx>-1; fx--)
			if (first.charAt(fx) != second.charAt(fx)) return false;
		return true;
	}
	
}
