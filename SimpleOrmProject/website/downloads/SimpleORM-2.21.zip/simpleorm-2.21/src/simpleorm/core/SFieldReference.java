package simpleorm.core;

import simpleorm.properties.*;
import java.sql.ResultSet;

/*
 * Copyright (c) 2002 Southern Cross Software Queensland (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/**
 Represents a foreign key reference from one record to another. It's
 initializer also normally generates the implicit foreign key fields.<p>
 
 For example, assume that <code>Employee</code> has a
 <code>DEPT_ID</code> field that refers to
 <code>Department.DEPT_ID</code>.  The <code>Employee</code> record
 would normally be declared as follows:-<p>
 
 <xmp>
 public class Employee extends SRecordInstance...
 static final SFieldMeta DEPARTMENT =
 new SFieldReference(meta, Department.meta);
 </xmp>
 
 Internally the <code>DEPARTMENT</code> <i>Reference</i> generates one
 or more <i>Foreign Key</i> fields that correspond to each key fields
 in <code>Department</code>.  In the example above, an implicit
 <code>Employee.DEPT_ID</code> field would be created.  Note that if
 the key defintion of <code>Department</code> changed then this would
 be automatically propogated to the <code>Employee</code> record.<p>
 
 It is also possible to declare the foreign key fields explicitly,
 which enables extra parameters such as column names to be explicitly
 specified.  For example:-<p>
 <xmp>
 public class Employee extends SRecordInstance...
 public static final SFieldMeta DEPT_ID =
 new SFieldString(meta, "DEPT_ID");
 static final SFieldMeta DEPARTMENT = new
 SFieldReference(meta, Department.meta,
 new SFieldMeta[]{DEPT_ID}, 0);
 </xmp>
 
 References are also allowed in primary keys of records, these are
 known as <i>Identifying</I> foreign keys.  This means that additional
 foreign keys would be added recursively.  See {@Link
 simpleorm.examples.BasicTests} for examples.<p>
 
 Explicitly storing the foreign key fields means that there
 is no need to have a <code>Department</code> record instance in order
 to retrieve an <code>Employee</code>.  Only if one calls
 <code>Employee.getDepartment</code> is the <code>Department</code>
 record created.  It also alows overlapping foreign keys to be
 supported later (where two References may share a column).<p>
 
 Fields are normally created in static initializers of class constants
 (although this is not necessary).  The java initialization rules
 generally work well to ensure that referenced records are initialized
 before referencing records.  However, it may occasionally be necessary
 to create references in a second pass, particularly if there are
 mutually recursive references.<p>
 
 To understand the underlying data structures you really need to look
 at the E-R diagram.<P>
 
 <img src="../../extraDocs/SOrmUML.png">
 
 E-Mail Extracts:-
 <font size=-1>
 
 First of all let me note that the problem that you are dealing with is the mapping what used to be called a conceptual model and the relational/logical model.  In the traditional "three schema model" generators work from conceptual through logical to physical models.<p>
 
 Since the advent of OO technology, the words have changed but the problems remain the same.  Generating the relational schema from the conceptual one used by SimpleORM is quite fiddly, and is the most complex code in SimpleORM.  Going the other way is, in general, much harder -- you are squeezing the toothpaste back into a tube, and not necessarily the same type of tube from whence it came.<p>
 
 However, in your quick start you do not have to solve all problems.  Just generate the easy, common cases.  Remember that the user can add foreign key definition in their subclass -- there is no reflection.  So please focus on the simple, consistent cases.<p>
 
 As Richard implies, it is a fundamental assumtion of SimpleORM that records only contain one Primary key, and that that all foreign keys use it.  No candidate keys considered.  This is pretty fundamental to the way SimpleORM works -- the cache is keyed by the primary key, only.<p>
 
 So that is why you only need to specify the referencing record, but may in general have to specify all the referencing fields.  This is why fields are *not* specified as
 SFieldReference(SRecordMeta meta, SFieldMeta[] localKeys, SFieldMeta[] foreignKeys)<p>
 which is a relational approach.
 
 SimpleORM assumes that foreign keys are generally defined in a consistent manner.  This produces succinct code.  I have not tried to make the processing of inconsistent names elegant because I assume (wrongly?) that it is rare. <p>
 </font>
 */

public class SFieldReference extends SFieldMeta {
	
	/** The direct foreign keys, may not all be scalars.  True inverse
	 of <code>SFieldMeta.sFieldReference</code>.  Not a flattened
	 structure like SRecordMeta.sFieldMetas.  You have to recur to
	 get all the scalar fields in a reference.*/
	SFieldMeta[] foreignKeyFields = null;
	
	
	/** The ultmatiley referenced record whose keys correspond to this
	 reference's foreign keys.  Ie. the end of the chain.  Not the
	 same as <code>foreignKeyFields[0].sRecordMeta</code> which is
	 just one level deep.  <code>SFieldMeta.referencedKeyField</code>
	 points to correpsonding reference in the
	 <code>foreignKeyFields[0].sRecordMeta</code> record.*/
	SRecordMeta referencedRecord = null;
	
	
	/** This is the string prepended to any foreign keys.  Eg. to
	 distinquish <code>ACTING_DEPT_ID</code> vs
	 <code>PERMANENT_DEPT_ID</code>. */
	String prefix = null;
	
	/** Creates a foreign key reference using <code>foreignKeys</code>
	 to reference <code>referenced</code>.  The <code>foreignKeys</code>
	 must match the top level primarky keys of <code>referenced</code>
	 exactly in order, type and number.  If the primaryKey includes
	 references, then just the reference should be included, not the
	 indirect foreign keys. <p>
	 
	 This raw initializer is only useful to add extra specifications to
	 the explicit definitions of the foreign key fields.  This is rare in
	 practice.<p> */
	public SFieldReference(
			SRecordMeta meta, SRecordMeta referenced, String fieldName,
			SFieldMeta[] foreignKeys, SPropertyValue [] pvals) {
		super(meta, (String)null, fieldName, pvals);
		//SLog.slog.debug("SFieldReference1 " + meta + referenced);
		setKeys(referenced, "", foreignKeys);
	}
	public SFieldReference(
			SRecordMeta meta, SRecordMeta referenced, SFieldMeta[] foreignKeys,
			SPropertyValue [] pvals) {
		this(meta, referenced, referenced.getString(SCon.SCOLUMN_NAME),
				foreignKeys, pvals);
	}
	
	
	/** Same as above, but used to reference intermediate foreign keys. */
	public SFieldReference(
			SRecordMeta meta, SFieldReference referenced, String fieldName,
			SFieldMeta[] foreignKeys, SPropertyValue [] pvals) {
		super(meta, (String)null, fieldName, pvals);
		//SLog.slog.debug("SFieldReference1 " + meta + referenced);
		setKeys(referenced, "", foreignKeys);
	}
	public SFieldReference(
			SRecordMeta meta, SFieldReference referenced,
			SFieldMeta[] foreignKeys, SPropertyValue [] pvals) {
		this(meta, referenced, referenced.getString(SCon.SCOLUMN_NAME),
				foreignKeys, pvals);
	}
	
	/**
	 * Get the field name to be passed to super-class constructor: if prefix specified,
	 * us it. Otherwise, use the table name of the referenced table
	 */
	private static String getFieldName( String prefix, SRecordMeta referenced )
	{
		if ( prefix == null || prefix.equals( "" ) )
		{
			return referenced.getString( SCon.STABLE_NAME );
		}
		else
		{
			return ptrim( prefix );
		}
	}
	
	/**
	 Creates a <code>SFieldReference</code> field to reference
	 <code>referenced</code>.  Then creates aditiaonal SFieldMetas that
	 correspond each column of the foreign key.  A foreign key may in
	 turn be a reference ("Identifying" foreign key) in which case
	 this process recurs.<p>
	 
	 Each created foreign key column has the same name and type as
	 the one in the referenced table but the names can be prefixed by
	 <code>prefix</code> which is handy if for example, an Employee
	 had a Managing_Department and a Billing_Department.*/
	public SFieldReference(
			SRecordMeta meta, SRecordMeta referenced,
			String prefix, SPropertyValue [] pvals) {
		super(meta, (String)null,
				getFieldName( prefix, referenced ),
				pvals);
		//SLog.slog.debug("SFieldReference2 " + meta + referenced);
		makeForeignKeys(meta, referenced, prefix, pvals);
		
		// #### The handling of properties between references and copies
		// needs much more thought!  In particular NOT NULL vs PRIMARY
		// KEY!  This was always a latent bug.
		
	}
	/** Remove final "_" of prefix. */
	private static String ptrim(String prefix) {
		int x = prefix.lastIndexOf("_");
		if (x == prefix.length()-1 && prefix.length() != 0)
			return prefix.substring(0, x);
		else
			return prefix;
	}
	
	
	public SFieldReference(
			SRecordMeta meta, SRecordMeta referenced,
			String prefix, SPropertyValue pval1) {
		this(meta, referenced, prefix, new SPropertyValue [] {pval1});
	}
	
	public SFieldReference(
			SRecordMeta meta, SRecordMeta referenced,
			String prefix, SPropertyValue pval1, SPropertyValue pval2) {
		this(meta, referenced, prefix, new SPropertyValue [] {pval1, pval2});
	}
	
	public SFieldReference(
			SRecordMeta meta, SRecordMeta referenced,
			String prefix) {
		this(meta, referenced, prefix, new SPropertyValue [0]);
	}
	
	/** <code>prefix</code> defaults to "", the common case. */
	public SFieldReference(
			SRecordMeta meta, SRecordMeta referenced) {
		this(meta, referenced, (String)null);
	}
	
	/** For identifying foreign keys. */
	public SFieldReference(
			SRecordMeta meta, SFieldReference referenced,
			String prefix, SPropertyValue [] pvals) {
		super(meta, (String)null,
				getFieldName( prefix, referenced.referencedRecord ),
				pvals);
		//SLog.slog.debug("SFieldReference4 " + meta + referenced + prefix);
		makeForeignKeys(meta, referenced, prefix, pvals);
	}
	
	/** Create the foreign keys in <code>rmeta</code> that correspond to
	 the primary keys in <code>referenced</code>.  If
	 <code>referenced</code> is SRecordMeta then top level, else if
	 SFieldReference then indirect identifying foreign key. */
	private void makeForeignKeys(
			SRecordMeta rmeta, SRecordMeta referenced,
			String prefix, SPropertyValue [] pvals) {
		
		if (isPrimaryKey && rmeta == referenced)
			throw new SException.Error(
					"Identifying Foreign Key " + this + " Cannot recursively reference " + referenced);
		
		//SLog.slog.debug("MakeForeignKeys1 " + this + rmeta + referenced);
		SArrayList refedKeys = referenced.keySFieldMetas;
		SArrayList madeFKeys = new SArrayList(refedKeys.size());
		
		for (int kx=0; kx<refedKeys.size(); kx++) {
			SFieldMeta key = (SFieldMeta)refedKeys.get(kx);
			if (key.sFieldReference == null) {
				/// A non foreignKey key, create corresponding foreign key.
				SFieldMeta fkey = key.makeForeignKey( //ie Recur
						rmeta, prefix, pvals);
				madeFKeys.add(fkey);
			}
		}
		SFieldMeta foreignKeys[]
				       = (SFieldMeta[])madeFKeys.toArray(new SFieldMeta[0]);
		setKeys(referenced, prefix, foreignKeys);
	}
	
	private void makeForeignKeys(
			SRecordMeta rmeta, SFieldReference referenced,
			String prefix, SPropertyValue [] pvals) {
		
		//SLog.slog.debug("MakeForeignKeys2 " + this + rmeta + referenced);
		SFieldMeta[]  refedKeys = referenced.foreignKeyFields;
		SFieldMeta foreignKeys[] = new SFieldMeta[refedKeys.length];
		
		for (int kx=0; kx<refedKeys.length; kx++) {
			SFieldMeta key = (SFieldMeta)refedKeys[kx];
			SFieldMeta fkey = key.makeForeignKey( //ie Recur
					rmeta, prefix, pvals);
			foreignKeys[kx] = fkey;
		}
		setKeys(referenced, prefix, foreignKeys);
	}
	
	/** Abstract specializer.  Clone this key field to be a foreign key
	 to <code>rmeta</code> of the same type as this.*/
	SFieldMeta makeForeignKey(
			SRecordMeta rmeta,  String prefix, SPropertyValue [] pvals) {
		return new SFieldReference(rmeta, this, prefix, pvals );
	}
	/** this record uses (existing) foreignKeys to reference referenced
	 record.  This method wires that up, setting
	 <code>sFieldReference</code> and
	 <code>referencedKeyFields</code>.  It does not create any new
	 fields.<p>
	 
	 Separated from <code>makeForeignKeys()</code> to allow an
	 explicit list of keys.<p>
	 
	 This one is for the top level.*/
	private void setKeys(
			SRecordMeta referenced, String prefix,
			SFieldMeta[] foreignKeys){
		
		this.referencedRecord = referenced;
		this.prefix = prefix==null?"":prefix;
		
		/// Run through both referenced.keys and foreign keys.
		int fx=-1;
		for (int kx=0; kx<referenced.keySFieldMetas.size(); kx++) {
			SFieldMeta kf = (SFieldMeta)referenced.keySFieldMetas.get(kx);
			if (kf.sFieldReference == null) {
				/// A non foreignKey key, create corresponding foreign key.
				fx++;
				SFieldMeta fkey = foreignKeys[fx];
				if (fkey.sFieldReference != null)
					throw new SException.Error(
							"Overlapping foreign keys not yet supported: "
							+ fkey + " already is a foreign key of "
							+ fkey.sFieldReference);
				if (!kf.getClass().isInstance(fkey))
					throw new SException.Error(
							"Foreign key " + fkey + " not same type as key " + kf);
				if (this.isPrimaryKey != fkey.isPrimaryKey)
					throw new SException.Error(
							"Inconsistent Primary Key flags " + this + " vs " + fkey);
				// (Can happen for manually declared foreign keys)
				fkey.sFieldReference = this;
				fkey.referencedKeyField = kf;
			}
		}
		this.foreignKeyFields = foreignKeys;
		if (foreignKeys.length != fx+1 || fx == -1)
			throw new SException.Error(
					"Wrong number of non-foregn keys " + (fx+1));
	}
	
	/** For intermediate foreign keys, link up to the referenced <em>Field</em>'s fields.
	 */
	private void setKeys(
			SFieldReference referenced, String prefix,
			SFieldMeta[] foreignKeys){
		
		this.referencedRecord = referenced.referencedRecord;
		this.prefix = prefix==null?"":prefix;
		
		/// Run through both referenced.keys and foreign keys.
		SFieldMeta[] refedKeys = referenced.foreignKeyFields;
		for (int kx=0; kx<refedKeys.length; kx++) {
			SFieldMeta kf = refedKeys[kx];
			/// A non foreignKey key, create corresponding foreign key.
			SFieldMeta fkey = foreignKeys[kx];
			if (fkey.sFieldReference != null)
				throw new SException.Error(
						"Overlapping foreign keys not yet supported: "
						+ fkey + " already is a foreign key of "
						+ fkey.sFieldReference);
			if (!kf.getClass().isInstance(fkey))
				throw new SException.Error(
						"Foreign key " + fkey + " not instance of key " + kf);
			fkey.sFieldReference = this;
			fkey.referencedKeyField = kf;
		}
		this.foreignKeyFields = foreignKeys;
	}
	
	public String createColumnSQL(){throw new SException.Error();}
	
	/** This reference is updatable iff all its ground foreign keys are
	 updatable, recursively. */
	void checkUpdatable(SRecordInstance instance) {
		for (int fx=0; fx<foreignKeyFields.length; fx++) {
			foreignKeyFields[fx].checkUpdatable(instance);
		}
	}
	
	/** Specializes SFieldMeta.getRawFieldValue, which is called by
	 getFieldValue, thence SRecoredInstance.getObject...  <p>
	 
	 Normally, if the field is null but all the primary key fields
	 are non null then does a <code>findOrCreate()</code> to provide
	 a referenced record.  SQY_REFERENCE_NO_QUERY suppresses this
	 query.  getReferencedWhileDetached may be called for detached
	 records.
	 */
	Object getRawFieldValue(SRecordInstance instance, long sqy_flags){
		SRecordInstance result
		= (SRecordInstance)instance.fieldValues[fieldIndex];
		//SLog.slog.debug("getRawFieldValue" + this + instance + result);
		if (result != null && 
				(!result.isValid() 
						|| (instance.isAttached() && !result.isAttached())) ) { // #Bartek
			// ie. Was not detatched.
			// ## Really should not serialize these in the first place.
			result = null;
		}
		if (result == null) {
			// references. Putting detached check AFTER check for null reference
			Object [] keys = new Object[foreignKeyFields.length];
			for (int fkx=0; fkx<foreignKeyFields.length; fkx++) {
				Object fkValue = foreignKeyFields[fkx].getRawFieldValue(instance, sqy_flags);
				// ### no IS_VALID test
				// May recur, and so findOrCreate
				if (fkValue == null) return null;
				keys[fkx] = fkValue;
			}
			
			if (SUte.inBitSet(sqy_flags, SCon.SQY_REFERENCE_NO_QUERY, SCon.SQY_))
				return Boolean.FALSE;
			
			if (instance.isAttached())
			{
				result = referencedRecord.findOrCreate(keys, sqy_flags);
			}
			else    // detached... make 'last-ditch' effort to fetch
			{
				result = instance.getReferenceWhileDetached( this, keys );
				if ( result == null )
				{
					throw new SException.Error("Cannot get " + this +" in Unattached " + instance.toStringDefault() );
				}
			}
			
			instance.fieldValues[fieldIndex] = result; // For next time.
		}
		return result;
	}
	
	/** Sets the instance reference to value.  Then recursively copies
	 all of the foreign keys.  <code>this</code> must be a top level
	 foreign key.  (value could be null.)*/
	void rawSetFieldValue(SRecordInstance instance, Object value){
		setRawFieldValueRecur(instance,
				(SRecordInstance)value, (SRecordInstance)value);
	}
	
	/** Actually sets the instance reference to value recursively.
	 <code>directRefed</code> is the instance that is directly
	 referenced from the top level call to
	 <code>setRawFieldValue</code>.  It is from this record that
	 values are copied, not from the indirectly referenced records.*/
	private void setRawFieldValueRecur(
			SRecordInstance instance, SRecordInstance directRefed, SRecordInstance value){
		if (SLog.slog.enableFields())
			SLog.slog.fields(">RSet " + instance + "." + this
					+ " = " + directRefed + "." + value);
		if (directRefed != null && directRefed.fieldValues == null)
			throw new SException.Error(
					"Cannot set " + instance + "." + this + " to Destroyed " + directRefed);
		/// Check for bad update orders.
		if (value != null) {
			SRecordInstance refedr = (SRecordInstance)value;
			if (refedr.isNewRow()) {
				if (!refedr.isDirty()
						|| (refedr.updateListIndex > instance.updateListIndex && instance.isDirty()))
					throw new SException.Error(
							"Attempt to set " + instance + "." + this + " to new row " + refedr
							+ " with incorrect update order will produce foreign key violations.");
			}
			if (refedr.isDeleted())
				throw new SException.Error(
						"Attempt to set " + instance + "." + this + " to deleted row " + refedr);
		}
		
		//SLog.slog.debug("SRFRecurSetting " + instance + "." + instance.allFields() + "[" + fieldIndex + "] := " + value);
		
		// Set the actual record on instance
		// however, DO NOT set it if instance is attached, and value is detached.
		// In this latter case, only the keys will be set below
		//
		// ##Bartek. I think this is now redundant given getRawFieldValue suppresses
		// references to detached records.
		boolean detachedToAttached = ( instance.isAttached() && value != null && !value.isAttached() );
		instance.fieldValues[fieldIndex] = detachedToAttached ? null : value;
		instance.bitSets[fieldIndex] |= (byte) (SCon.INS_DIRTY | SCon.INS_VALID);
		
		/// Recur through foreign keys
		for (int fx=0; fx<foreignKeyFields.length; fx++) {
			SFieldMeta fkey = foreignKeyFields[fx];
			SFieldMeta refed = fkey.referencedKeyField;
			//SLog.slog.debug("SRFRecur #" + fx + fkey + refed + directRefed); // DR == null
			Object newValue =
				// value==null?null:directRefed.fieldValues[refed.fieldIndex]; // !!! Old
				directRefed == null ? null : directRefed.fieldValues[refed.fieldIndex]; // Corrected?
			
			// Issue is that if we deliberately set the value to null (Basic
			// Tests) there is no looked up value, get directRefed == null.
			// But in IdentFKeys we only retrieve the Payslip, not the
			// Employee rec, and so Empee ref is null although Empee Nr is
			// not.
			
			// Maybe should use getRawFieldValue?
			//SLog.slog.debug("SRFRecur " + fx + fkey + refed  + "[" + refed.fieldIndex + "] :=" + newValue);
			if (fkey instanceof SFieldReference)
				((SFieldReference)fkey).setRawFieldValueRecur(instance, directRefed, (SRecordInstance)newValue);
			else
				fkey.rawSetFieldValue(instance, newValue);
			// ## Not OK if overlapping fkeys.
		}
		//SLog.slog.debug("<");
	}
	
	/** Returns the field definition of the <code>index</code>th foreign
	 key for this reference.  The first one is 0.  This can then be used
	 as a parameter to subsequent get*() methods.  <p>
	 
	 The main use of this function is to access the foreing key values of
	 references without having to actually query the database.  <p>
	 
	 (Note that
	 this purpose will become obsolete once the lazy
	 <code>findOrCreate</code> is implemented because just referencing
	 the key value of the referenced object will not trigger the
	 query.) */
	public SFieldMeta foreignKeyField(int index) {
		return foreignKeyFields[index];
	}
	
	/** Number of foreign key fields for this reference. */
	public int foreignKeyFieldsSize() { return foreignKeyFields.length;}
	
	/**
	 * Get the SRecordMeta to which this reference points to.
	 * Will not attempt to retrieve the record from the database,
	 * will return null if not in memory.
	 */
	public SRecordMeta getReferencedRecord()
	{
		return this.referencedRecord;
	}
	
	public String toString() {
		/// Make prety referenceName
		return "[FR " + (sRecordMeta!=null?SUte.cleanClass(sRecordMeta.userClass):"NULL") + "."
		+ prefix + "_" + (referencedRecord!=null?SUte.cleanClass(referencedRecord.userClass):"NULL") + "]";
	}
	public String toLongerString() {
		StringBuffer res = new StringBuffer(
				"[FRL " + super.toLongerString()
				+ " RefedRec " + referencedRecord + " FKeyFlds ");
		res.append(SUte.arrayToString(foreignKeyFields));
		res.append("]");
		return res.toString();
	}
	
	
	Object queryFieldValue(ResultSet rs, int sqlIndex) {
		throw new SException.InternalError("Attempt to query " + this);
	}
	
	Object convertToField(Object raw) throws Exception {
		Class refed = referencedRecord.userClass;
		if (raw != null && !refed.isInstance(raw))
			throw new SException.Error(
					"Object " + raw + " not a " + refed.getName());
		return raw;
	}
	
	/** Specializes SFieldMeta. */
	String defaultDataType(){
		throw new SException.InternalError("SFieldReference has no datatype.");}
}
