package simpleorm.core;

/** This contains Oracle specific code. 
 * 
 * In oracle VARCHAR2 '' == null.  Ie. min string length is 2.
 * VARCHAR == VARCHAR2? but not recommended?
 * VARCHARs max size 2000 or 4000 Oracle 8.
 * CHARS max size 2000 all versions.
 * LONG for larger strings.
 * 
 * Dates DATE, TIMESTAMP [WITH TIMEZONE].  
 * 
 * It is reported that CHARs need to be trimed for comparison?
 * */

public class SDriverOracle extends SDriver {

  protected  String driverName() {return "Oracle JDBC driver";}

  public int maxIdentNameLength(){return 30;} // Correct for Oracle.

  /** Specializes SDriver.generateKeySequence using Oracle SEQUENCEs. */
  protected long generateKeySequence(SRecordMeta rec, SFieldMeta keyFld) {
    Object sequenceName = keyFld.getProperty(SSEQUENCE_NAME);

    String qry = "SELECT " + (String)sequenceName + ".NEXTVAL FROM DUAL";
    Object next = SConnection.rawQueryJDBC(qry);

    return SJSharp.object2Long(next);
  }
  public boolean supportsKeySequences(){return true;}
  protected String createSequenceDDL(String name) {
    return "CREATE SEQUENCE " + name;
  }
  protected String dropSequenceDDL(String name) {
    return"DROP SEQUENCE " + name;
  }

  /**
   *   
   */
 protected String columnTypeSQL(SFieldMeta field) {
 	String dataType = (String)field.getProperty(SDATA_TYPE);
  if ( dataType.equals("BYTES"))
    return "RAW"; // Ie. just a byte array.  Use SFieldBlob for BLOB.
// 	if (dataType.equals("INTEGER"))
// 		return "numeric(9,0)";
//    else if ( dataType.equals("TIMESTAMP") )
//      return "DATE"; // Is this correct ##
    else if ( dataType.equals("TIME") )
      return "TIMESTAMP"; 
    else if ( dataType.equals("VARCHAR")  )
    	return "VARCHAR2(" + field.getProperty(SBYTE_SIZE) + ")";
    else  
      return super.columnTypeSQL(field);
  }


}
