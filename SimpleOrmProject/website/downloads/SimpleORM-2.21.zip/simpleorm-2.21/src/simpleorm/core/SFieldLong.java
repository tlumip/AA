package simpleorm.core;
import simpleorm.properties.*;
import java.sql.ResultSet;

/** Represents Long field meta data.  Default SQL type is
    NUMERIC(18,0), which is roughly sql-92.*/

public class SFieldLong extends SFieldScalar {
  public SFieldLong(SRecordMeta meta, String columnName, 
    SPropertyValue [] pvals) {
    super(meta, columnName, pvals);
  }
  public SFieldLong(SRecordMeta meta, String columnName) {
    this(meta, columnName, new SPropertyValue[0]);
  }
  public SFieldLong(SRecordMeta meta, String columnName,
     SPropertyValue pval) {
    this(meta, columnName, new SPropertyValue[]{pval});
  }
  public SFieldLong(SRecordMeta meta, String columnName,
     SPropertyValue pval1, SPropertyValue pval2) {
    this(meta, columnName, new SPropertyValue[]{pval1, pval2});
  }

  /** Abstract specializer.  Clone this key field to be a foreign key
      to <code>rmeta</code> of the same type.*/
  SFieldMeta makeForeignKey(
    SRecordMeta rmeta, String prefix, SPropertyValue [] pvals) {
    return new SFieldLong(rmeta, 
      (prefix==null?"":prefix)+getString(SCon.SCOLUMN_NAME), 
      pvals);
  }

  Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception {
    long res = rs.getLong(sqlIndex);
    if (rs.wasNull()) // ie. last operation!
      return null;
    else 
      return SJSharp.newLong(res);
  }

  Object convertToField(Object raw)  throws Exception {
    if (SJSharp.isLong(raw)) return raw;
    if (raw == null) return null;
    if (raw instanceof Number) 
      return SJSharp.newLong((Number)raw);
    if (raw instanceof String) {
      return SJSharp.newLong((String)raw);
    }
    throw new SException.Data("Cannot convert " + raw + " to Long.");
  }

  /** Specializes SFieldMeta.  This is basically SQL 2, and fairly
      database independent, we hope.  Note that "LONG" for Oracle
      means a text field that can contain over 2K characters!  */
  String defaultDataType(){return "NUMERIC(18,0)";}

}
