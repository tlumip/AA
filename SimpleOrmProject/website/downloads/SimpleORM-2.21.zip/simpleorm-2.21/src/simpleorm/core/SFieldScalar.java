package simpleorm.core;
import simpleorm.properties.*;

/** Scalar fields such as String, Int, but not Reference.*/

public abstract class SFieldScalar extends SFieldMeta {
  public SFieldScalar(
    SRecordMeta sRecord, String columnName, SPropertyValue [] pvals) {
    super(sRecord, columnName, pvals);
  }
}
