package simpleorm.core;

/** This contains MS SQL Server specific code.
 * 
 * CHAR, VARCHAR max 8,000.  TEXT 2^31.  NVARCHAR/NCHAR UTF16, max size 4,000.
 */

public class SDriverMSSQL extends SDriver {
	
	protected String driverName() {return "SQLServer";}
	
	
	
	/* paging
	 selectSQL(...) { 
	 * 0 = SQL string
	 * 1 = Page int -> LastUnwantedRecord
	 * 2 = RecsPerPage int
	 * 3 = unique column
	 * 4 = Sort
	 Select TOP @RecsPerPage * FROM (@SQL) T WHERE T.@ID NOT IN 
	 (select TOP ((@RecsPerPage*(@Page-1)) @ID FROM (@SQL) T9 ORDER BY @Sort) order by @Sort
	 
	 Params : String pageid, int pageindex, int recsperpage ) 
	 * /
	 // for now we can only page if there is only one primary key
	  SFieldMeta sfmKey = null;
	  int iPKeyCount = 0;
	  for (int i = 0; i < from.keySFieldMetas.size(); i++) 
	  {
	  sfmKey = (SFieldMeta)from.keySFieldMetas.get(i);
	  if (sfmKey.sFieldReference == null)
	  iPKeyCount++;
	  }
	  if (iPKeyCount != 1)
	  throw new SException.Error("Cannot page a query that has multiple primary keys (for now) " + this);
	  
	  String strSQL = "SELECT TOP {2,number,integer} * FROM ({0}) T WHERE T.{3} NOT IN "
	  + "(select TOP {1,number,integer} {3} FROM ({0}) T9 {4}) {4}";
	  Object[] args = {
	  ret.ToString(),
	  sps.getOffset();
	  sps.getLimit();
	  
	  new Long(recsperpage * (pageindex - 1)),
	  new Long(recsperpage),
	  sfmKey.getString(sfmKey.SCOLUMN_NAME),
	  " ORDER BY " + (orderBy != null ? orderBy : sfmKey.getString(sfmKey.SCOLUMN_NAME))
	  };
	  return java.text.MessageFormat.format(strSQL,args);
	  / * paging */
	
	
	
	/** Apparantly need DATETIME instead of TIMESTAMP */
	protected String columnTypeSQL(SFieldMeta field) {
		
		if ( ( (String) field.getProperty(SDATA_TYPE)).equals("TIMESTAMP"))
			return "DATETIME";
		else if ( ( (String) field.getProperty(SDATA_TYPE)).equals("DATE"))
			return "DATETIME";
		else if ( ( (String) field.getProperty(SDATA_TYPE)).equals("TIME"))
			return "DATETIME";
		else if ( ( (String) field.getProperty(SDATA_TYPE)).equals("NUMERIC(18,0)"))
			return "BIGINT";
		else if ( ( (String) field.getProperty(SDATA_TYPE)).equals("BYTES"))
			return "IMAGE"; // Ie. just a byte array.
		else
			return super.columnTypeSQL(field);
		
	}
	
	
	protected String forUpdateSQL(boolean forUpdate)
	{
		return "";
	}
	
	/** XLOCK is not strictly necessary in MS SQL because it does not
	 provide Oracle-like data versioning.<p>
	 
	 But having XLOCK should reduce deadlocks.  More importantly,
	 2005 is supposed to be providing data versioning
	 ("Snapshots").<p>
	 
	 However, Jorge says that it is unnecessary and makes SimpleORM
	 fail, but it works for me.
	 
	 @see SDriver#forUpdateSQL for discussion.
	 
	 */
	protected String postFromSQL(boolean forUpdate, boolean unrepeatableRead)
	{
		if (unrepeatableRead) return " WITH (NOLOCK)";
		else if (forUpdate && xLockEnabled) return " WITH (XLOCK)";
		return "";
	}
	boolean xLockEnabled = false;
	/** Enables WITH (XLOCK) for updatable queries.  
	 * Should reduce deadlocks but apparantly can cause bugs.
	 * (Not supported in SQL 7?  Something about HOLDLOCK?)
	 */
	public void setXLockEnabled(boolean xlock) {xLockEnabled = xlock;}
	public boolean getXLockEnabled() {return xLockEnabled;}
	
	
	public String alterTableAddColumnSQL( SFieldMeta field )
	{
		StringBuffer sql = new StringBuffer();
		
		sql.append( "\nALTER TABLE " );
		sql.append( field.sRecordMeta.getString(STABLE_NAME) );
		sql.append( " ADD " );
		sql.append( wholeColumnSQL( field ) );
		sql.append(clauseSeparator("    "));
		
		return sql.toString();
	}
	
	
	// ### We need a key generator here!
}

