package simpleorm.core;
import simpleorm.properties.*;

import java.util.HashMap;
import java.sql.ResultSet;
import java.io.*;
import java.sql.*;
/*
 * Copyright (c) 2002 Southern Cross Software Queensland (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/** Each instance defines the meta data for a field in an {@link
 SRecordMeta}.  Subclasses are used for specific data types, with
 {@link SFieldObject} being the most generic.  Like JDBC, type
 conversions are made automatically.<p>
 
 Internally, the types are stored accurately.  Ie. the
 <code>SRecordInstance.fieldValues</code> objects are the exact
 types as declared (String, Integer, Employee etc.)  However,
 generous automatic conversions are performed both when accessing
 these from the application and when getting and setting columns in
 the database.<p>
 
 See SSimpleORMProperties for a descripiton of how properties are
 used with fields.<p>*/

public abstract class SFieldMeta extends SPropertyMap implements Serializable {
	/** The record that this field belongs to. */
	SRecordMeta sRecordMeta;
	
	/** The indext into SRecordMeta.fields. */
	int fieldIndex;
	
	/** Is part of a primary key, may also be a foreign key.  ### Propertyize.*/
	transient boolean isPrimaryKey = false;
	
	/** Can only be read, not set. Mainly SCOLUMN_NAME */
	transient boolean isReadOnly = false;
	
	/** Not null means this field is a foreign key member of the
	 SFieldReference.  Overlapping foreign keys are not supported so
	 this is a scalar.  (The semantics of setField are vague
	 Overlapping keys.)  Strict inverse of
	 <code>SFieldReference.foreignKeyFields</code>.*/
	transient SFieldReference sFieldReference = null;
	
	/** If sFieldRefrence != null, then this refers to the corresponding
	 key field in the referenced table. */
	transient SFieldMeta referencedKeyField = null;
	
	/** The last key value generated for this
	 <code>SGENERATED_KEY</code> field in this JVM.  Used by the
	 default driver as a hack to minimize collisions with the SELECT
	 MAX method.  Synchronize all access.*/
	transient private long lastGeneratedKeyValue = 0;
	
	/** Creates a new field for <code>sRecord</code> corresponding to
	 <code>columnName</code>.  <code>pvalues</code> are an arbitrary
	 list of properties that can be associated with this
	 field. <code>fieldName</code> is only used for the fieldMap and
	 defaults to the <code>columnName</code> or prefix for
	 references. */
	SFieldMeta(SRecordMeta sRecord, String columnName, String fieldName,
			SPropertyValue [] pvalues) {
		//SLog.slog.debug("  SFieldMeta " + sRecord + columnName);
		this.sRecordMeta = sRecord;
		
		setPropertyValues(pvalues);
		String colName = (String)putDefaultProperty(SCon.SCOLUMN_NAME, columnName);
		String fldName = (String)putDefaultProperty(SCon.SFIELD_NAME, fieldName);
		
		/// Check no duplicate column names, can happen for references.
		for (int mx=0; mx<sRecord.sFieldMetas.size(); mx++) {
			SFieldMeta fm = (SFieldMeta)sRecord.sFieldMetas.get(mx);
			String xcol = fm.getString(SCon.SCOLUMN_NAME);
			if (xcol != null && xcol.equals(colName))
				throw new SException.Error("Duplicate Column Name " + colName);
		}
		
		/// Set up new record.
		sRecordMeta.sFieldMetas.add(this);
		fieldIndex = sRecordMeta.sFieldMetas.size() - 1;
		sRecordMeta.sFieldNames.add(fldName);
		sRecordMeta.fieldMap.put(fldName, this);
		if (getBoolean(SCon.SPRIMARY_KEY)) {
			isPrimaryKey = true;
			sRecordMeta.keySFieldMetas.add(this);
		}
		if (getProperty(SCon.SCOLUMN_QUERY) != null)
			isReadOnly = true;
		if (sRecordMeta.keySFieldMetas.size() == 0)
			throw new SException.Error(
					"No Primary Key declared for " + sRecordMeta + " (Must be first fields)");
		// Important for Employee.Manager refs Employee
	}
	
	/** Common case for all fields but References. */
	SFieldMeta(SRecordMeta sRecord, String columnName,
			SPropertyValue [] pvalues) {
		this(sRecord, columnName, columnName, pvalues);
	}
	
	/** Clone this key field to be a foreign key to <code>rmeta</code>
	 of the same type.*/
	abstract SFieldMeta makeForeignKey(
			SRecordMeta rmeta, String prefix, SPropertyValue [] pvals);
	
	/** Return default SDATA_TYPE property. */
	abstract String defaultDataType();
	
	/** Dispatched from SRecordInstance.getObject(), this is specialized
	 for references etc. */
	Object getFieldValue(SRecordInstance instance, long sqy_flags) {
		if (!instance.isValid())
			throw new SException.Error(
					"Cannot access destroyed record " + instance);
		if (instance.deleted)
			throw new SException.Error(
					"Attempt to access Deleted record " + instance);
		if (sRecordMeta != instance.getMeta()) // ie. identical
			throw new SException.Error(
					"Field " + this + " is not in " + instance.getMeta());
		// Maybe trigger lazy read of object later.
		
		if ((instance.bitSets[fieldIndex] & SCon.INS_VALID) == 0
				&& !(this instanceof SFieldReference) )
			throw new SException.Error(
					"Cannot access unqueried field " + this + " in " + instance);
		Object res = getRawFieldValue(instance, sqy_flags);
		if (SLog.slog.enableFields())
			SLog.slog.fields("Got " + instance.toStringDefault() + "." + this + " == " + res);
		return res;
	}
	/** Specialized in SFieldReference */
	Object getRawFieldValue(SRecordInstance instance, long sqy_flags) {
		return instance.fieldValues[fieldIndex];
	}
	
	/** Does generic checks before calling field type specific handler.
	 See SRecordInstance.setObject for a description fo the full
	 flow.<p>
	 
	 The internal flow is:-
	 <xmp>
	 SRecordInstance.setString(field, value)
	 SRecordInstance.setObject(field, value)
	 SFieldMeta.setFieldValue(this)
	 - Generic validation incl. Not primary key.
	 - Check if changed.
	 SField*.convertToField(value)
	 SFieldMeta|Reference.setRawFieldValue(instance, value)
	 </xmp> 
	 
	 * Note that setRawFieldValue is also called directly for keys etc. 
	 * 
	 **/
	
	void setFieldValue(SRecordInstance instance, Object rawValue) {
		
		// ### INS_VALID & UPDATABLE tests are missing?
		
		/// Check instance valid for setting this field.
		if (instance.fieldValues == null)
			throw new SException.Error(
					"Cannot access destroyed record " + instance);
		if (instance.deleted)
			throw new SException.Error(
					"Cannot access deleted record " + instance);
		if (sRecordMeta != instance.getMeta()) // ie. identical
			throw new SException.Error(
					"Field " + this + " is not in " + instance.getMeta());
		if (isPrimaryKey && instance.isAttached() ) // See SRecordMeta createDetached.
			throw new SException.Error(
					"Cannot change primary key field " + this + " in " + instance);
		if (sFieldReference != null)
			throw new SException.Error(
					"Cannot directly update foreign key  " + this + " in " + instance
					+ ". Update " + sFieldReference + " instead.");
		// If users could directly update the foreign keys they could
		// make the relationship between foreign keys and the references
		// inconsistent.  When findOrCreate becomes truely lazy, the
		// overheads in creating the referenced object will be
		// negligible.  However, this may change if overlapping foreign
		// keys are implemented.
		
		
		checkUpdatable(instance);
		
		/// Convert rawValue if necessary.
		Object convValue = null;
		try {
			convValue = convertToField(rawValue);
		} catch (Exception ex) {
			throw new SException.Data(
					"Converting " + rawValue + " for " + instance + "." + this, ex);
		}
		
		/// Now do any user validations.
		instance.validateField(this, convValue);
		
		/// Set the field value if different.
		Object fvalue = instance.fieldValues[fieldIndex];
		if ((instance.bitSets[fieldIndex] & SCon.INS_VALID) == 0
				|| (convValue == null && fvalue != null)
				|| (convValue != null &&
						(fvalue == null || !convValue.equals(fvalue))) ) {
			rawSetFieldValue(instance, convValue);
			instance.setDirty();
		}
	}
	/** Specialized for SReferences.*/
	void checkUpdatable(SRecordInstance instance) {
		if ((instance.bitSets[fieldIndex] & SCon.INS_READ_ONLY) != 0)
			throw new SException.Error("Not queried for updating " + this +
					" in " + instance);
	}
	/** Specialized for References.  Called from 1. setFieldValue(),
	 which sets the record dirty, 2. setPrimaryKey() for which we do
	 not want the record marked dirty,
	 3. SFieldReference.rawSetFieldValue() (recursively) in which
	 case setFieldValue() should have already marked the record
	 dirty. */
	void rawSetFieldValue(SRecordInstance instance, Object value) {
		if (SLog.slog.enableFields())
			SLog.slog.fields("Set " + instance + "." + this + " = " + value);
		if (isReadOnly)
			throw new SException.Error(
					"Attempt to set read only field " + instance + "." + this + " to " + value);
		instance.fieldValues[fieldIndex] = value;
		instance.bitSets[fieldIndex] |= (byte)(SCon.INS_DIRTY | SCon.INS_VALID);
	}
	
	/** Issues a JDBC get*() on the result set for the field and converts the database type
	 to the appropriate internal type, eg, Double for a double field. The first
	 column has sqlIndex==1. */
	abstract Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception;
	
	/** Converts the parameter from the users type to the correct internal Object type for this
	 field.  Returns the object if no conversion necessary.  Used by
	 <code>SRecordInstance.setObject</code> etc.*/
	abstract Object convertToField(Object raw) throws Exception;
	
	
	/**
	 * Places a value in a prepared statement in the database representation
	 * used during SRecordInstance.flush.  
	 * Can convert between internal values and database values, eg. TRUE to "Y".
	 * 
	 * (This does NOT need to handle NULL values (those are handled seperately by SRecordInstance))
	 */
	void writeFieldValue(PreparedStatement ps, int sqlIndex, Object value)
	{
		try {
			ps.setObject(sqlIndex, writeFieldValue(value));
		} catch (Exception ex) {throw new SException.JDBC(ex);}
	}
	
	/**
	 * Converts a single value from internal representation to database representation.
	 * Used primarily by the writeFieldValue above, but also used for converting optimistic lock
	 * values in SRecordInstance.flush.<p>
	 * 
	 * Overidden by SFieldBoolean.  (not by SFieldString). 
	 *
	 * NOTE: This does NOT need to handle NULL values (those are handled seperately by SRecordInstance)
	 */
	Object writeFieldValue(Object value)
	{
		return value;
	}
	
	/** Lists the record and column name only.  Useful in traces. */
	public String toString() {
		return "[F " + SUte.cleanClass(sRecordMeta.userClass)
		+ "." + getString(SCon.SCOLUMN_NAME) + "]";
	}
	/** Lists all the details of the field. */
	public String toLongerString() {
		return "[" + this
		+ (isPrimaryKey?" PKey":"")
		+ (sFieldReference != null?(
				" sFldRef " + sFieldReference + " RefedKey " + referencedKeyField):"")
				+ "]";
	}
	
	/**
	 * Accessor to get the SRecordMeta of this field
	 */
	public SRecordMeta getSRecordMeta()
	{
		return sRecordMeta;
	}
	
	/*
	 public Object validate(Object newValue) throws SValidationException{}
	 // Framework.
	  */
	
	/**
	 This is used to fudge version numbers in databases that do not
	 properly suport them.  It is rough and fails if there are
	 multiple JVMs, or the user switches schemas in Oracle etc.  (I
	 had used it as a backup of Oracle etc.  but that was not a good
	 idea.)
	 */
	synchronized long nextGeneratedValue(long minimum) {
		if (lastGeneratedKeyValue < minimum)
			lastGeneratedKeyValue = minimum;
		else
			++lastGeneratedKeyValue;
		return lastGeneratedKeyValue;
	}
	
	
	/**
	 * Same purpose as corresponding method on SRecordMeta.
	 * <p>This method is implemented to return the pre-existing SFieldMeta object
	 */
	protected Object readResolve()
	throws ObjectStreamException
	{
		Object substituted = sRecordMeta.sFieldMetas.get( fieldIndex );
		return substituted;
	}
}
