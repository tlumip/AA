package simpleorm.core;

import simpleorm.properties.*;
import java.sql.ResultSet;

/** Represents Timestamp field meta data. */

public class SFieldTimestamp extends SFieldScalar {
  public SFieldTimestamp(SRecordMeta meta, String columnName, 
    SPropertyValue [] pvals) {
    super(meta, columnName, pvals);
  }
  public SFieldTimestamp(SRecordMeta meta, String columnName) {
    this(meta, columnName, new SPropertyValue[0]);
  }
  public SFieldTimestamp(SRecordMeta meta, String columnName,
     SPropertyValue pval) {
    this(meta, columnName, new SPropertyValue[]{pval});
  }
  public SFieldTimestamp(SRecordMeta meta, String columnName,
     SPropertyValue pval1, SPropertyValue pval2) {
    this(meta, columnName, new SPropertyValue[]{pval1, pval2});
  }

  /** Abstract specializer.  Clone this key field to
be a foreign key
      to <code>rmeta</code> of the same type.*/
  SFieldMeta makeForeignKey(
    SRecordMeta rmeta, String prefix, SPropertyValue [] pvals) {
    return new SFieldTimestamp(rmeta,      
      (prefix==null?"":prefix)+getString(SCon.SCOLUMN_NAME), 
      pvals);
  }

  Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception {
    java.sql.Timestamp res = rs.getTimestamp(sqlIndex);
    if (rs.wasNull()) // ie. last operation!
      return null;
    else 
      return res;
  }
 
  Object convertToField(Object raw)  throws Exception
  {
    if (raw instanceof java.sql.Timestamp) return (java.sql.Timestamp) raw;
    if (raw == null) return null; // Follows JDBC
    if (raw instanceof String) 
      return java.sql.Timestamp.valueOf((String)raw);
    if (raw instanceof java.util.Date)
      return new java.sql.Timestamp(((java.util.Date)raw).getTime());

    throw new SException.Data("Cannot convert " + raw + " to Timestamp.");
  }

  /** Specializes SFieldMeta. */
  String defaultDataType(){return "TIMESTAMP";}

}

