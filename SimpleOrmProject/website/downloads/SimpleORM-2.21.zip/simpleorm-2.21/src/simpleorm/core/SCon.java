package simpleorm.core;


/**
   This stub just provides a convenient name for the constants.
*/
public class SCon implements SConstants {}
