package simpleorm.core;


public class SDriverDaffodil extends SDriver {

  protected  String driverName() {return "DaffodilDBDriver";}

    protected void addNull(StringBuffer sql, SFieldMeta fld) {
      if (fld.isPrimaryKey || fld.getBoolean(SMANDATORY))
        sql.append(" NOT NULL");
    }


}
