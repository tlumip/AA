package simpleorm.core;

/**
 * Generator using seperate SEQUENCE objects for databases that support them.
 * Common method for Oracle.
 */
public class SGeneratorSequenceTable extends SGenerator {
	
	public SGeneratorSequenceTable(SRecordMeta record) {super(record);}

	protected long generateKey(SRecordMeta meta, SFieldMeta keyField) {
		throw new SException.Error("Not implemented yet.");
	}

}