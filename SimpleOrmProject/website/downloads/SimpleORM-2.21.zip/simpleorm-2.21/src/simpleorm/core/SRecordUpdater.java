package simpleorm.core;

import java.sql.Connection;
import java.sql.PreparedStatement;

import simpleorm.core.SRecordInstance.BrokenOptimisticLockException;

/**
 * Overflow from SRecordInstance, all the flushing logic.
 * Instance per SRecordMeta.
 */
class SRecordUpdater {

	static void flush(SRecordInstance instance) {
		SRecordMeta meta = instance.getMeta();
		if (SLog.slog.enableUpdates())
			SLog.slog.updates("Flushing '" + instance + "'" +
					(instance.newRow?"INSERT":instance.deleted?"DELETE":"UPDATE"));
		
		if (!instance.isDirty()) return;
		// No error to attempt to flush clean record.
		if (instance.updateListIndex == -1)
			throw new SException.Error(
					"Record isDirty but not in updateList (detached?) " + instance);
		
		instance.validateRecord();
		
		SConnection scon = SConnection.getBegunConnection();
		
		if (instance.sConnection != scon)
			throw new SException.Error(
					"Inconsistent Connections " + instance + instance.sConnection + scon);
				
		/// Determine fields to be updated.
		SArrayList fieldList = new SArrayList(meta.sFieldMetas.size());
		if (!instance.deleted) {
			for (int ux=0; ux<meta.sFieldMetas.size(); ux++) {
				SFieldMeta sfm = (SFieldMeta)meta.sFieldMetas.get(ux);
				boolean upd = (instance.newRow && sfm.isPrimaryKey);
				upd = upd || (instance.bitSets[sfm.fieldIndex] & SCon.INS_DIRTY) != 0;
				upd = upd && (instance.newRow || !sfm.isPrimaryKey);
				// Primarly keys are marked dirty if retrieved via findOrCreate.
				if (upd && !(sfm instanceof SFieldReference))
					fieldList.add(sfm);
			}
		}
		if (!(instance.newRow && instance.deleted)
				&& (instance.deleted || fieldList.size() > 0)) {
			
			/// Determine the SQL Query
			String qry = null;
			
			// Allocate max size, Object[] more efficient than SArrayList
			Object[] keyMetaValues = new Object[meta.sFieldMetas.size()];
			
			SArrayList keyMetas = instance.keyFieldMetas(
					!instance.newRow && instance.optimisticFieldValues != null, // true --> Optimisitic
					keyMetaValues );
			
			if (instance.newRow)
				qry = scon.sDriver.insertSQL(fieldList, meta);
			else if (instance.deleted)
				qry = scon.sDriver.deleteSQL(meta, keyMetas, instance, keyMetaValues);
			else
				qry = scon.sDriver.updateSQL(fieldList, meta, keyMetas, instance, keyMetaValues);
			// ## could cache the creation of these queries.  But pretty
			// fast anyway.  Batching them is much more important.
			
			/// Prepare the statement
			Connection con = scon.jdbcConnection;
			PreparedStatement ps = null;
			try {
				ps = con.prepareStatement(qry); // Let the JDBC driver cache these.
			} catch (Exception psex) {
				throw new SException.JDBC("Preparing " + instance + "'" + qry + "'", psex);
			}
			
			/// setObject(,)s the new body values for INSERT or UPDATE statement
			int jx = 0; // JDBC setString
			SArrayList parameters = new SArrayList( 20 ); // Just used for tracing
			if (!instance.deleted) {
				for (int vx=0; vx<fieldList.size(); vx++) {
					int pvx = ((SFieldMeta)fieldList.get(vx)).fieldIndex;
					SFieldMeta fieldMeta = (SFieldMeta)fieldList.get(vx);
					try {
						jx++;
						parameters.add( instance.fieldValues[pvx] );
						
						// ### Maybe should dispach setObject to SField* drivers.
						if (instance.fieldValues[pvx]==null)
							ps.setNull(jx,java.sql.Types.VARCHAR);
						// The VARCHAR is needed for Oracle, otherwise it
						// complains that it does not know what type the null is
						// (ie. with setObject(,null)).  Odd.  But varchar is safe
						// for other types as everything can be coerced to a
						// string.  And as it is only null, nothing has to be
						// coerced.
						else
							//ps.setObject(jx,fieldValues[pvx]);
							// writeFieldValue converts True to "Y" etc.
							fieldMeta.writeFieldValue(ps, jx, instance.fieldValues[pvx]);
					} catch (Exception se) {
						throw new SException.JDBC("Setting Values " + instance + "'" + qry
								+ "' Field " + (vx+1), se);
					}
				}
			}
			/// setObject(,)s the key for UPDATE or DELETE statement.  May include
			/// optimisitic fields.
			if (!instance.newRow) {
				for (int kx=0; kx<keyMetas.size(); kx++) {
					SFieldMeta fieldMeta = (SFieldMeta)keyMetas.get(kx);
					int pkx = fieldMeta.fieldIndex;
					Object value;
					if (instance.optimisticFieldValues == null)
						value = instance.fieldValues[pkx];
					else
					{
						try {
							value = fieldMeta.writeFieldValue(instance.optimisticFieldValues[pkx]);
						} catch (Exception se)
						{
							throw new SException.JDBC("Converting optimistic field value '" + instance + " '" + qry
									+ "' " + jx + keyMetas.get(kx) +  " = " + instance.fieldValues[pkx] , se);
						}
					}
					
					if (value != null) { // else generates IS NULL
						jx++;
						if (SLog.slog.enableFields())
							SLog.slog.fields("Key set " + instance + jx +
									keyMetas.get(kx) + " = " + value);
						try {
							parameters.add( value );
							ps.setObject(jx, value);
						} catch (Exception se) {
							throw new SException.JDBC("Setting  " + instance + " '" + qry
									+ "' " + jx + keyMetas.get(kx) +  " = " + value , se);
						}
					}
				}
			}
			/*
			 if (!newRow) {
			 for (int kx=0; kx<keyMetas.size(); kx++) {
			 int pkx = ((SFieldMeta)keyMetas.get(kx)).fieldIndex;
			 Object value
			 = optimisticFieldValues == null ? fieldValues[pkx]
			 : optimisticFieldValues[pkx];
			 if (value != null) { // else generates IS NULL
			 jx++;
			 if (SLog.slog.enableFields())
			 SLog.slog.fields("Key set " + instance + jx + keyMetas.get(kx) + " = " + value);
			 try {
			 parameters.add( value );
			 ps.setObject(jx, value);
			 } catch (Exception se) {
			 throw new SException.JDBC("Setting  " + instance + " '" + qry
			 + "' " + jx + keyMetas.get(kx) +  " = " + value , se);
			 }
			 }
			 }
			 }
			 */
			
			// Logging
			if (SLog.slog.enableQueries())
				SLog.slog.queries("FlushSQL " + SQuery.substitute( qry, parameters ) );
			
			/// Execute the Query
			int result = 0;
			try {
				result = ps.executeUpdate();
			} catch (Exception rsex) {
				throw new SException.JDBC(
						"Executing " + qry + " for " + instance, rsex);
			}
			if (result != 1) {
				if (instance.optimisticFieldValues != null && result == 0)
					throw new BrokenOptimisticLockException(instance);
				else
					throw new SException.InternalError(
							"Rows Updated " + result + " != 1 "  + instance);
			}
			try { ps.close(); }
			catch (Exception cl1) {
				throw new SException.JDBC("Closing " + instance, cl1);
			}
			
		}
		
		/// Clear dirty and Remove this from updateList
		for (int fdx=0; fdx<fieldList.size(); fdx++)
		{
			SFieldMeta field = (SFieldMeta)fieldList.get(fdx);
			int fdfx = field.fieldIndex;
			instance.bitSets[fdfx] &= ~SCon.INS_DIRTY; // leave valid bit set.
			
			// Also clear dirty-flag for SFieldReference
			if ( field.sFieldReference != null )
			{
				instance.bitSets[field.sFieldReference.fieldIndex] &= ~SCon.INS_DIRTY;
			}
		}
		scon.uncommittedFlushes = true;
		scon.updateList.set(instance.updateListIndex, null);
		instance.updateListIndex = -1;
		instance.dirty = false;
		instance.newRow = false; // Any subsequent flush should be an UPDATE.
		// If was deleted leave as deleted -- attempts to access will fail.
		// if newRow && deleted OK to leave in updateListIndex.
		if (instance.optimisticFieldValues != null)
			instance.setOptimistic(true); // In case the record is flushed a second time.
	} // flush

}
