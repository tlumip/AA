package simpleorm.core;

/**
 * Generator using seperate SEQUENCE objects for databases that support them.
 * Common method for Oracle.
 */
public class SGeneratorSequence extends SGenerator {

	public SGeneratorSequence(SRecordMeta record) {super(record);}

	protected long generateKey(SRecordMeta meta, SFieldMeta keyField) { 
		SConnection scon = SConnection.getBegunConnection();
		long key = scon.sDriver.generateKeySequence(meta, keyField);
		return key;
	}
	
	private String sequenceName() {
    SFieldMeta keyField = (SFieldMeta)record.keySFieldMetas.get( 0 );
    String name = keyField.getString(SCon.SSEQUENCE_NAME);
    return name;
	}
	public String createDDL(){
		SConnection scon = SConnection.getBegunConnection();
		return scon.sDriver.createSequenceDDL(sequenceName());
	}
	public String dropDDL(){
		SConnection scon = SConnection.getBegunConnection();
		return scon.sDriver.dropSequenceDDL(sequenceName());
	}
}