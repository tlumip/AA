package simpleorm.core;

/**
 * Basic Select Max style generator.
 */
public class SGeneratorSelectMax extends SGenerator {
	
	public SGeneratorSelectMax(SRecordMeta record) {super(record);}

	protected long generateKey(SRecordMeta meta, SFieldMeta keyField) { 
		SConnection scon = SConnection.getBegunConnection();
		long key = scon.sDriver.generateKeySelectMax(meta, keyField);
		return key;
	}
}