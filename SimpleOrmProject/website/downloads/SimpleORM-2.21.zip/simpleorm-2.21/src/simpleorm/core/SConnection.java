package simpleorm.core;

import java.sql.*;
import java.util.HashMap;
import java.util.Iterator;

/*
 * Copyright (c) 2002 Southern Cross Software Queensland (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/** Links JDBC Connections to SimpleORM ones and handles transacitons
 and flushing. <p>
 
 Associates existing JDBC transactions with the current thread so that
 they can be used by other SimpleORM classes.  Associating the
 connection with threads avoids nasty threading problems that can
 otherwise arrise.<p>
 
 SimpleORM takes no interest in how the JDBC connection was actually
 obtained.  It might be obtained directly using
 DriverManager.getConnection(), connection pooling software such as
 BitMechanic, or from a J2EE application server.  SimpleORM therefor
 does not restrict the environments in which it can be used.<P>
 
 But note that it is very important that transactions ONLY be COMMITED
 by SimpleORM class, and NOT by raw JDBC calls.<P>
 
 All transactions must start with a {@link #begin} and end with
 either a {@link #commit} or a {@link #rollback}.
 <code>commit</code> also {@link #flush}es any outsanding changes.
 
 (The complex AWT/Swing thread pattern is to have the main thread
 sets up the forms, and then exit.  A second AWT thread then does the
 real work.  In other words a single threaded application pointlessly
 using two threads!  SimpleORM works well with Swing but one needs to
 use <code>invokeAndWait()</code> to set up the forms the AWT thread,
 which is much cleaner anyway.  See 
 {@link simpleorm.examples.SwingTest} for an example.)<p>
 
 This is specialized by SConnectionEJB for use within JTA transaction management.
 **/

public class SConnection extends simpleorm.properties.SPropertyMap
implements SConstants {
	private static SThreadLocal threadSConnection = new SThreadLocal();
	private static long nrCons = 0;
	
	Connection jdbcConnection = null;
	Connection jdbcSequenceConnection = null;
	SDriver sDriver = null;
	
	
	/** The getMetaData() url.  Saved here so that toString can dispaly
	 it even on a closed connection. */
	String url = null;
	
	/** Transaction is active between begin and commit.*/
	boolean hasBegun = false;
	
	/** Data has been flushed but not committed in this transaction. */
	boolean uncommittedFlushes = false; 
	
	/** Only to identify connection for toString() */
	long conNr = ++nrCons;
	
	/** Provided by user to identify thread, eg. HTML session id.  Keep
	 it short. */
	String name = "";
	
	/** Of all records retrieved.  Both key and body are
	 SRecordInstances, which has redefined equals() and hashTable(); */
	HashMap transactionCache = new HashMap();
	
	/** Ordered list of SRecordInstances to flush and purge. */
	SArrayList updateList = new SArrayList(20); 
	
	/** Enables Extra internal validations throughout SimpleORM.  Cheap
	 tests are always enabled, but this can be used to turn on tests
	 that are expensive in times of trouble. */
	static boolean expensiveValidations = false;
	
	/** No direct creation of Connections. */
	protected SConnection(){}
	
	/** True iff commit must be called before the connection there are any (dirty) records that need to be
	 committed, regardless of whether they have been flushed. 
	 (Overriden in SConnectionEJB.)*/
	public boolean mustCommitBeforeDetaching() {
		return updateList.size() > 0 || uncommittedFlushes;
	}
	
	
	/** Allows SConnection to be subclassed. 
	 * connection should normally be null, in which case conf.obtainPrimaryJDBCConnection
	 * is used to open it.
	 * (rawConnection and sDriverName are deprecated.)
	 */
	protected void innerAttach(
			SDataSource source, String connectionName, Connection rawConnection, SDriver driver){
		name = connectionName;

		SConnection badscon = getConnection();
		if (badscon != null)
			throw new SException.Error("Thread's SConnection already open " + badscon);

		dataSource = source;
		Connection con = rawConnection != null ? rawConnection : dataSource.openPrimaryDBConnection();
		try {
			if (con == null || con.isClosed())
				throw new SException.Error("Connection " + con + " is not open.");
		} catch (Exception ex) {throw new SException.JDBC(ex);}

		jdbcConnection = con;
		rawAttach();

		try {
			url = con.getMetaData().getURL();
		} catch (Exception eu) {throw new SException.JDBC(eu);}
		
		if (dataSource == null)
			sDriver = driver==null ? SDriver.newSDriver(con, null) : driver;
		else 
			sDriver = SDriver.newSDriver(con, dataSource.getSDriverName());
		try {
			if (jdbcConnection.getAutoCommit())
				jdbcConnection.setAutoCommit(false);
		} catch (Exception ex) {throw new SException.JDBC(ex);}
		String jvsn = SJSharp.jvmVersion();
		SLog.slog.connections("Attached Connection " + this + " SimpleORM " + SUte.simpleormVersion() + " jdk " + jvsn);
	}
	static SDataSource dataSource;
	public SDataSource getDataSource(){return dataSource;}
	
	protected void rawAttach() { // Overriden in SConnectionEJB
		threadSConnection.set(this);
	}
	
	/** 
	 * Attaches a SimpleORM connection to the current thread based on conf.
	 * Opens a JDBC connection.<p>
	 * 
	 * connectionName is a simple name that can be used to identify this connection
	 * in log traces etc.  Eg. the session ID plus the user name.  But keep it short
	 * for logging.<p>
	 * 
	 * The driver is usually determined automatically (if null) based on the conf, 
	 * but if it is overriden make sure to create a new driver instance for each connection.<p>
	 * 
	 * @see SDataSource for details.
	 */
	public static void attach(SDataSource source, String connectionName) {
	  new SConnection().innerAttach(source, connectionName, null, null);	
	}

	
	/** Attaches the already opened JDBC Connection <code>con</code> to
	 the current thread for future processing by SimpleORM.
	 	 
	 @deprecated Use attach() or attach(source) instead which can open mulitple connections needed for some key generation algorithms.
	 @see SDataSource for details.
	 */
	public static void attach(
			Connection con, String connectionName, SDriver driver){
		new SConnection().innerAttach(null, connectionName, con, driver);
	}
	/** Attaches the already opened JDBC Connection <code>con</code> to
	 the current thread for future processing by SimpleORM.
	 	 
	 @deprecated Use attach() or attach(source) instead which can open mulitple connections needed for some key generation algorithms.
	 @see SDataSource for details.
	 */
	public static void attach(
			Connection con, String connectionName){
		new SConnection().innerAttach(null, connectionName, con, null);
	}
	
	/** 
	 * Retrieve or create the SConnection associated with this "Context".
	 * Normally this just means (indirectly) call getThreadedConnection
	 * which finds the connection associated with this thread.
	 * However, if EJB.SConnectionEJB is loaded, then this can be dispached
	 * to getTransactionConnection instead.   
	 * <p>
	 * 
	 It may or may not be begun.  May be used to set properties for
	 the connection, which persist between transactions but not
	 between attach ments.*/
	static public SConnection  getConnection() {
		return connectionGetter.getAConnection();
	}
	static SConnection getThreadedConnection() { 
		SConnection scon = (SConnection)threadSConnection.get();
		return scon;
	}
	static protected ConnectionGetter connectionGetter = new ConnectionGetter();
	/**
	 * Just dispaches getConnection to either SConnection or SConnectionEJB if it was loaded.<p>
	 * 
	 * Normally connections are associated with the current thread and SConnectionEJB is not
	 * a core part of SimpleORM and so not loaded.  
	 * But if SConnectionEJB (or similar) is loaded then it has to be able to intercept
	 * the SConnection.getConnection call used by all other SimpleORM methods such as 
	 * findOrCreate.  So SConnectionEJB overrides the connectionGetter static when it loads 
	 * so that it can redirect to itself, and then specialize SConnection methods as needed.<p>
	 *   
	 * Do not worry about this unless you are using EJB JTA.  
	 * Note that this has nothing to do with the creation of jdbc connections.
	 */
	protected static class ConnectionGetter {
		protected SConnection getAConnection() {
			return SConnection.getThreadedConnection();
		}
	}
	
	/** Gets current SConnection object for thread.  Throws an exception
	 if not attached and open. */
	private static SConnection getOpenedConnection() {
		SConnection scon = getConnection();
		if (scon == null || scon.jdbcConnection == null) 
			throw new SException.Error("Bad SConnection -- Not opened/attached ");
		try {
			if (expensiveValidations && scon.jdbcConnection.isClosed()) 
				throw new SException.Error("Bad SConnection -- Closed " 
						+ scon.jdbcConnection);
		} catch (Exception ex) {throw new SException.JDBC(ex);}
		return scon;
	}
	
	/** Gets current SConnection object for thread.  Throws an exception
	 if not attached and open AND between begin() and
	 commit() or rollback().  Package local.*/
	static SConnection getBegunConnection() {
		SConnection scon = getOpenedConnection();
		if (!scon.hasBegun()) 
			throw new SException.Error("Transaction not begin()ed.");
		return scon;
	}
	
	/** Transaction is active between begin and commit.*/
	public boolean hasBegun() {return hasBegun;}
	
	/** If the JDBC connection has been attached and not closed. */
	public boolean isOpened() {
		try {
			return jdbcConnection != null && !jdbcConnection.isClosed();
		} catch (SQLException ex) {return false;}
	}
	
	
	/** Asserts transaction Begin()ed and returns the JDBC connection.
	 Can be used to integrate direct JDBC calls with the SimpleORM
	 connection.  Dangerous.  Take care with caching and never use
	 this to commit a transaction.  Should only be rarely used in
	 practice. */
	public static Connection getBegunDBConnection() {
		SConnection scon = getBegunConnection();
		return scon.jdbcConnection;
	}
	
	/**
	 @deprecated Renamed to getBegunDB Connection (Might not beJDBC if .Net).
	 */
	public static Connection getBegunJDBCConnection() {
		return getBegunDBConnection();
	}
	
	/**
	 * Returns a secondary jdbc connection for generating sequence numbers, if required.
	 * Creates a new one if necessary. 
	 */
	Connection getSequenceDBConnection() {
		if (jdbcSequenceConnection == null) {
			if (getDataSource() == null)
				throw new SException.Error("No SDataSource supplied to create secondary connection " + this);
			jdbcSequenceConnection = getDataSource().openSecondaryDBConnection();
		}
		return jdbcSequenceConnection;
	}
	
	/** Detaches the SConnection from the current thread without
	 closing the JDBC connection so that it can be reattached to another thread. 
	 Rarely used, <code>detachAndClose</code> is normally what is used.<p>
	 
	 Checks and throws and issues a message if there are any unflushed
	 records that have been updated.  One should normally commit() or
	 rollback() before detaching unless embedded within an EJB, in
	 which flush() is required.
	 */
	public static void detachWithoutClosing(){ 
		SConnection scon = getConnection();
		SLog.slog.connections("Detaching Connection " + scon);
		if (scon == null) return; // Eg. if exception during long transaction.
		if (scon.hasBegun && scon.mustCommitBeforeDetaching()) {
			// throw new SException.Error(...)
			// Does not behave well in finally clauses -- if the try fails
			// this then throws another "not committed" exception which masks
			// the first. No known work arround in Java!
			SLog.slog.error("Transaction has unflushed updated records.  This is normally caused by an unrelated Exception throwing to the finally block in which case ignore this message.  But if no other exception then a commit() probably missing.");
		}
		destroyAll(); // For J2EE case where flush/detach used.
		scon.jdbcConnection = null;
		scon.jdbcSequenceConnection = null;
		scon.rawDetach();
	}
	protected void rawDetach() { // Overriden in SConnectionEJB
		threadSConnection.set(null);
	}
	
    /**
     * Closes the JDBC connection and then calls
     * <code>detachWithoutClosing</code> to detach the SimpleORM connection
     * from the current thread. Should usually be put in a finally clause. No
     * error if already detached or closed so safe in finally clauses.
     * <p>
     */
    public static void detachAndClose() {
        SConnection scon = getConnection();
        if (scon != null) {
            closeCon(scon.jdbcConnection);
            closeCon(scon.jdbcSequenceConnection);
        }
        detachWithoutClosing();
    }
    private static void closeCon(Connection con) {
        boolean isOpen = false;
        try {
            isOpen = con != null && !con.isClosed();
        } catch (Exception ex) {
            throw new SException.JDBC("isClosed ", ex);
        }
        if (isOpen) {
            try {
                con.rollback(); // If transaction open and
                                                // exception, esp. for DB2.
            } catch (Exception ex) {
                throw new SException.JDBC("Error rollback " + con, ex);
            }
             try {
                con.close();
            } catch (Exception ex) {
                throw new SException.JDBC("Error closing " + con, ex);
            }
        }
    }


    /** Convenience routine for doing bulk updates using raw JDBC.
	 Dangerous.  Take care with caching and never use this to commit
	 a transaction.  Returns number of rows updated.
	 Does nothing if sql == null.
	 */
	public static int rawUpdateDB(String sql, Object [] params) {
		SLog.slog.updates("rawDB " + sql);
		int res = -1;
		if (sql != null) {
			Connection con = getBegunDBConnection();
			try {
				PreparedStatement ps = con.prepareStatement(sql);
				for (int px=0; px<params.length; px++) {
					ps.setObject(px+1, params[px]);
				}
				res = ps.executeUpdate();
				ps.close();
			} catch (Exception ex) {
				throw new SException.JDBC("SQL: " + sql, ex);
			}
		}
		return res;  	
	}
	public static int rawUpdateDB(String sql, Object param) {
		return rawUpdateDB(sql, new Object[]{param});
	}
	public static int rawUpdateDB(String sql) {
		return rawUpdateDB(sql, new String[0]);
	}
	
	/**
	 @deprecated Renamed to rawUpdateDB Connection (Might not beJDBC).
	 */
	public static int rawUpdateJDBC(String sql, Object [] params) {
		return rawUpdateDB(sql, params);
	}
	/**
	 @deprecated Renamed to rawUpdateDB Connection (Might not beJDBC).
	 */
	public static int rawUpdateJDBC(String sql, Object param) {
		return rawUpdateDB(sql, param);
	}
	/**
	 @deprecated Renamed to rawUpdateDB Connection (Might not beJDBC).
	 */
	public static int rawUpdateJDBC(String sql) {
		return rawUpdateDB(sql);
	}
	
	
	
	/** Utility routine for dropping tables.  Hides JDBC exception
	 caused if the table does not exist.  Mainly used in test cases.
	 (Does not use the SRecord objects so that they do not all have
	 to be loaded during specific tests.)  Dispatched to SDriver.<p>
	 
	 WARNING: JDBC error suppression is crude -- a table may indeed
	 exist and still not be dropped for other reasons,
	 eg. referential integrity. <p>
	 
	 WARNING: Due to bugs in JDBC etc. each dropped table must be in
	 its own transaction in case of errors.  This routine commits changes.*/
	public static void dropTableNoError(String table) {
		if (getBegunConnection().mustCommitBeforeDetaching())
			throw new SException.Error("Uncommited Updates need to be committed.");
		getDriver().dropTableNoError(table);
		commit();
		begin();
	}
	
	/** Convenience routine for doing single row queries using raw JDBC.
	 Be sure to flush the cache appropriately, or you will query
	 behind it.<p>
	 
	 if <code>nrColumns == 0</code> (default) returns one result
	 column as a non array object, otherwise returns an array of
	 results.  (nrColumns avoids the need to use JDBC meta data which
	 can be buggy.)  */
	public static Object rawQueryDB(
			String sql, String [] params, int nrColumns) {
		Connection con = getBegunJDBCConnection();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			for (int px=0; params != null && px<params.length; px++) {
				ps.setString(px+1, params[px]);
			}
			ResultSet rs = ps.executeQuery();
			Object res = null;
			if (rs.next()) {
				if (nrColumns == 0)
					res = rs.getObject(1);
				else {
					Object [] ares = new Object[nrColumns];
					for (int rx=0; rx<nrColumns; rx++)
						ares[rx] = rs.getObject(rx+1);
					res = ares;
				}
				if (rs.next())
					throw new SException.Error(
							"Query returned multiple rows " + sql 
							+ SUte.arrayToString(params));
			} 
			rs.close();
			ps.close();
			if (SLog.slog.enableQueries())
				SLog.slog.queries("rawJDBC " + sql + " -- " + res);
			return res;
		} catch (Exception ex) {
			throw new SException.JDBC(ex);
		}
	}
	public static Object rawQueryDB(String sql, String [] params) {
		return rawQueryDB(sql, params, 0);
	}
	public static Object rawQueryDB(String sql, String param) {
		return rawQueryDB(sql, new String[]{param});
	}
	public static Object rawQueryDB(String sql) {
		return rawQueryDB(sql, new String[0]);
	}
	
	/** @deprecated Renamed rawQueryDB  */
	public static Object rawQueryJDBC(
			String sql, String [] params, int nrColumns) {
		return rawQueryDB(sql, params, nrColumns);
	}
	public static Object rawQueryJDBC(String sql, String [] params) {
		return rawQueryDB(sql, params);
	}
	public static Object rawQueryJDBC(String sql, String param) {
		return rawQueryDB(sql, param);
	}
	public static Object rawQueryJDBC(String sql) {
		return rawQueryDB(sql);
	}
	
	
	/** Start a new transaction.  A JDBC connection must already be
	 attached to this thread, and must not be mid transaction. */
	public static void begin() {
		SConnection scon = getOpenedConnection();
		if (scon.hasBegun)
			throw new SException.Error("Transaction already Begun.");
		if (scon.transactionCache.size() != 0 || scon.updateList.size() != 0)
			throw new SException.InternalError("Non empty cache/update list.");
		scon.hasBegun=true;
		SLog.slog.connections("Begun Connection " + scon);
	}
	
	/** Flush and purge the transaction cache to the database, and then
	 commit the transaction.  Note that this is the only way that a
	 transaction should be commited -- do not use JDBC commit
	 directly.  Once commited, <code>begin()</code> must be used to
	 start the next transaction.*/
	public static void commit() {
		SConnection scon = getBegunConnection();
		flush();
		destroyAll();
		
		try {
			scon.jdbcConnection.commit();
		} catch (Exception ex) {
			throw new SException.JDBC(ex);
		}
		scon.uncommittedFlushes = false;
		scon.hasBegun=false;
		SLog.slog.connections("Committed Connection " + scon);
	}
	
	/** Purges the cache and rolls back the transaction.  Any uncommited
	 updates to the database are also rolled back. */
	public static void rollback() {
		destroyAll();
		SConnection scon = getBegunConnection();
		try {
			scon.jdbcConnection.rollback();
		} catch (Exception ex) {
			throw new SException.JDBC(ex);
		}
		scon.uncommittedFlushes = false;
		scon.hasBegun=false;
		SLog.slog.connections("Rolled Back Connection " + scon);
	}
	
	/** Flush all records of tables in this transaction to the database. */
	public static void flush(){
		SConnection scon = getBegunConnection();    
		for (int i = 0; i < scon.updateList.size(); i++) { // Jan reckons iterator causes grief?
			SRecordInstance ri = (SRecordInstance)scon.updateList.get(i);
			if (ri != null) ri.flush(); // Could have been manually flushed.
		}
		scon.updateList.clear();
	}
	
	/** Flushes and Purges all record instances.  Can be used before a
	 raw JDBC update to ensure that the cache remains consistent
	 after the query.
	 
	 @see SRecordInstance#flushAndPurge
	 @see SRecordMeta#flushAndPurge 
	 */
	public static void flushAndPurge() {
		flush();
		destroyAll();
	}
	
	/** Destroy all records in all tables so that they cannot be used
	 again and to encourage garbage collection. */
	static void destroyAll(){
		SConnection scon = getConnection();    
		Iterator ci = scon.transactionCache.values().iterator();
		while (ci.hasNext()) {
			SRecordInstance ri = (SRecordInstance)ci.next();
			ri.incompleteDestroy();
		}
		scon.transactionCache.clear();
		scon.updateList.clear();
	}
	
	/** Dumps out the entire cache of records for this connection.  For
	 debugging wierd bugs only. */
	public static void dumpCache() {
		SLog.slog.message("DumpCache");
		SConnection scon = getConnection();    
		Iterator ci = scon.transactionCache.values().iterator();
		while (ci.hasNext()) {
			SRecordInstance ri = (SRecordInstance)ci.next();
			SLog.slog.message("  " + ri + (ri.isDirty()?" Dirty":""));
		}
	}
	
	/** Eg. if (getDriver() instanceOf SDriverPostgres) ... 
	 * Also getDriver().setMyFavoritePerConnectionParameter.
	 */
	static public SDriver getDriver() {return getConnection().sDriver;}
	
	
	/** Enables the SimpleORM connection to be disassociated with the
	 current thread, and then associated with another thread.
	 Dangerous.  When you pick up the connection you also pick up the
	 hash map of records retrieved during the transaction.<p>
	 
	 This is provided for completeness only.  Note that both Swing
	 and EJBs can be used without doing this (see the examples).  If
	 you end up with two threads accessing the same connection at the
	 same time you will have horrible, unreproduceable bugs.<p>
	 
	 Don not do it unless you really have to.  */
	public static SConnection unsafeDetachFromThread() {
		SConnection scon = (SConnection)threadSConnection.get();
		SLog.slog.connections("unsafeDetachFromThread " + scon);
		threadSConnection.set(null);
		return scon;
	}
	/** Re-attacheds a detached connection to the current thread.
	 
	 @see #unsafeDetachFromThread
	 */
	public void unsafeAttachToThread() {
		SConnection scon = (SConnection)threadSConnection.get();
		if (scon != null) 
			throw new SException.Error(
					"This thread already has connection " + scon);
		threadSConnection.set(this);
		SLog.slog.connections("unsafeAttachToThread " + this);
	}
	
	
	/** Short connection/thread identifier for inclusion in log messages
	 to enable output from different threads to be separated. */
	static String shortToString() {
		SConnection con=getConnection();
		if (con != null)
			return con.conNr + "." +  con.name;
		else
			return "No Connection";
	}
	
	/*
	 public static static void flush(Class rec){}
	 public void flush(SRecordMeta rec){} // This record
	 public static void purge(){} // ie. and remove from cache.
	 public static void purge(Class rec){}
	 public void purge(SRecordMeta rec){}
	 */
	
	public String toString() {
		return "[SConnection " + conNr + "_" + name + ": " + url + "]";
	}
}

