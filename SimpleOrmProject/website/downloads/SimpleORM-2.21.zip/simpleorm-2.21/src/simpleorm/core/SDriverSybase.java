package simpleorm.core;

/** This contains Sybase Adaptive Server specific code.
 */

public class SDriverSybase extends SDriver {

  protected String driverName() {return "jConnect (TM) for JDBC (TM)";}

  /** Sybase only understands DATETIME (and SMALLDATETIME) and timestamp (must be lc!)*/
  protected String columnTypeSQL(SFieldMeta field) {
    if ( ((String)field.getProperty(SDATA_TYPE)).equals("TIMESTAMP") )
      return "timestamp"; 
    if ( ((String)field.getProperty(SDATA_TYPE)).equals("DATE") )
      return "datetime"; 
    if ( ((String)field.getProperty(SDATA_TYPE)).equals("TIME") )
      return "datetime"; 
    else
      return super.columnTypeSQL(field);
  }


 protected String forUpdateSQL(boolean forUpdate)
  {
      return "";
  }

  /** MSSQL and Sybase do not support FOR UPDATE.  But the docs say to use WITH
      (XLOCK).  But Jorge says that it is unnecessary and makes
      SimpleORM fail.  Very odd. */
  protected String postFromSQL(boolean forUpdate)
  {
    // if (forUpdate) return " WITH (XLOCK)";
    return "";
  }
}

