package simpleorm.core;
import simpleorm.properties.*;

/*
 * Copyright (c) 2002 Southern Cross Software Limited (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/** This interface contains all the SProperties constants used in
 SimpleORM.  Properties are a general way to attach extra information
 to SRecordMetas and SFieldMetas.  They are usually used as follows:-<p>
 <xmp>
 public static final SFieldObject TSTAMP_OBJ =
 new SFieldObject(meta, "TSTAMP_OBJ",
 SDATA_TYPE.pvalue("TIMESTAMP"));
 
 public static final SFieldString DATA_ID =
 new SFieldString(meta, "DATA_ID", 10, SFD_PRIMARY_KEY);
 </xmp>
 
 Each of the <code>SField*</code> initializers allows 0, 1, 2 or an
 array of <code>SPropertyValues</code> to be passed as trailing
 parameters.  Each of these contains an SProperty and a value for that
 property.  Thus the first example adds a property
 <code>SDATA_TYPE</code> to the <code>TSTAMP_OBJ</code> field with
 value <code>"TIMESTAMP"</code>.<p>
 
 As a convenience the <code>SFD_</code> constants contain precreated
 <code>SPropertyValues</code> for simple boolean properties.  So the
 second example is just a short cut for:-<p>
 
 <xmp>
 public static final SFieldString DATA_ID =
 new SFieldString(meta, "DATA_ID", 10,
 SPRIMARY_KEY.pvalue(Boolean.TRUE));
 </xmp>
 
 (Due to a bug in Javadoc (1.3 at least) anonymous classes cannot be used to initiate static constants.)<p> */

public interface SSimpleORMProperties {
	
	/** The array of fields with in an SRecordMeta. */
	static final SProperty SFIELD_METAS = new SPropertySFieldMetas();
	public static class SPropertySFieldMetas extends SProperty {
		SPropertySFieldMetas(){super("SFieldMetas");}
		protected Object theValue(SPropertyMap map) {
			SRecordMeta rec = (SRecordMeta)map;
			return rec.sFieldMetas.toArray(new SFieldMeta[0]);
		}
	}
	
	/** Map of all fields in an SRecordMeta. Same elements as
	 <code>SFIELD_METAS</code>, but a HashMap instead of an array,
	 keyed by the SFIELD_NAME name.<p>
	 
	 Normally just use <code>SRecordMeta.getField(name)<code> to
	 retrieve fields by name.  */
	static final SProperty SFIELD_MAP = new SPropertySFieldMap();
	public static class SPropertySFieldMap extends SProperty {
		SPropertySFieldMap(){super("SFieldMap");;}
		protected Object theValue(SPropertyMap map) {
			SRecordMeta rec = (SRecordMeta)map;
			return rec.fieldMap;
		}
	}
	
	/** Arbitrary field name to be used by applications.  Defaults to
	 column name or to Column name or prefix or Referenced table name
	 for references. */
	static final SProperty SFIELD_NAME = new SProperty("SFieldName");
	
	/** The record that an SFieldMeta is associated with. */
	static final SProperty SRECORD_META = new SPropertySRecordMeta();
	public static class SPropertySRecordMeta extends SProperty {
		SPropertySRecordMeta(){super("SRecordMeta");}
		protected Object theValue(SPropertyMap map) {
			SFieldMeta fld = (SFieldMeta)map;
			return fld.sRecordMeta;
		}
	}
	
	/** Index into <code>SFIELD_METAS</code> of an sFieldMeta.
	 ie. <code>field.SRECORD_META.SFIELD_METAS[field.SFIELD_INDEX] ==
	 field</code>. */
	static final SProperty SFIELD_INDEX = new SPropertySFieldIndex();
	public static class SPropertySFieldIndex extends SProperty {
		SPropertySFieldIndex(){super("SFieldIndex");}
		protected Object theValue(SPropertyMap map) {
			SFieldMeta fld = (SFieldMeta)map;
			return SJSharp.newInteger(fld.fieldIndex);
		}
	}
	
	/** The table name of this record OR field. */
	static SProperty STABLE_NAME = new SPropertySTableName();
	public static class SPropertySTableName extends SProperty {
		SPropertySTableName(){super("STableName");}
		protected Object defaultValue(SPropertyMap map) {
			SPropertyMap rec = (SPropertyMap)map.getProperty(SRECORD_META);
			return rec.getProperty(STABLE_NAME);
		}
	};
	
	/** Name of the SQL column. */
	static final SProperty SCOLUMN_NAME = new SProperty("SColumnName");
	
	/** Query fragment to select value.  May be a subselect.
	 Normally also SUNQUERIED.  Never updates.*/
	static final SProperty SCOLUMN_QUERY = new SProperty("SColumnQuery");
	
	
	/** The SQL data type of the column.  For the generic driver this
	 corresponds to the actual type used in the Create Table
	 statement. 
	 Warning, these may be mapped by the SDrivers to try to overcome
	 type incompatibilities.  
	 */
	static final SProperty SDATA_TYPE = new SPropertySDataType();
	public static class SPropertySDataType extends SProperty {
		SPropertySDataType(){super("SDataType");}
		protected Object defaultValue(SPropertyMap map) {
			return ((SFieldMeta)map).defaultDataType();
		}
	}
	/** The parameter to the Varchar(...) data type on the Create Table
	 statement.  Note that it is normally the number of bytes, not the
	 number of characters (in UTF-8, say).  It is a meaningless number,
	 but most databases demand it.  Postgresql does not, and it is not
	 used in that case. */
	static final SProperty SBYTE_SIZE = new SProperty("SByteSize");
	
	/** The precission and scale of Numerics for BigDecimal.  Used to
	 generate <code>NUMERIC(precission, scale) in CREATE TABLE</code>
	 statements.*/
	static final SProperty SDECIMAL_PRECISION
	= new SProperty("SDecimalPrecision");
	static final SProperty SDECIMAL_SCALE
	= new SProperty("SDecimalScale");
	
	/** Specifies that the String datatype is to be represented as a
	 CHAR and not a VARCHAR. */
	static final SProperty SSTRING_CHAR = new SProperty("SStringChar");
	static final SPropertyValue SFD_STRING_CHAR
	= new SPropertyValue(SSTRING_CHAR);
	
	
	
	/** Indicates which are the primary key field(s).
	 Every record must have a primary key.  */
	static final SProperty SPRIMARY_KEY = new SProperty("SPrimaryKey");
	static final SPropertyValue SFD_PRIMARY_KEY
	= new SPropertyValue(SPRIMARY_KEY);
	
	/** SFieldReference property that suppresses the generation of
	 Foreign Key constraint DDL.  Defaults from Record and thence Connection. */
	static final SProperty SNO_FOREIGN_KEY = new SPropertyNoForeignKey();
	static final SPropertyValue SFD_NO_FOREIGN_KEY
	= new SPropertyValue(SNO_FOREIGN_KEY);
	public static class SPropertyNoForeignKey extends SProperty {
		SPropertyNoForeignKey(){super("SNoForeignKey");}
		protected Object defaultValue(SPropertyMap map) {
			if (map instanceof SFieldMeta) {
				SPropertyMap rec = (SPropertyMap)map.getProperty(SRECORD_META);
				return rec.getProperty(SNO_FOREIGN_KEY);
			} else if (map instanceof SRecordMeta &&
					SConnection.getConnection() != null)
				return SConnection.getConnection().getProperty(SNO_FOREIGN_KEY);
			else
				return null;
		}
	};
	
	/** If Field A.SFIELD_REFERENCE = Field B then B is a
	 SFieldReference field and A forms a part of that reference.
	 Eg. if B = Employee.Department, A=Employee.Dept_Id.*/
	static final SProperty SFIELD_REFERENCE = new SPropertySFieldReference();
	public static class SPropertySFieldReference extends SProperty {
		SPropertySFieldReference(){super("SFieldReference");}
		protected Object theValue(SPropertyMap map) {
			SFieldMeta fld = (SFieldMeta)map;
			return fld.sFieldReference;
		}
	}
	//## Should expose the entire internal schema though properties like this.
	
	/** Normally only top level foreign keys are generated.  So
	 PayrollDetail to Payroll is foreign key is normally generated,
	 but not the nested PayrollDetail to Employee.  However, this
	 property can be used to enable inner foreign keys to be
	 generated as well.  (Rarely used in practice.) */
	static final SProperty SINNER_FOREIGN_KEY = new SPropertyInnerForeignKey();
	static final SPropertyValue SFD_INNER_FOREIGN_KEY
	= new SPropertyValue(SINNER_FOREIGN_KEY);
	public static class SPropertyInnerForeignKey extends SProperty {
		SPropertyInnerForeignKey(){super("SInnerForeignKey");}
		protected Object defaultValue(SPropertyMap map) {
			SFieldMeta ref = (SFieldMeta)map.getProperty(SFIELD_REFERENCE);
			return ref != null?ref.getProperty(SINNER_FOREIGN_KEY):null;
		}
	};
	
	
	/** Only "Descriptive" fields (eg. Name) will be queried if
	 <code>SQY_DESCRIPTIVE</code> is specified. */
	static final SProperty SDESCRIPTIVE = new SProperty("SDescriptive");
	static final SPropertyValue SFD_DESCRIPTIVE
	= new SPropertyValue(SDESCRIPTIVE);
	
	/** <code>SUNQUERIED</code> fields are not normally retrieved by
	 queries unless the <code>SQY_UNQUERIED</code> flag is specified
	 on the query.  Typically large, rarely used fields. */
	static final SProperty SUNQUERIED   = new SProperty("SUnqueried");
	static final SPropertyValue SFD_UNQUERIED
	= new SPropertyValue(SUNQUERIED);
	
	/** The field must not be "empty" when the record is flushed.  It may
	 temporarily be empty in the meantime.<p>
	 
	 In order to avoid the horrible SQL NULL semantics, some
	 databases prefer to store empty string values as <code>""</code>
	 rather than <code>NULL</code>s (eg. Sybase, MSSQL).  For now
	 <code>SMANDATORY</code> just means <code>NOT NULL</code> in
	 create table statements.  A java value of <code>""</code>
	 produces SQL <code>""</code>, a java <code>null</code> produces
	 sql <code>null</code>.<p>
	 
	 ### Additional null semantics will be provided later that unify
	 <code>""</code> and <code>null</code> to provide output
	 appropriate for the database used.  This will make it easier to
	 write database independent code, and avoid horrible bugs when
	 the two are confused.<p>
	 
	 @see SRecordInstance#isEmpty
	 */
	static final SProperty SMANDATORY    = new SProperty("SMandatory");
	static final SPropertyValue SFD_MANDATORY
	= new SPropertyValue(SMANDATORY);
	
	/** A generated primary key column.
	 *  The value must be an SGenerator subtype.
	 *       
	 See GeneratedKeyTest.
	 */
	static final SProperty SGENERATED_KEY = new SPropertySGeneratedKey();
	public static class SPropertySGeneratedKey extends SProperty {
		SPropertySGeneratedKey(){super("SGeneratedKey");}
		protected void validate(SPropertyMap map, Object value){
			if (! (value instanceof SGenerator))
				throw new RuntimeException("SGeneratedKey " + value + " is not an SGenerator");
		}
	}
	
	/** Name of the sequence to use for the generated key for databases
	 that support them (eg. Postgresql).  Defaults to
	 tablename_SEQ.  Boolean.FALSE is a special value that causes
	 the default Select Max algoritm to be used. */
	static SProperty SSEQUENCE_NAME = new SPropertySSequenceName();
	public static class SPropertySSequenceName extends SProperty {
		SPropertySSequenceName(){super("SSequenceName");}
		protected Object defaultValue(SPropertyMap map) {
			String tname = map.getString(STABLE_NAME);
			return tname + "_SEQ";
		}
	}
	
	
	/** Suppresses this column being used as a foreign key component.
	 Must be used for database types that cannot be used in WHERE
	 clauses such as Oracle's long type. */
	static final SProperty SOPTIMISTIC_UNCHECKED = new SProperty("SOptimisticUnchecked");
	static final SPropertyValue SFD_OPTIMISTIC_UNCHECKED
	= new SPropertyValue(SOPTIMISTIC_UNCHECKED);
	
	/** Extra text that is appended blindly after the DDL
	 <code>CREATE TABLE</code> column type information but before the
	 ",".  Can be used for database specific tuning, check clauses
	 etc.*/
	static final SProperty SEXTRA_COLUMN_DDL
	= new SProperty("SExtraColumnDDL");
	
	/** Extra text that is appended blindly at the very end of
	 the DDL <code>CREATE TABLE (..., PRIMARY KEY...</code> but
	 before the closing ")".  Can be used for database specific
	 tuning, check clauses etc. This text usually begins with a ",".*/
	static final SProperty SEXTRA_TABLE_DDL
	= new SProperty("SExtraTableDDL");
	
	/** Extra text that is appended blindly at the very end of a foreign
	 key definition.  A typical value is " ON DELETE CASCADE".  (No
	 attempt is made by SimpleORM to keep the cache consistent with
	 changes to the database made in this way.)
	 */
	static final SProperty SEXTRA_FKEY_DDL
	= new SProperty("SExtraFKeyDDL");
	
}
