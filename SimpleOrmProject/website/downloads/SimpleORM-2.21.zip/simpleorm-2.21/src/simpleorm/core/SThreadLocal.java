package simpleorm.core;

/**
 * JAVA implementation of SThreadLocal
 */
public class SThreadLocal extends java.lang.ThreadLocal {
}
/**
 * J# implementation of SThreadLocal
 */
/*
public class SThreadLocal {
    System.LocalDataStoreSlot m_Ldss;
    public SThreadLocal() {
        this.m_Ldss = System.Threading.Thread.AllocateDataSlot();

    }
    public synchronized void set(Object obj) {
        System.Threading.Thread.SetData(this.m_Ldss, obj);
    }
    public synchronized Object get() {
        return System.Threading.Thread.GetData(this.m_Ldss);
    }
}
*/
