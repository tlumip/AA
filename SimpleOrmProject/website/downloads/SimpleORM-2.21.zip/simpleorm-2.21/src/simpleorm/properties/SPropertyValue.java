package simpleorm.properties;

/**
 * Convenience, ephemeral objects for creating properties with values.
 * Note that PropertyHash contains the values directly, not these
 * objects.  They are simply picked apart and the key and values are
 * added to the map separately.<p>
 * 
 * ## The only reason that we need these is that S*Meta records require an array
 * of propertyValues as a parameter.  The alternative would be something like <p>
 * 
 * SField foo = new SField(...).MYPROP(myval).MYPROP2(myval2)...
 * 
 * Where MYPROP just returns the SPropertyMap that SField is.
 * However, this does not work because of initialization code in the SField
 * constructor, which should probably be moved.
 */

public class SPropertyValue{
  SProperty property = null;
  Object value = null;

  public SPropertyValue(SProperty property, Object value) {
    this.property = property;
    this.value = value;
  }

  /** Default value is Boolean.TRUE */
  public SPropertyValue(SProperty property) {
    this.property = property;
    this.value = Boolean.TRUE;
  }
}
