package simpleorm.properties;
import java.util.Hashtable;
import java.util.Enumeration;

/*
 * Copyright (c) 2002 Southern Cross Software Limited (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/** A property map similar to java.util.Propeties except that the keys
 * are SProperty objects, and inheritance is supported.<p>
 *
 * Note that the map is SProperty --> Object directly.
 * SPropertyValues instances are not stored directly in this map, they
 * are picked appart into propety and value which are stored
 * separately.  ## Should they be?
*/
public class SPropertyMap {

  Hashtable hashMap = new Hashtable();

  /** Gets the value of prop for this map.  May return a default value
      if none has been explicitly set.*/
  public Object getProperty(SProperty prop) {
    Object val = prop.theValue(this);
    if (val != null) return val;
    if (hashMap.containsKey(prop)) 
      return hashMap.get(prop);
    else
      return prop.defaultValue(this);
  }


  /** Convenient routine for getting boolean properties.  Default is
      always false. */
  public boolean getBoolean(SProperty prop) {
    Object val = getProperty(prop);
    if (val == null) return false;
    return ((Boolean)val).booleanValue();
  }

  /** (String)getProperty(..). */
  public String getString(SProperty prop) {
    return (String)getProperty(prop);
  }

  /** Sets prop to value for this map after validating it.  May or may
      not already exist.  If value is null then removes the property,
      so a property cannot actually be set to null -- once removed it
      may start defaulting. */
  public void putProperty(SProperty prop, Object value) {
    //System.out.println("     -putting " + this + "." + prop + " := " + value);
    prop.validate(this, value);
    if (value == null) // Needs to be a special case!
      hashMap.remove(prop);
    else
      hashMap.put(prop, value);
  }

  /** Sets prop to value for this map provided that it does not
      already have an <em>explicit</em> value in <em>this</em> map.
      Either way returns the value of the property now.
  */
  public Object putDefaultProperty(SProperty prop, Object value) {
    Object val = hashMap.get(prop);
    if (val == null) {
      val = value;
      putProperty(prop, value);
    }
    return val;
  }

  /** Convenience method that sets this map to each property value pair. */
  public void setPropertyValues(SPropertyValue [] pvals) {
    for (int px=0; px < pvals.length; px++) {
      setPropertyValue(pvals[px]);
    }
  }
  /** Convenience method that sets this mmap to this property value pair. */
  public void setPropertyValue(SPropertyValue pval) {
      putProperty(pval.property, pval.value);
  }

  /** Removes the value in this Map only.  It may still be inheritable
      from other maps or have a default value.  This is quite
      different from setting the value to null. */
  public void remove(SProperty prop) {
    hashMap.remove(prop);;
  }
  
  /** ## Used to create foreign keys.  But should really be smarter and
      use inheritance.  But then multiple inheritiance issues need to
      be resolved.
  public SPropertyValue [] cloneMap() {
    SPropertyValue [] pvals = new SPropertyValue[hashMap.size()];
    int px=0;
    for (Enumeration keys = hashMap.keys(); 
         keys.hasMoreElements(); px++) {
      SProperty prop = (SProperty)keys.nextElement();
      pvals[px]=new SPropertyValue(prop, hashMap.get(prop));
    }
    return pvals;
  }
  */
}
