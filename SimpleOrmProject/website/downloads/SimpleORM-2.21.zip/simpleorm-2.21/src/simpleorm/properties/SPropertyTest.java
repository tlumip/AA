package simpleorm.properties;

/** Unit tests the property subsystem. */

public class SPropertyTest {

  final static SProperty NAME = new SProperty("Name");
  final static SProperty DBFIELD = new SProperty("DBField");
  final static SProperty PROMPT = new SProperty("Prompt"){
      protected Object defaultValue(SPropertyMap map) {
        SPropertyMap form = (SPropertyMap)map.getProperty(DBFIELD);
        return form.getProperty(PROMPT);
      }
    };
  final static SProperty PRIMARY_KEY = new SProperty("PKey");
  final static SPropertyValue SDF_PRIMARY_KEY 
    = new SPropertyValue(PRIMARY_KEY);

  public static SPropertyMap newField(
    SPropertyValue [] pvals) {
    SPropertyMap fld = new SPropertyMap();
    fld.setPropertyValues(pvals);
    return fld;
  }

  public static void main(String[] argv) throws Exception {
    SPropertyMap dbField = newField(
      new SPropertyValue [] {NAME.pvalue("CustNr"), 
                             SDF_PRIMARY_KEY}); // Or PRIMARY_KEY.ptrue()
    dbField.putProperty(PROMPT, "Customer Number");
    
    //SPropertyMap dbField2 = newField(dbField0.cloneMap());

    SPropertyMap uiField = new SPropertyMap();
    uiField.putProperty(DBFIELD, dbField);

    if (!uiField.getProperty(PROMPT).equals("Customer Number"))
      throw new RuntimeException("bad Prompt");
    if (!dbField.getBoolean(PRIMARY_KEY))
      throw new RuntimeException("bad PKey");
  }

}
