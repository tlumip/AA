package simpleorm.properties;
/*
 * Copyright (c) 2002 Southern Cross Software Limited (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/** Represents the key to SPropertyMap.  Each property is identified
 * by its name, which is used to index the map.  There is only one
 * instance of this class for each type of property.
 */
public class SProperty {
  String name=null; // immutable

  /** Name of property (Must be globaly unique). */
  public SProperty(String name) {
    this.name = name;
  }

  public String getName(){return name;}

  /** Equality is based only on the <code>name</code> */
  public boolean equals(Object key2) {
    if (this == key2) return true;
    if (key2 == null || !(key2 instanceof SProperty)) return false;
    return ((SProperty)key2).name.equals(name);
  }
  public int hashCode() {return name.hashCode();}

  /** Provides a default value for a property.  Often specialized. */
  protected Object defaultValue(SPropertyMap map) { return null; }

  /** Provides the value for a property.  If this is specialized then
      setting the property has no effect. */
  protected Object theValue(SPropertyMap map) { return null; }

  /** Validates the property value, throw an exception if
      invalid. specialized. */
  protected void validate(SPropertyMap map, Object value){}

  /** Convenience routine that <code> return new SPropertyValue(this,
      value);</code>.  Used as a parameter to SField etc. eg. 
      <code>{MYPROP.pvalue("myvalue"), ...}</code> */
  public SPropertyValue pvalue(Object value) {
    return new SPropertyValue(this, value);
  }

  /** Convienience routine that returns a PV with TRUE as the value.*/
  public SPropertyValue ptrue() {
    return new SPropertyValue(this);
  }

  public String toString(){return "[SProperty " + name + "]";}

}
