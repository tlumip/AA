package simpleorm.ui;
import simpleorm.properties.*;
import simpleorm.core.*;

/*
 * Copyright (c) 2002 Southern Cross Software Limited (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/** Contains all the constants and property definitions used by
SimpleORM/ui.  Implementing this interface will automatically import
these constants which is convenient.  All constants are prefixed to
avoid conflicts.<p>
*/

public interface SUIConstants extends SConstants {

  /** The prompt to be used by a User Interface.  Defaults to a pretty
      version of the column name. */
  static final SProperty SUI_PROMPT = new SPropertySUIPrompt();
  public static class SPropertySUIPrompt extends SProperty {
    SPropertySUIPrompt(){super("SUIPrompt");}
    protected Object defaultValue(SPropertyMap map) {
      String cname = map.getString(SCOLUMN_NAME);
      String cn2 = cname.replace('_', ' ').toLowerCase(); // ## mixed case
      return cn2;
    }
  }
}

