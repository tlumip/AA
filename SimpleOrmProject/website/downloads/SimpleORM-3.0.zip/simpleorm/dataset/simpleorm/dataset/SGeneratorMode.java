
package simpleorm.dataset;

public enum SGeneratorMode {
	SSELECT_MAX,
    SSEQUENCE,
    SINSERT,
}