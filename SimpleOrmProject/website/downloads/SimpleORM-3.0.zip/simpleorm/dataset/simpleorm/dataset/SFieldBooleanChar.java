package simpleorm.dataset;

import java.sql.ResultSet;

import simpleorm.utils.SException;

/**
 * Booleans which are represented by a string. Constructor determine whether
 * "T", "Y", "Yes" etc.
 */

public class SFieldBooleanChar extends SFieldBoolean {

	private static final long serialVersionUID = 1L;

	/**
	 * Represents Boolean field meta data as trueStr and falseStr chars.
	 * 
	 * @author Martin Snyder.
	 */

	private String TRUE_VALUE;

	private String FALSE_VALUE;

	public SFieldBooleanChar(SRecordMeta meta, String columnName, String trueStr, String falseStr,
			SFieldFlags... pvals) {
		super(meta, columnName, pvals);
		setMaxSize((trueStr.length() > falseStr.length()) ? trueStr.length() : falseStr.length());
		TRUE_VALUE = trueStr;
		FALSE_VALUE = falseStr;
	}

	/**
	 * Converts from database representation to internal representation
	 */
	public Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception {
		String res = rs.getString(sqlIndex);
		if (TRUE_VALUE.equals(res))
			return Boolean.TRUE;
		else
			// Default to false if value is in fact not expected
			return Boolean.FALSE;
	}

	@Override public Object writeFieldValue(Object value) {
		//if (value!=null){
		if (((Boolean) value).booleanValue())
			return TRUE_VALUE;
		else
			return FALSE_VALUE;
		//}else {
		//	return null;
		//}
	}


	@Override
	public String defaultSqlDataType() {
		return "VARCHAR";
	}
	
	public int javaSqlType() {
		return java.sql.Types.VARCHAR;
	}

	@Override
	boolean isCompatible(SFieldScalar field) {
		if (!(field instanceof SFieldBooleanChar)) {
			return false;
		}
		return true;
	}
	
	@Override
	protected Boolean convertToDataSetFieldType(Object raw) {
		if (raw == null)
			return null;
		if (Boolean.TRUE.equals(raw)) return Boolean.TRUE; // Autoboxing if necessary
		if (Boolean.FALSE.equals(raw)) return Boolean.FALSE; // Autoboxing if necessary
		if (raw instanceof String) {
			String s = (String) raw;
			if (TRUE_VALUE.equalsIgnoreCase(s))
				return Boolean.TRUE;
			else if (FALSE_VALUE.equalsIgnoreCase(s))
				return Boolean.FALSE;
		}
		throw new SException.Error("Cannot Convert '" + raw
			+ "' to Boolean.");
	}
}
