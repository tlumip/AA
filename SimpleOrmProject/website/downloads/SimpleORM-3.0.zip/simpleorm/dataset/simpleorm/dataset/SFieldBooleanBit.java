/*
 * Created on Jan 18, 2005
 * Author dhristodorescu
 * Borderfree
 */
package simpleorm.dataset;

import java.sql.ResultSet;


/**
 * @author dhristodorescu Borderfree
 */
public class SFieldBooleanBit extends SFieldBoolean {
	static final long serialVersionUID = 3L;

	public SFieldBooleanBit(SRecordMeta meta, String columnName,
			SFieldFlags... pvals) {
		super(meta, columnName, pvals);
	}

	/**
	 * Converts from database representation to internal representation
	 */
	public Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception {
		return rs.getBoolean(sqlIndex) ? Boolean.TRUE : Boolean.FALSE;
	}

	/** Specializes SFieldMeta. */
	@Override
	public String defaultSqlDataType() {
		return "BIT"; // For MS SQL.
	}

	public boolean isCompatible(SFieldScalar field) {

		boolean result = true;
		if (!(field instanceof SFieldBooleanBit))
			result = false;
		return result;
	}

	@Override
	public
	int javaSqlType() {
		return java.sql.Types.BIT;
	}
	
	
}
