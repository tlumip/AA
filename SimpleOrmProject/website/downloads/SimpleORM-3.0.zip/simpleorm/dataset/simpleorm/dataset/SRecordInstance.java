package simpleorm.dataset;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import simpleorm.utils.SException;
import simpleorm.utils.SUte;
import simpleorm.utils.SException.Error;

/*
 * Copyright (c) 2002 Southern Cross Software Queensland (SCSQ).  All rights
 * reserved.  See COPYRIGHT.txt included in this distribution.
 */

/**
 * Each SRecordInstance represents an individual record in memory that either
 * correspond to a row in the database or a new record that has yet to be
 * inserted.
 * <p>
 * 
 * RecordInstances are normally created by either {@link SSessionJdbc#findOrCreate
 * findOrCreate} or {@link SSessionJdbc#Query}. The former selects a specific
 * record by primary key, while the latter retrieves all records that satify a query.  
 * Instances may also be directly created by {@Link SDataSet#findOrCreate} without reference
 * to a session.
 * <p>
 * 
 * The main methods are <code>get*</code> and <code>set*</code> which get
 * and set field values of the record. {@link #deleteRecord} deletes a row.
 * <p>
 * 
 * No two RecordInstances can have the same primary key field values within the
 * same connection. Attempts to retrieve the same row twice will simple return a
 * pointer to an existing SRecordInstance. There is no relationship between
 * RecordInstances in different connections -- all locking is done by the
 * underlying database.
 * <p>
 */

public abstract class SRecordInstance implements Serializable {

  	static final long serialVersionUID = 20084L;

	/**
	 * This must be defined in every user record's definition to access the
	 * SRecord which provides the meta data for this instance. It is normally
	 * defined as:-
	 * <p>
	 * 
	 * <pre>
	 * SRecord getMeta() {
	 * 	return meta;
	 * };
	 * </pre>
	 * 
	 * <p>
	 * 
	 * The actual <code>meta</code> variable is thus not Serialized, but it
	 * would not be anyway as it is usually static.
	 */
	public abstract SRecordMeta<?> getMeta();

	/**
	 * The one connection to which this Instance is glued. Instances may never
	 * be shared across connections.
	 */
//	private transient SSession sConnection = null;
	
	SDataSet sDataSet = null;
	  
    /** 
     * The value for each field.  
     * Stored in the type they are declared in.  So SFieldIntegers are use JDBC ResultSet.getInt(),
     * and setString (say) converts to an Integer.
     * 
     * There is no actual SimpleOrm object that corresponds to an individual field instance value,
     * a dubious optimization.
     */
	Object[] fieldValues = null;
    /** Value of fieldValue when record retrieved, used to implement optimistic locking. */
	Object[] fieldOptimisticValues = null;
	
	/**
	 * True if queried read only. 
     * Was important if FOR UPDATE not used, but now always optimistically locked anyway.
     * So now just a convenience, to be able to prevent updates to a record.
	 */
	boolean readOnly = false;	

	/**
	 * -1: not in sConnection.updateList either because 1. not dirty or 2. not
	 * attached.
	 */
	int updateListIndex = -1; // (Transient means set to 0, not -1!)
	
	/**
	 * Is dirty and needs to be flushed. But may not be in
	 * sConnection.updateList because the instance is detached.
	 */
	boolean dirty = false;

	/** Need to delete at commit. */
	boolean deleted = false;
	
	/**
	 * Set after <code>findOrInsert()</code> that does not find the row
	 * already in the database.
	 */
	boolean newRow = false;

	/**
	 * @see #wasInCache()
	 */
	boolean wasInCache = false;
		    
    static class InvalidValue implements Serializable {} // Always test with instanceof, not ==
    static final InvalidValue INVALID_VALUE = new InvalidValue();
    
	
	/**
	 * Protected default constructor. Necessary to allow definition
	 * of record with no explicit constructor.
	 * If overriding is REALLY necessary, don't forget to call super();
	 */
	protected SRecordInstance() {
		createFields(getMeta().getFieldMetas());
	}

    /**
	 * Creates field instances when creating the record
	 *
	 */
	private void createFields(List<SFieldMeta> fieldList) {
		int nbFlds = getMeta().getFieldMetas().size();
		fieldValues = new Object[nbFlds];
		fieldOptimisticValues = new Object[nbFlds];
		
        Arrays.fill(fieldValues, INVALID_VALUE);
	}
    

	/**
	 * Determines whehter two SRecordInstances are for the same SRecordMeta and
	 * have the same primary key fields.
	 * <p>
	 * 
	 * This is purely for the purpose of putting <code>SRecordInstances</code>
	 * in the <code>SSession.transactionCache</code>. This is done as
	 * <code>tc.put(SRecordInstance, SRecordInstance)</code>, ie the instance
	 * is used for both the key and the body. This avoids having to create a
	 * separate primary key object for each record instance.
	 * <p>
	 * 
	 * It only foreign keys, not referenced SRecordInstances which may be null
	 * if the parent record has not been retrieved.
	 */
	public boolean equals(Object key2) {
        boolean eq = equalsInner(key2);
        //System.err.println("- Equals " + eq + this + key2);
        return eq;
    }
	private boolean equalsInner(Object key2) {
		if (this == key2) // even if key is null
			return true;
		if (!(key2 instanceof SRecordInstance))
			return false;

		SRecordInstance pkey2 = (SRecordInstance) key2;
		SRecordMeta<?> meta = getMeta();
		if (meta != pkey2.getMeta())
			return false;
		
		for (SFieldScalar fmeta : getMeta().getPrimaryKeys()) {
			Object k1 = this.getRawValue(fmeta);
			Object k2 = pkey2.getRawValue(fmeta);
            if (k1 == null || k2 == null) // If DataSet.createWinNullKey.
                return false; // even if both null.
			if (!k1.equals(k2))
				return false; // Can never be null
		}
		return true;
	}

	/** See <code>equals()</code>. */
	public int hashCode() {
		// Note that SFieldMeta.rawSetFieldValue can change the hash code.
        // No real point in caching, only calculated once per object anyway when put in.
			int code = getMeta().getTableName().hashCode();
			SFieldScalar[] keys = getMeta().getPrimaryKeys();
			for (SFieldScalar fmeta : keys) {
				Object k1 = this.getRawValue(fmeta);
				if (k1 == INVALID_VALUE) 
                    throw new SException.InternalError("hashCode before primary key set");
				if (k1!=null) // createWithNullKey
                    code = k1.hashCode() + code << 1;
                else
                    code = System.identityHashCode(this); // Just to avoid collisions.
			}
    		return code; // code % (1<<16 -1) only produces marginal improvement (10K --> 7K).
	}

    static private int hasMapsHash(int h) { // Copied from HashMap for testing purposes only.  It does a BAD job!
        // This function ensures that hashCodes that differ only by
        // constant multiples at each bit position have a bounded
        // number of collisions (approximately 8 at default load factor).
        h ^= (h >>> 20) ^ (h >>> 12);
        h = h ^ (h >>> 7) ^ (h >>> 4);
        return h & (1<<16 -1);
    }
    
	/**
	 * Returns the field's value as a Java Object in the type stored in the dataset. <P>
     * 
     * Methods such as
	 * <code>getString()</code> dispach to this method but are generally more
	 * convenient because the cast the result to the correct type. This method
	 * in turn just dispaches to <code>field.getFieldValue()</code>, ie. it
	 * is the declaredtype of the SField that determines how the value is
	 * retrieved.<P>
     * 
	 * Don't rely on null result, as it could mean field is null, or it has
	 * not been queried or set. Use isNull(field) instead. <p>
     * 
     * Note that Enums are stored as strings, use getEnum to return an Enum.
	 */
	public Object getObject(SFieldMeta field) {
        checkFieldIsAccessible(field);
        if (!isValid(field))
            throw new SException.Error("Cannot get unretrieved/unset field " + this + "." + field);
		return field.getRawFieldValue(this, SQueryMode.SFOR_UPDATE, SSelectMode.SNORMAL);
	}

    private void checkFieldIsAccessible(SFieldMeta field) throws Error {
        if (!isNotDestroyed()) {
            throw new SException.Error("Cannot access destroyed record " + this);
        }
        if (isDeleted()) {
            throw new SException.Error("Attempt to access Deleted record " + this);
        }
        if (field.getRecordMeta() != this.getMeta()) {
            throw new SException.Error("Field " + this + " is not in " + this.getMeta());
        }
    }


	/**
	 * Generic routine to set a fields value. Just dispaches to
	 * <code>field.setFieldValue(convertToField(value))</code>
	 * <p>
	 */
	public void setObject(SFieldMeta field, Object value) {
        setObject(field, value, true);
    }
	
    /** Enables value to be set with field validation suppressed, rarely used. */
    public void setObject(SFieldMeta field, Object value, boolean fieldValidate) {
		checkFieldIsAccessible(field);
		// throw exception if not updatable
		if (isReadOnly()) 
            throw new SException.Error("Record is ReadOnly " + this);

		// / Convert rawValue if necessary.
		Object convValue = null;
		try {
			convValue = field.convertToDataSetFieldType(value);
		} catch (Exception ex) {
			throw new SException.Data("Converting " + value + " for "
					+ this + "." + field, ex);
		}

		// / Set the field value if different.
		Object oldValue = null;
		if (isValid(field))
			oldValue = getRawValue(field);
		if (        !isValid(field)
				|| (convValue == null && oldValue != null)
				|| (convValue != null && 
                       (oldValue == null || !convValue.equals(oldValue)))) {
            
  			field.rawSetFieldValue(this, convValue);
            
			// / Now do any user validations. Do them now so validators can access new field value.
			try {
				if (fieldValidate) this.doValidateField(field, convValue); // oldValue not passed as not available for Record validation.
			}
			catch (SException.Validation e) {
				// if validation fails, reset field to its initial value
				field.rawSetFieldValue(this, oldValue);
				throw e;
			}
			this.setDirty(true);
		}
	}

    /** Was the field SQL NULL in the database?  
     * (eg. getInt would return 0 for this case.)
     */
	public boolean isNull(SFieldMeta field) {
		return getObject(field) == null;
	}

	public void setNull(SFieldMeta field) {
		setObject(field, null);
	}

	/**
	 * True if field is the empty value, ie. null or "" or spaces.
	 * @see #SMANDATORY
	 */
	public boolean isEmpty(SFieldMeta field) {
        Object obj = getObject(field);
        if (obj == null) return true;
        if (obj instanceof String) {
            String str = (String)obj;
            if (str.isEmpty()) return true;
            if (str.trim().isEmpty()) return true; // little expensive
        }
        return false;
	}

	/**
	 * Sets field to be empty, ie. currently <code>setObject(,
	 null)</code>.
	 * But other options will be added later.
	 * 
	 * @see #SMANDATORY
	 */
	public void setEmpty(SFieldMeta field) {
		setObject(field, null);
	}

	/**
	 * Gets the value of field cast to a String, trimed of trailing spaces. This
	 * is equivalent to <code>getObject().toString().trimTrailingSpaces()</code>.
	 * So the field type itself need not be <code>SFieldString</code>, but
	 * just something that can be cast to a String. Trailing spaces can be a
	 * problem with some databases and fileds declared <code>CHAR</code>.
	 * <p>
	 * 
	 * Note that if you do not want trailing spaces trimmed, then just call
	 * getObject().toString() manually. (For CHAR fields, most dbs/jdbc drivers
	 * seem to trim, but this is highly inconsistent.)
	 * <p> ## Trimming is an issue with CHAR style fields that pad with spaces.
	 * Currently we always read from database into the fields without trimming.
	 * The idea being to let the SimpleORM user get at the raw query result
	 * using getObject, whatever that raw result is.
	 * <p>
	 * 
	 * Most DBs seem to trim for us. But some may not, and some may require the
	 * trailing spaces on queries. Certainly trailing spaces in the objects will
	 * upset the record cache, and there is some dubious code in
	 * SRecordFinder.retrieveRecord() to handle this.
	 * <p>
	 * 
	 * I think that for CHAR fields we need to always trim at database read, and
	 * pad where needed. This should also be dispatched to DB handler. I think
	 * that Oracle gives grief. (Note that trim means trailing spaces, leading
	 * should be left alone.)
	 * <p>
	 * 
	 * I have not done this because it would require testing on many datbases.
	 * <p>
	 */
	public String getString(SFieldMeta field) {
		try {
			Object val = getObject(field);
			if (val == null)
				return null;
			String str = val.toString();
			int end = str.length() - 1;
			int sx = end;
			for (; sx > -1 && str.charAt(sx) == ' '; sx--)
				;
			if (sx != end)
				return str.substring(0, sx + 1);
			else
				return str;
//			return field.getString(getObject(field));
		} catch (SException.Error er) {
			throw er;
		}
	}

    /** Sets the value of the field from a string, casting if necessary.
     * So this can be used to set an Integer field, say.
     */
	public void setString(SFieldMeta field, String value) {
		setObject(field, value);
	}

	/**
	 * Casts getObject() to int iff a Number, see getString(). Returns 0 if
	 * null, following JDBC.
	 */
	public int getInt(SFieldMeta field) {
		Object val = getObject(field);
   		if (val == null)
			return 0;
		if (val instanceof Number)
			return ((Number) val).intValue();
		else
            try {
    			return Integer.parseInt(val.toString());
            } catch (Exception ex) {
                throw new SException.Data("Could not convert " + field + " to int " + val, ex)
                    .setFieldMeta(field).setRecordInstance(this).setParams(val);
            }
	}

	public void setInt(SFieldMeta field, int value) {
		setObject(field, new Integer(value));
	}

	/**
	 * Casts getObject() to long iff a Number, see getString(). Returns 0 if
	 * null, following JDBC. Note that longs may not be accurately supported by
	 * the database -- see SFieldLong.
	 */
	public long getLong(SFieldMeta field) {
    	Object val = getObject(field);
        if (val == null)
			return 0;
		if (val instanceof Number)
			return ((Number) val).longValue();
		else
            try {
    			return Long.parseLong(val.toString());
            } catch (Exception ex) {
                throw new SException.Data("Could not convert " + field + " to long " + val, ex)
                    .setFieldMeta(field).setRecordInstance(this).setParams(val);
            }
	}

	public void setLong(SFieldMeta field, long value) {
		setObject(field, new Long(value));
	}

	/**
	 * Casts getObject() to double iff a Number, see getString(). Returns 0 if
	 * null, following JDBC.
	 */
	public double getDouble(SFieldMeta field) {
		Object val = getObject(field);
   		if (val == null)
			return 0;
		if (val instanceof Number)
			return ((Number) val).doubleValue();
		else
            try {
    			return Double.parseDouble(val.toString());
            } catch (Exception ex) {
                throw new SException.Data("Could not convert " + field + " to double " + val, ex)
                    .setFieldMeta(field).setRecordInstance(this).setParams(val);
            }
	}

	public void setDouble(SFieldMeta field, double value) {
		setObject(field, new Double(value));
	}

	/**
	 * Casts getObject() to double iff a Number, see getString(). Returns false
	 * if null.
	 */
	public boolean getBoolean(SFieldMeta field) {
		try {
			Object val = getObject(field);
			return val == Boolean.TRUE;
		} catch (SException.Error er) {
			throw er;
		}
	}
    
    
	public void setBoolean(SFieldMeta field, boolean value) {
		setObject(field, value ? Boolean.TRUE : Boolean.FALSE);
	}

	/** etc. for Timestamp. */
	public java.sql.Timestamp getTimestamp(SFieldMeta field) {
			java.sql.Timestamp val = ((java.sql.Timestamp) getObject(field));
			return val;
	}

	/**
	 * Note that value should normally be a java.sql.Timestamp (a subclass of
	 * java.util.Date). However, if it is a java.util.Date instead, then it will
	 * replaced by a new java.sql.Timestamp object before being set. This is
	 * convenient for people using java.util.Date as their main date type.
	 */
	public void setTimestamp(SFieldMeta field, java.util.Date value) {
		setObject(field, value);
	}

	/** etc. for Date. 
     ### Should convert strings to Date, ISO etc.  Likewise other types.
     (Painful to do in Java!)
     */
	public java.sql.Date getDate(SFieldMeta field) {
			java.sql.Date val = ((java.sql.Date) getObject(field));
			return val;
	}

	/** See {@link #setTimestamp} for discussion of Date parameter. */
	public void setDate(SFieldMeta field, java.util.Date value) {
		setObject(field, value);
	}

	/** etc. for Time. */
	public java.sql.Time getTime(SFieldMeta field) {
			java.sql.Time val = ((java.sql.Time) getObject(field));
			return val;
	}

	/** See {@link #setTimestamp} for discussion of Date parameter. */
	public void setTime(SFieldMeta field, java.util.Date value) {
		setObject(field, value);
	}

	/** etc. for BigDecimal. */
	public BigDecimal getBigDecimal(SFieldMeta field) {
			BigDecimal val = ((BigDecimal) getObject(field));
			return val;
	}
	
	public void setBigDecimal(SFieldMeta field, BigDecimal value) {
		setObject(field, value);
	}

    public <T extends Enum<T>> T getEnum(SFieldEnum<T> field) {
        String val = getString(field);
        return field.convertToEnum(val);
    }
     public <T extends Enum<T>> void setEnum(SFieldEnum<T> field, Enum<T> value) {
        setObject(field, value);
    }

	/** Casts getObject() to byte[]. */
	public byte[] getBytes(SFieldMeta field) {
		try {
			Object val = getObject(field);
			return (byte[]) val;
		} catch (SException.Error er) {
			throw er;
		}
	}

	public void setBytes(SFieldMeta field, byte[] value) {
		setObject(field, value);
	}


	/**
	 * Gets a record referenced by <code>this.field</code>. 
     * Does a lazy lookup on the SDataSet.getSession()  if necessary, and if attached to a session.
	 */
	public <T extends SRecordInstance> T findReference(SFieldReference<T> field) {
		return (T)findReference(field, SQueryMode.SFOR_UPDATE, SSelectMode.SNORMAL);
	}
	
	public <T extends SRecordInstance> T findReference(SFieldReference<T> field, SSelectMode selectMode) {
		return (T)findReference(field, SQueryMode.SFOR_UPDATE, selectMode);
	}
	
	public <T extends SRecordInstance> T findReference(SFieldReference<T> field, SQueryMode queryMode) {
		return (T)findReference(field, queryMode, SSelectMode.SNORMAL);
	}
	
	public <T extends SRecordInstance> T findReference(SFieldReference<T> field, SQueryMode queryMode, SSelectMode selectMode) {
        checkFieldIsAccessible(field);
		return (T) field.getRawFieldValue(this, queryMode, selectMode);
	}
        
	public void setReference(SFieldReference<?> field, SRecordInstance value) {
		setObject(field, value);
	}

	/**
	 * Same as getReference, except that if the referenced record is not already
	 * in the cache then it will simply return Boolean.FALSE. Particularily
	 * useful for detached records where it is not possible to do such a query.
	 * <p>
	 * 
	 * If the underlying scalar key values are null, then this always null
	 * because there is no record to retrieve. It is only for a non-null,
	 * non-retrieved references that this returns FALSE.
	 */
	@Deprecated
	public Object getReferenceNoQuery(SFieldReference field) {
		//SFieldInstance finst = this.getField(field); 
		if (!this.isNotDestroyed())
			throw new SException.Error("Cannot access destroyed record " + this);
		if (this.isDeleted())
			throw new SException.Error("Attempt to access Deleted record " + this);
		if ( ! field.getRecordMeta().equals(this.getMeta())) // ie. identical
			throw new SException.Error("Field " + this + " is not in " + this.getMeta());
		return field.getRawFieldValue(this, SQueryMode.SREFERENCE_NO_QUERY, SSelectMode.SNORMAL);
	}

	/**
	 * Sets this record to be dirty so that it will be updated in the database.
	 * Normally done implicitly by setting a specific column. 
	 * 
	 * NOP - But may
	 * occasionally be useful after a findOrInsert() to add a record that
	 * contains nothing appart from its primary key. ===> isNewRow is here for that
     * @See SDataSet#makeFlushedDirty which also makes dirty.
	 */
	public void setDirty(boolean val) {
        if (val == dirty) return;
		if (val) {
			if (readOnly)
				throw new SException.Error("Record retrieved read only " + this);
			dirty = true;
			if (sDataSet != null) { // && updateListIndex == -1) {
				updateListIndex = sDataSet.putInDirtyList(this);
			}
		}
		else {
			if (sDataSet != null && updateListIndex == -1) {
				sDataSet.removeFromDirtyList(updateListIndex, this);
			}
			dirty = false;
			updateListIndex = -1;
		}
	}

	/**
	 * True iff this record is dirty but not yet flushed to the database. May be
	 * both dirty and unattached.
	 * <p>
	 * 
	 * A record is not dirty if a record has been flushed to the database but
	 * the transaction not committed.
	 * <p> ## Should add <tt>wasEverDirty</tt> method for both record and
	 * fields for validation tests.
	 */
	public boolean isDirty() {
		return dirty;
	}

	/** Tests whether just field is dirty. */
	public boolean isDirty(SFieldMeta field) {
        return isValid(field) && fieldOptimisticValues[field.index] != fieldValues[field.index]; // eq or equal?
        // Should ideally have test that simply retrieved references are not dirty.
	}

	/**
	 * Was in the cache before the most recent findOrCreate. (Will always been
	 * in the cache after a findOrCreate.) Used to prevent two create()s for the
	 * same key. Also for unit tests.
	 */
	public boolean wasInCache() {
		return wasInCache;
	}

	/**
	 * Sets a flag to delete this record when the transaction is commited. The
	 * record is not removed from the transaction cache. Any future
	 * <code>findOrCreate</code> will thus return the deleted record but its
	 * fields may not be referenced. (<code>isDeleted</code> can be used to
	 * determine that the record has been deleted.)
	 * <p>
	 * 
	 * The record is only deleted from the database when the transaction is
	 * committed or is flushed. Thus a transaction that nulls out references to
	 * a parent record and then deletes the parent record will not cause a
	 * referential integrity violation because the update order is preserved so
	 * that the updates will (normally) be performed before the deletes.
	 * <p>
	 * 
	 * Note that for Optimistic locks only those fields that were retrieved are
	 * checked for locks.
	 */
	public void deleteRecord() {
		if (! isNotDestroyed() || deleted)
			throw new SException.Error("Cannot delete destroyed record " + this);
		setDirty(true);
		deleted = true;
	}

	public boolean isDeleted() {
		return deleted;
	}

	/**
	 * Often called after {SRecordMeta#findOrCreate} to determine whether a row
	 * was retrieved from the database (not a new row) or whether this record
	 * represents a new row that will be inserted when it is flushed.
	 */
	public boolean isNewRow() {
		return newRow;
	}
	public void setNewRow(boolean val) {
		newRow = val;
	}

	/**
	 * Throws an excpetion if !{@link #isNewRow}. Handy, use often in your
	 * code to trap nasty errors.
	 */
	public void assertNewRow() {
		if (!isNewRow())
			throw new SException.Error("Not a new row " + this);
	}

	/** @see #assertNewRow */
	public void assertNotNewRow() {
		if (isNewRow())
			throw new SException.Error("Is a new row " + this);
	}

	/**
	 * True if the record has valid data, ie. it has not been destroyed. (This
	 * has nothing to do with validateRecord.)
	 */
	// TODO how should this be implemented ?
	public boolean isNotDestroyed() {
		return fieldValues != null;
	}

	/**
	 * True if the field has been queried as part of the current transaction and
	 * so a get is valid. Use this to guard validations if partial column
	 * queries are performed. See isDirty.
	 */
	public boolean isValid(SFieldMeta field) {
        return ! (fieldValues[field.index] instanceof InvalidValue);
	}

	/**
	 * Destroys this instance so that it can no longer be used. Also nulls out
	 * variables so to reduce risk of memory leaks. Note that it does not remove
	 * the record from the transaction cache and update list -- it cannot be
	 * called on its own.
	 */
	void destroy() {
		updateListIndex = -2;
        fieldValues = null;
        fieldOptimisticValues=null;
		sDataSet = null;
	}


	/**
	 * True if this instance is attached to the current begun transaction.
	 * Exception if is attached but not to the current transaction or the
	 * current transaction has not begun.
     * #### not right.
	 */
	public boolean isAttached() {
		return sDataSet.isAttached();
	}


	/**
	 * toString just shows the Key field(s). It is meant to be consise, often
	 * used as part of longer messages.
	 */
	public String toString() {
		return toStringDefault();
	}

	/**
	 * Default behavior of toString(). This was split out from the toString()
	 * method to avoid infinite recursion if a subclass of SRecordInstance
	 * overrode toString() to use any of the get...() methods.
	 */
	String toStringDefault() {
		StringBuffer ret = new StringBuffer("[" + SUte.cleanClass(getClass())
				+ " ");
		if ( ! isNotDestroyed())
			ret.append("[Destroyed SRecordInstance]");
		else {
			boolean first = true;
			for (SFieldScalar fld : getMeta().getPrimaryKeys()) {
				if (!first)
					ret.append(", ");
				first = false;
				if (isValid(fld))
					ret.append(getRawValue(fld));
			}
		}
		if (newRow)
			ret.append(" NewRecord");
		if (deleted)
			ret.append(" Deleted");
		if (dirty)
			ret.append(" Dirty"+updateListIndex);
		ret.append("]");
		return ret.toString();
	}

	/** For debugging like toString(), but shows all the fields. */
	public String allFields() {
		StringBuffer ret = new StringBuffer("[" + SUte.cleanClass(getClass())
				+ " ");
		if ( ! isNotDestroyed())
			ret.append("[Destroyed SRecordInstance]");
		else {
			int px = 0;
			for (SFieldMeta fmeta : getMeta().getFieldMetas()) {
				if (px++ > 0)
					ret.append("| ");
				if (isValid(fmeta))
					ret.append(getRawValue(fmeta));
				else ret.append("UNQUERIED");
			}
		}
		if (newRow)
			ret.append(" NewRecord");
		if (deleted)
			ret.append(" Deleted");
		if (dirty)
			ret.append(" Dirty");
		ret.append("]");
		return ret.toString();
	}

	
	/**
	 * Exception thrown due to broken optimistic locks. This one may be worth
	 * trapping by the application so gets its own class.
	 */
	public static class BrokenOptimisticLockException extends SException {
		static final long serialVersionUID = 20083L;

		SRecordInstance instance;

		public BrokenOptimisticLockException(SRecordInstance instance) {
			super("Broken Optimistic Lock " + instance, null);
			this.instance = instance;
		}

		/** The record that had the broken optimistic lock. */
		public SRecordInstance getRecordInstance() {
			return instance;
		}
	}
	
	void setPrimaryKeys(Object[] pkeys) {
		// / If keys is a single key then make it an singleton array.
		int passedKeysIndex = 0;
		for (SFieldScalar keyf : getMeta().getPrimaryKeys()) {
			if (pkeys.length < passedKeysIndex + 1)
				throw new SException.Data("Too few key params "	+ SUte.arrayToString(pkeys));

			// Object rawValue = npkeys != null ? npkeys[kx] : pkey;
			Object rawValue = pkeys[passedKeysIndex];
			if (rawValue == null)
				throw new SException.Data("Null Primary key " + keyf + " "+ passedKeysIndex);

			// / Convert rawValue if necessary.
			Object convValue = null;
			try {
				convValue = keyf.convertToDataSetFieldType(rawValue);
			}
			catch (Exception ex) {
				throw new SException.Data("Converting " + rawValue+ " for " + this + "." + keyf, ex);
			}

			// For references this will also copy the foreign key values.
			keyf.rawSetPrimaryKeyValue(this, convValue);
			passedKeysIndex++;
		}
		if (passedKeysIndex != pkeys.length)
			throw new SException.Error("Too many key params "
					+ (passedKeysIndex + 1) + " < " + SUte.arrayToString(pkeys)+ ".length");
	}
    
    /** For createWithNullKey */
	void nullPrimaryKeys() {
		// / If keys is a single key then make it an singleton array.
		for (SFieldScalar keyf : getMeta().getPrimaryKeys()) {
            if (getRawValue(keyf) != INVALID_VALUE)
                throw new SException.InternalError("Nulling non new key");
			setRawValue(keyf, null);
		}
	}
	

	void doValidateField(SFieldMeta field, Object newValue) {
		field.doValidate(this);
        try {
            onValidateField(field, newValue);
        } catch (SException.Validation ve) {
            ve.setFieldMeta(field);
            ve.setRecordInstance(this);
            ve.setFieldValue(newValue);
        }
	}
    
    /**
     * Called after individual field validators each time a field's value is set,
	 * (now) including keys.  Not called as values are retrieved from database.<p>
     * 
	 * Throw an SException.Validation if not OK. The value is not assigned, and
	 * the transaction can continue.  The exception will be augmented with 
	 * <p>
	 * 
	 * This is called after the value has been converted to its proper type, eg.
	 * from a String to a Double and the field value has been updated. 
	 * <p>
     * If the validation fails, the field is automatically set back to its oldValue.<p>
     * 
	 * This is called for key values as well. This is only for newly created
	 * records but is during the findOrCreate -- ie it is called even if the
	 * record is never made dirty and thus saved.<p>
     *  
	 *@See #onQueryRecord
	 */
    protected void onValidateField(SFieldMeta field, Object newValue){}


	public void doValidateRecord() {
		// Don't validate is deleted
		if (isDeleted()) return;
		// else
		List<SFieldMeta> fields = getMeta().getFieldMetas();
		for (SFieldMeta field : fields) {
       		if (isValid(field))
  			  field.doValidate(this);
		}
        try {
            onValidateRecord();
        } catch (SException.Validation vre) {
            vre.setInstance(this);
            throw vre;
        }
	}

    /** Override this to validate records before flush. 
	 * Throw an SValidationException if not OK.<p>
	 * 
	 * This is called just before a record would be flushed. Only dirty records
	 * are validated. If the validation fails then the record is not flushed.
	 * (It may also be called directly by the application to validate the record
	 * before it is flushed.)
	 * <p>
	 * 
	 * Use this routine when a record may be in a temporarily invalid state, but
	 * which must be corrected before flushing. This is common when there is a
	 * more complex relationship between different fields that cannot be
	 * validated until all the fields have been assigned values.<p>
	 */
   	protected void onValidateRecord() {}

    /** Override this to get field values just after a record is actually retrieved, by findOrCreate or query. */
    protected void onQueryRecord() {}    
    public void doQueryRecord() {onQueryRecord();}
    
	public void validatePrimaryKeys() {
		Object value = null;
		for (SFieldScalar keyf : getMeta().getPrimaryKeys()) {
			//if ( ! keyf.isForeignKey()) { // TODO why this test ?
				value = getObject(keyf);
				doValidateField(keyf, value);
			//}
		}
	}
		
	// Filed instance methods
	
	/**
	 * Raw setter for field value. Internal to Simpleorm.
	 * @param fmeta the field to set
	 * @param value the new value of the field, as is, can be null
	 */
	public void setRawValue(SFieldMeta fmeta, Object value) {
		fieldValues[fmeta.index] = value;
	}
	/**
	 * Raw accessor for field value. Internal to Simpleorm.
	 * @param fmeta the field to get
	 * @param value the raw value of the field, as is, can be null
	 */
	public Object getRawValue(SFieldMeta fmeta) {
		return fieldValues[fmeta.index];
	}
	void setValid(SFieldMeta fmeta, boolean valid) {
	}
    	
    /** The value that was read from (or flushed to) the database.
     * Used for optimistic locking, and also just to tell how fields change.
     */
    public Object getInitialValue(SFieldMeta fieldMeta) {
		return fieldOptimisticValues[fieldMeta.index];
	}
   	
    /**
     * Copies the initial value for field,  mainly used for optimistic locking and
	 * <p>
	 * 
	 * The copy is cheap because it is only copying pointers. However, if the
	 * optimisitic lock fails then an exception will be thrown. Mainly used for
	 * long lived transactions.
	 * <p>
	 */
	public void copyInitialValue(SFieldMeta field) {
    	// Already done, maybe findOrCreating the same record twice
		fieldOptimisticValues[field.index] = fieldValues[field.index];
	}

    //////////// ACCESSORS ////////////
    public boolean isReadOnly() {
		return readOnly;
	}
	public void setReadOnly(boolean val){
		readOnly = val;
	}
	public SDataSet getDataSet() {
		return sDataSet;
	}
	
	// Internal state - package visible only, used by SDataSet
	//
	
	void setDataSet(SDataSet ds) {
		sDataSet = ds;
		//sDataSet.putInCache(this);
	}

    void setWasInCache(boolean val) {
		wasInCache = val;
	}

}
