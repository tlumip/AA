package simpleorm.dataset;

import java.sql.ResultSet;

import simpleorm.dataset.validation.SValidatorEnum;
import simpleorm.utils.SException;

/**
 * Represents Enum field meta data.  
 * Note that internal storage is as String, not Enum, which is more flexible eg. if database has bad data.
 * So getObject() returns String, but getEnum() returns Enum.
 */

public class SFieldEnum<T extends Enum<T>> extends SFieldScalar {

	static final long serialVersionUID = 3L;
	
	private Class<T> enumClass = null;
	
	/**
	 * <code>enumType</code> is the Enum type backing this field
	 */
	public SFieldEnum(SRecordMeta<?> meta, String columnName, Class<T> enumType, SFieldFlags... pvals) {
		super(meta, columnName, pvals);
		int maxSize = 0;
		enumClass = enumType;
		//enumInstance = exampleValue;
		for (T val : enumClass.getEnumConstants()) {
			maxSize = maxSize < val.name().length() ? val.name().length() : maxSize;
		}
		setMaxSize(maxSize);
   		addValidator(new SValidatorEnum<T>(this));
	}
	
	public Class<T> getEnumClass() {
		return enumClass;
	}

	public Object queryFieldValue(ResultSet rs, int sqlIndex) throws Exception {
		return rs.getString(sqlIndex);
	}

	/**
	 * Internal representation of SFieldEnum is
	 * String, as it is the way it is persited in database.
	 * enumClass is used mostly as a validator.
	 */
	protected Object convertToDataSetFieldType(Object raw) {
		if (raw == null) {
			return null;
		}
		else if (raw instanceof String) {
			return raw;
		}
		else if (raw instanceof Enum) {
			Enum en = (Enum) raw;
            //en.valueOf(enumClass, sqlDataTypeOverride)
			return en.name();
		}
		throw new SException.Data("Cannot convert " + raw + " to Enum.");
	}

    public <T extends Enum<T>> T  convertToEnum(String value) {
        return (T)Enum.valueOf(enumClass, value);        
    }
    
	@Override public String defaultSqlDataType() {
		return "VARCHAR(" + this.getMaxSize()+")";
	}

	/**
	 * Nota : foreign key is allowed if the enum values can be stored
	 * in the database... We don't force checking the values (ie use same enum type)
	 */
	public boolean isCompatible(SFieldScalar field) {

		if (!(field instanceof SFieldString))
			return false;
		SFieldString strField = (SFieldString) field;
		if (strField.getMaxSize() != this.getMaxSize())
			return false;
		return true;
	}
	
	@Override public int javaSqlType() {
		return java.sql.Types.VARCHAR;
	}
}
