 package simpleorm.quickstart;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Iterator;

import org.apache.commons.sql.io.JdbcModelReader;
import org.apache.commons.sql.model.Database;
import org.apache.commons.sql.model.Table;

//import clientMatterTask.new_db.br.ClientMatterTaskFormatter;


/**
 * This class generates the SimpleORM mapping files for a (in this example)
 * Sybase schema.
 *
 * Designed to run as an ANT task with the following system paramters:
 * <ul>
 * <li>database.url=jdbc:interbase://localhost/C:/Source/Java/ORM/SimpleORM/simpleorm/temp/test.gdb
 * <li>database.username=sysdba
 * <li>database.password=masterkey
 * <li>database.driver=interbase.interclient.Driver
 * <li>database.schema=
 * <li>database.catelog=
 * <li>quickstart.file=.
 * <li>quickstart.packagename=simpleorm.dbtest
 * <li>quickstart.getters_and_setters=true
 * <li>quickstart.use_one_package=true
 * <li>quickstart.INiceNameFormatter=simpleorm.quickstart.DefaultFormatter
 *<ul>
 *
 * To run.
 * <ol>
 * <li>Insure that log4j.jar is in your classpath, along with your JDBC driver.
 * <li>Set the system properties.
 * <li>Create an instance of SimpleORMGenerate
 * <li>Call method execute()
 * </ol>
 *
 * @author <a href="mailto:richard.schmidt@inform6.com">Richard Schmidt</a> Original version Joe McDaniel.
 * @version $Id: $
 */
public class SimpleORMGenerator {
	
	private String dbDriver, dbUrl, dbUser, dbPassword, dbCatolog, dbSchema;
	private File rootDir;
	private String packageName;
	String classNameForFormatter; 	
	private INiceNameFormatter niceName;
	
	private void loadFromSystemPreferences(){
		
    	dbDriver = 	System.getProperty( "database.driver");
		dbUrl = 	System.getProperty("database.url");    	
		dbUser = 	System.getProperty("database.user");            	
		dbPassword=	System.getProperty("database.password");            			
		dbSchema = 	System.getProperty("database.schema","");		
		dbCatolog = System.getProperty("database.catelog","");
		rootDir = 	new File( System.getProperty("quickstart.file","."));
		packageName=System.getProperty("quickstart.packagename");
		classNameForFormatter = 
			System.getProperty("quickstart.INiceNameFormatter","simpleorm.quickstart.DefaultFormatter");		
	} 
	

    /**Use the default nice name formatter*/
    public SimpleORMGenerator() throws Exception{
		
    }


    public void execute() throws Exception{
    	
		loadFromSystemPreferences();    	
        System.out.println("SimpleOrm code generator starting\n");
        System.out.println("Your DB settings are:");
        System.out.println("driver       : " + dbDriver);
        System.out.println("URL          : " + dbUrl);
        System.out.println("user         : " + dbUser);
        System.out.println("password     : " + dbPassword);
        System.out.println("schema       : " + dbSchema);
        System.out.println("catelog      : " + dbCatolog);        
        System.out.println();        
        System.out.println("Other settings are");        
        System.out.println("directory    : " + rootDir.getAbsolutePath());                
        System.out.println("package name : " + packageName);                        
        System.out.println("INiceName    : " + classNameForFormatter);                                
        System.out.println();        
        
        //Load up the INiceName

		try {
			niceName = (INiceNameFormatter)        
			    Class.forName( classNameForFormatter).getConstructor( null).newInstance(null);
			
		} catch (Exception e) {
			System.err.println( "Could not load INiceNameFormatter, will use DefaultFormatter instead");
			e.printStackTrace();
			niceName = new DefaultFormatter();
		}    
        //Add on the package directory
        rootDir = new File(rootDir.getAbsolutePath() + File.pathSeparator +
                packageName.replace('.', File.pathSeparator) + File.pathSeparator);

        if (!rootDir.exists()) {
            rootDir.mkdirs();
        }

        // Load the database Driver.
        Class.forName( dbDriver);

        // Attemtp to connect to a database.
        Connection con = DriverManager.getConnection(  dbUrl, dbUser, dbPassword);
        JdbcModelReader reader = new JdbcModelReader(con);
        reader.setCatalog(dbCatolog);
        reader.setSchema( dbSchema);
        //Get the metta data from the database
        Database db = reader.getDatabase();


		//Itterate trhough the tables, generating the files.        
        Iterator tablesEnum = db.getTables().iterator();
        while (tablesEnum.hasNext()) {
            try {

                TableGenerate table = new TableGenerate(db,
                        (Table) tablesEnum.next(), niceName, packageName, rootDir);
                        
                table.generateBaseClass();
                table.generateBRClass();
                System.out.println("Generated table " + table.table.getName());            	                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        System.out.println("done");
    }


    public static void main(String[] args) throws Exception{
    	
    	System.setProperty("database.driver","interbase.interclient.Driver");
		System.setProperty("database.url","jdbc:interbase://localhost/C:/Source/Java/ORM/SimpleORM/simpleorm/temp/test.gdb");    	

		System.setProperty("database.user","sysdba");            	
		System.setProperty("database.password","masterkey");            			
		System.setProperty("database.schema","");
		System.setProperty("database.catelog","");
		System.setProperty("quickstart.file",".");
		System.setProperty("quickstart.packagename","simpleorm.new_db");
		System.setProperty("quickstart.INiceNameFormatter","simpleorm.quickstart.DefaultFormatter");


		System.setProperty("database.url","jdbc:interbase://localhost/C:/Source/Ostrich/Database/ostrich2.gdb");		
//		System.setProperty("quickstart.INiceNameFormatter","simpleorm.quickstart.SimpleORMNiceNameFormatter");		
		System.setProperty("quickstart.INiceNameFormatter","foursee.ots.orm.tables.OtsFormatter");
		System.setProperty("quickstart.packagename","foursee.ots.simpleorm");
		
        SimpleORMGenerator instance =  new SimpleORMGenerator();
       
        instance.execute();
    }
}
