package simpleorm.sessionjdbc;

import simpleorm.dataset.SFieldScalar;
import simpleorm.dataset.SRecordMeta;
import simpleorm.utils.SException;

/**
 * Generator using Identity columns which have values added by the database when
 * rows are inserted. Only supported by some dbs, notably MSSQL.
 */
public class SGeneratorInsertIdentity extends SGenerator {

	public SGeneratorInsertIdentity(SFieldScalar field, String name) {
		super(field, name);
	}

	public long generateKey(SSessionJdbc session,SRecordMeta meta, SFieldScalar keyField) {
		throw new SException.Error("Not implemented yet.");
	}

}