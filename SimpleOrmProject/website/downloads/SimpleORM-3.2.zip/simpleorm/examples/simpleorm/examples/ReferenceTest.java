package simpleorm.examples;

import static simpleorm.dataset.SFieldFlags.SDESCRIPTIVE;
import static simpleorm.dataset.SFieldFlags.SPRIMARY_KEY;
import simpleorm.dataset.SFieldInteger;
import simpleorm.dataset.SFieldReference;
import simpleorm.dataset.SFieldScalar;
import simpleorm.dataset.SFieldString;
import simpleorm.dataset.SRecordInstance;
import simpleorm.dataset.SRecordMeta;
import simpleorm.sessionjdbc.SSessionJdbc;
import simpleorm.sessionjdbc.SDataLoader;

/**
 * This provides a basic test of foreign key references and in particular
 * overlapping foreign keys. 
 * 
 * (Much simplified in SimpleORM 3.0)
 */
public class ReferenceTest {

    public static class RefYY extends SRecordInstance {

//		public RefYY(boolean attached){
//			super(attached);
//		}
		public static final SRecordMeta<RefYY> meta = new SRecordMeta(RefYY.class, "RefYY");

		public static final SFieldString YY_ID = new SFieldString(meta,	"YY_ID", 10, SPRIMARY_KEY);

		public static final SFieldString YNAME = new SFieldString(meta,	"YNAME", 10, SDESCRIPTIVE);
		
		public static final SFieldString XX_ID1 = new SFieldString(meta, "XX_ID1", 10);
		public static final SFieldInteger XX_ID2A = new SFieldInteger(meta, "XX_ID2A");
		public static final SFieldInteger XX_ID2B = new SFieldInteger(meta, "XX_ID2B");
		
		static final SFieldReference<RefXX> XXRA = new SFieldReference(meta, RefXX.meta, "XXRA", 
            new SFieldScalar[]{XX_ID1, XX_ID2A},  new SFieldScalar[]{RefXX.XX_ID1, RefXX.XX_ID2});
		static final SFieldReference<RefXX> XXRB = new SFieldReference(meta, RefXX.meta, "XXRB",
                        new SFieldScalar[]{XX_ID1, XX_ID2B},  new SFieldScalar[]{RefXX.XX_ID1, RefXX.XX_ID2});

		public SRecordMeta getMeta() {
			return meta;
		};
	}

	public static class RefXX extends SRecordInstance {

//		public RefXX(boolean attached){
//			super(attached);
//		}
		public static final SRecordMeta<RefXX> meta = new SRecordMeta(RefXX.class, "RefXX");

		public static final SFieldString XX_ID1 = new SFieldString(meta,	"XX_ID1", 10, SPRIMARY_KEY);

		public static final SFieldInteger XX_ID2 = new SFieldInteger(meta,	"XX_ID2", SPRIMARY_KEY);

        public static final SFieldString XNAME = new SFieldString(meta,		"XNAME", 10, SDESCRIPTIVE);

		public SRecordMeta getMeta() {
			return meta;
		};
	}

    public static void main(String[] argv) throws Exception {
		SSessionJdbc ses = TestUte.initializeTest(ReferenceTest.class);
		System.err.println(RefXX.meta.toLongerString());
		System.err.println(RefYY.meta.toLongerString());
		System.err.println(ses.getDriver().createTableSQL(RefXX.meta) + ";\n");
		System.err.println(ses.getDriver().createTableSQL(RefYY.meta) + ";\n");
        
        ses.begin();
        TestUte.dropAllTables(ses);
        ses.rawUpdateDB(ses.getDriver().createTableSQL(RefXX.meta));
        ses.rawUpdateDB(ses.getDriver().createTableSQL(RefYY.meta));
        ses.commit();
        
        testOverlap();
		SSessionJdbc.getThreadLocalSession().close();
	}
        
    static void testOverlap() {
    	SSessionJdbc ses = SSessionJdbc.getThreadLocalSession();
        ses.begin();
        SDataLoader xl = new SDataLoader(ses, RefXX.meta);
        xl.insertRecords(new Object[][] {
            {"One", 1, "First1"},
            {"One", 2, "First2"},
            {"Two", 1, "Second1"},
            {"Two", 2, "Second2"},
            {"Two", 3, "Second3"},
        });
        
        SDataLoader yl = new SDataLoader(ses, RefYY.meta);
        yl.insertRecords(new Object[][] {
            {"Y1", "FirstY", "One", 1, 2},
            {"Y2", "SecondY", "One", 2, 1},
        });
        
        ses.commit();
        ses.begin();
        
        RefYY y1 = ses.mustFind(RefYY.meta, "Y1");
        
        TestUte.assertEqual("First2", y1.findReference(RefYY.XXRB).getString(RefXX.XNAME));

        RefXX x21 = ses.mustFind(RefXX.meta, "Two", 1);
        RefXX x23 = ses.mustFind(RefXX.meta, "Two", 3);

        y1.setReference(RefYY.XXRA, x21);        
        TestUte.assertEqual("Second2", y1.findReference(RefYY.XXRB).getString(RefXX.XNAME));
        // IE. setting XXRA magically changes XXRB because of the overlapping keys
        ses.flush();
        
        y1.setReference(RefYY.XXRA, x23);
        TestUte.assertEqual("Second2", y1.findReference(RefYY.XXRB).getString(RefXX.XNAME)); // no change.

        ses.flush();        
        y1.setReference(RefYY.XXRA, null);      
        TestUte.assertTrue(y1.isNull(RefYY.XX_ID1));
        TestUte.assertTrue(y1.isNull(RefYY.XX_ID2A));
        TestUte.assertEqual("2", y1.getString(RefYY.XX_ID2B));
        TestUte.assertTrue(null == y1.findReference(RefYY.XXRB));

        ses.commit();
               
    }
}
